# Instalação na Raspberry Pi e gravação do Mega

Destino informado: Raspberry Pi 3B, Raspberry Pi OS 64 bits, usuário `beck`. A aplicação usa o ambiente gráfico da Pi e abre por um ícone, sem autostart.

## Transferir pelo pendrive

Baixe `tcc-nb3-raspberry.zip` e copie para o pendrive. Na Raspberry Pi, abra o pendrive pelo gerenciador de arquivos, extraia o pacote e copie a pasta **TCC-NB3** para a pasta pessoal de `beck`, ficando em `/home/beck/TCC-NB3`. Instale nessa pasta, não diretamente no pendrive: o aplicativo precisa continuar acessível depois de remover o dispositivo.

Se essa pasta já contiver uma instalação ou alterações suas, preserve-a e extraia o novo pacote em outra pasta. O banco com usuários, históricos e limites fica fora da pasta da aplicação e não é apagado pelo instalador.

## Instalar como beck

No terminal da Pi:

```bash
cd ~/TCC-NB3
sha256sum --check SHA256SUMS
bash scripts/install_raspberry.sh
```

Execute o instalador como `beck`, sem prefixar `sudo`. Ele usa sudo apenas para instalar `python3-venv`, `python3-tk`, `xdg-user-dirs` e `avrdude` e para adicionar o usuário ao grupo `dialout`. Os pacotes do sistema precisam de acesso aos repositórios do Raspberry Pi OS; o pyserial é instalado a partir da wheel incluída e verificada.

Encerre e abra a sessão de `beck` se o instalador adicionar o grupo serial. Depois use o ícone **TCC — Arduino e Raspberry Pi** na área de trabalho. Na primeira abertura, o desktop pode pedir **Permitir iniciar**. Não há execução automática no login. Mantenha a pasta `~/TCC-NB3` no mesmo local porque o atalho aponta para ela.

O instalador pode ser repetido. Ele preserva dados, usuários e alarmes em `~/.local/share/tcc-monitor`; não copia bancos da máquina de desenvolvimento. Se já existir um atalho pessoal com o mesmo nome, ele não é sobrescrito.

Para escolher a pasta da área de trabalho ou verificar pré-requisitos já instalados:

```bash
bash scripts/install_raspberry.sh --desktop-dir "$HOME/Desktop"
bash scripts/install_raspberry.sh --skip-system
```

## Firmware já compilado

O pacote contém `firmware/compiled/mega_controller.hex`, compilado para **Arduino Mega 2560 / ATmega2560, 16 MHz**. Consulte `BUILDINFO.json` nessa pasta para versões, hash da fonte e uso de memória. O `.hex` não contém o bootloader: a gravação USB usa o bootloader já instalado no Mega.

Para gravar, feche a aplicação e conecte o Mega por USB. Confira a pinagem NB3 e identifique a porta real:

```bash
ls -l /dev/serial/by-id/
bash scripts/upload_mega.sh /dev/serial/by-id/IDENTIFICADOR_REAL_DO_MEGA
```

O script usa avrdude e verifica a escrita da flash. A instalação da interface não executa esse comando automaticamente. Nenhuma gravação física é considerada validada apenas por compilar o código.

Depois abra o aplicativo pelo ícone. A conexão procura uma única porta USB; se houver mais de uma, execute com a porta escolhida:

```bash
bash scripts/run.sh --port /dev/serial/by-id/IDENTIFICADOR_REAL_DO_MEGA
```

Associe as ROMs dos DS18B20 e calibre os sete canais seguindo [calibration.md](calibration.md) e [commissioning.md](commissioning.md). Com o firmware NB3 instalado, calibrações futuras não exigem recompilar nem gravar o sketch.

## Quando não houver internet na Pi

A wheel do pyserial incluída atende 32 e 64 bits e é instalada offline, com checksum. Os pacotes de sistema são obtidos pelos repositórios assinados do Raspberry Pi OS. Se Tkinter, venv, avrdude e as permissões seriais já estiverem preparados, use `--skip-system`; caso contrário, conecte a Pi à internet para a primeira instalação dos pacotes de sistema. Nenhuma senha de acesso é incluída no pacote.
