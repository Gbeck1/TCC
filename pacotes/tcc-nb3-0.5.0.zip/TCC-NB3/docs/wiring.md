# NB3 — pinagem e interfaces elétricas

Este é o mapa NB3 utilizado pelo firmware/protocolo v2. Ele substitui a pinagem da versão inicial. Confira os componentes, os níveis e a montagem antes de energizar: o código não valida a ligação de potência.

## Mapa do Mega 2560

| Função | Mega 2560 | Observação |
|---|---:|---|
| Barramento dos seis DS18B20 | D36 | OneWire em três fios; pull-up 4,7 kΩ |
| PWM Delta exaustão 1 | D6 | Timer 4A, BC548 com inversão compensada |
| PWM Delta exaustão 2 | D7 | Timer 4B |
| PWM NMB insuflamento | D8 | Timer 4C |
| Alimentação comum das três ventoinhas | D4 | Q4/BC548 aciona um único IRF4905 |
| Peltier | D5 | Timer 3A, gate do IRLZ44N |
| Tacômetro Delta 1 | D2 | Interrupção; pull-up de 10 kΩ para 5 V, se o sinal for compatível |
| Tacômetro Delta 2 | D3 | Interrupção; mesma verificação de nível |
| Tacômetro NMB | D18 | Interrupção; mesma verificação de nível |
| P1 HX710B DOUT / SCK | D22 / D23 | Canal 0, Paramentação |
| P2 HX710B DOUT / SCK | D24 / D25 | Canal 1, Desparamentação |
| P3 HX710B DOUT / SCK | D26 / D27 | Canal 2, Corredor Central |
| P4 HX710B DOUT / SCK | D28 / D29 | Canal 3, Sala de Autoclave |
| P5 HX710B DOUT / SCK | D30 / D31 | Canal 4, Laboratório 1 |
| P6 HX710B DOUT / SCK | D32 / D33 | Canal 5, Laboratório 2, referência fixa do PID |
| P7/ambiente HX710B DOUT / SCK | D34 / D35 | Canal 6 |
| Comunicação Raspberry Pi | USB | Serial 115200, 8N1; protocolo v2, hardware NB3 |

## Ventoinhas: três PWM, uma alimentação

Para cada entrada PWM, há um BC548 como saída de coletor aberto: emissor ao GND comum, coletor ao fio PWM da ventoinha, base ao pino D6/D7/D8 por resistor de **1 kΩ** e pull-down de **10 kΩ** na base. Confira a pinagem do BC548 real. Verifique a tensão e a especificação do sinal PWM de cada ventoinha; não conecte a alimentação de 12 V a um GPIO.

O firmware gera aproximadamente **25 kHz** nos três canais do Timer 4 e compensa a inversão do BC548. PWM lógico 255 significa esforço máximo; a forma de onda no pino do Mega é invertida para produzir o sinal correto no coletor. Reserve o Timer 4 a essa função. Confirme frequência, níveis e sentido da resposta com instrumento e nas ventoinhas reais.

O NB3 usa **um único IRF4905**, de alta lateral, para ligar/desligar a alimentação das três ventoinhas em conjunto. Source vai ao positivo de 12 V, drain ao positivo comum das ventoinhas, gate tem pull-up de **10 kΩ para source/12 V**. Q4, o quarto BC548, puxa o gate ao GND quando D4 comanda ligar; sua base usa **1 kΩ** em série e **10 kΩ** de pull-down. No mapa lógico, D4 alto significa alimentar as três ventoinhas.

**O gate puxado a 12 V não se liga diretamente ao Mega.** Q4 isola esse nível do GPIO. Confira VGS, correntes, dissipação, polaridade e o estado durante o reset dos componentes reais. O manual permite três PWMs independentes, mas o botão de alimentação é único: não existe desligamento elétrico individual de uma ventoinha nesta montagem. Três alimentações independentes exigiriam três MOSFETs P e três drivers dedicados.

As Delta AFB0612EHE e a NMB-MAT 2415KL-04W-B96 podem ter curvas distintas. PWM maior nas Delta não mede vazão e não garante pressão negativa. Use os sensores calibrados e confirme a operação na maquete. Correntes, cores dos fios e níveis aceitos precisam vir das etiquetas/documentação das unidades reais.

## Tacômetros

Os três sinais de tacômetro chegam a D2/D3/D18. A proposta usa pull-up de **10 kΩ para 5 V** em cada entrada; antes de ligar, confirme que o tacômetro de cada modelo é coletor aberto e admite esse nível. Um sinal push-pull ou com nível diferente exige uma interface adequada. Não presuma compatibilidade apenas pela quantidade de fios.

O firmware conta pulsos por interrupção e publica RPM. A configuração inicial de **2 pulsos por volta** é provisória: confira a documentação de cada modelo ou compare com uma referência física e configure cada canal na manutenção ADMIN. Um valor de RPM zero após uma janela sem pulsos não distingue motor parado de cabo/tacômetro sem sinal. O monitoramento não impõe um intertravamento de atuação.

## Peltier

O IRLZ44N chaveia o negativo: drain no negativo do Peltier, source no GND de potência, positivo do Peltier na fonte correspondente. D5 aciona o gate por **100 Ω**, com pull-down gate-source de **10 kΩ**. Na versão 0.4.0, D5 é uma saída digital: HIGH liga o Peltier e LOW desliga. Não há PWM nesse pino. O Timer 4 continua reservado aos ventiladores.

O Peltier informado consome até **3,5 A**. Preveja seu fusível dedicado e dimensione fonte, cabos, conectores, MOSFET e dissipação pela montagem real, além das correntes das ventoinhas. O lado quente exige dissipação adequada. O programa controla resfriamento; não há ponte H ou inversão para aquecimento.

## DS18B20

Os seis sensores usam três fios e o barramento D36 com pull-up de **4,7 kΩ**. Coloque **100 nF** próximo à alimentação de cada DS18B20. Confira o comprimento/capacitância do barramento e a alimentação compatível. Esta montagem não usa alimentação parasita.

Associe cada ROM ao canal/sala correto na manutenção ADMIN. A ordem de descoberta não identifica a posição física. O firmware descobre as ROMs na partida; reinicie o Mega após trocar, adicionar ou retirar sensores para atualizar a lista.

## Pressão e HX710B

Cada um dos sete módulos tem seu DOUT/SCK dedicado conforme a tabela e **100 nF** próximo da alimentação. Confirme tensão de alimentação, nível de DOUT, marcação do conversor e seleção por pulsos/taxa na placa real. HX710A, HX710B e HX711 não devem ser presumidos intercambiáveis. A Pi fala com o Mega apenas por USB; nunca aplique 5 V nos GPIOs de 3,3 V da Pi.

As contagens são assinadas de 24 bits. Cada canal precisa de offset e escala em Pa/contagem medidos com referência física. O nome MPS20N0040D-D não fornece a calibração completa do módulo, da fonte e do amplificador; não use uma escala inventada apenas para preencher a tela.

O MPS20N0040D-D mede a diferença entre suas duas portas. O sétimo módulo chamado “ambiente” não é um barômetro absoluto. Para calcular `canal_sala - canal_ambiente`, os sete canais precisam ter uma referência pneumática coerente, por exemplo uma porta de todos ligada à mesma referência e outra à sala/ambiente correspondente. Defina e verifique essa referência fisicamente.

Se os seis sensores já estiverem ligados diretamente entre sala e ambiente, revise a topologia/fórmula para não descontar o ambiente duas vezes. Verifique se sensibilidade e ruído permitem resolver as pequenas diferenças esperadas na maquete.

## Distribuição de alimentação e partida

A proposta NB3 inclui **2.200 µF / 25 V no barramento de 12 V**; no de 5 V, **470 µF / 10–16 V e 100 nF**. Inclua também os **100 nF** locais dos estágios PMOS/NMOS. Confira polaridade dos eletrolíticos, proximidade das cargas e corrente de ripple; esses valores não dispensam a análise da fonte e da fiação.

Mantenha GND comum nas interfaces que precisam de referência, proteção compatível nas cargas e os caminhos de potência fora dos pinos do Arduino/Pi. Não alimente ventoinhas ou Peltier pelo 5 V/USB. Não interligue o header serial de 5 V do Mega ao header de 3,3 V da Pi. Confirme fontes, fusíveis, conectores, queda de tensão e dissipação antes de comandar cargas.

Ao resetar, o Mega não restaura modo/saídas manuais nem sessão ADMIN. O layout EEPROM NB3 é versão 2 e não reutiliza configuração salva no layout anterior; confira e salve novamente os ajustes. Verifique os estados elétricos durante o reset e a abertura da USB: fechar a aplicação ou perder comunicação, por si só, não desliga as cargas por software.
