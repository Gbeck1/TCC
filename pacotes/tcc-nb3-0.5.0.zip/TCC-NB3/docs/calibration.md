# Calibração dos sensores de pressão pela interface

Com o firmware NB3 deste projeto instalado, os coeficientes são enviados por USB e gravados na memória do Arduino. Não é necessário editar ou reenviar o sketch a cada calibração.

1. Entre como ADMIN e selecione **Manual** na Manutenção.
2. Abra **Manutenção → Calibração** e escolha o canal P1 a P7. A tela identifica a sala; P7 é o canal ambiente.
3. Escolha a quantidade de amostras, de 1 a 30. O padrão é 5 novas leituras. A interface permanece responsiva durante a coleta; leituras ausentes e mensagens repetidas não contam como amostras.
4. Aplique uma pressão de referência conhecida ao sensor, espere estabilizar e preencha **Referência A (Pa)**. Use **Capturar A**.
5. Aplique outra pressão conhecida, diferente da primeira, preencha **Referência B (Pa)** e use **Capturar B**. A tela calcula a média das contagens de cada coleta.
6. Selecione **Calcular** e confira a prévia. **Aplicar calibração** envia os coeficientes ao Arduino. Aguarde a confirmação e a atualização da telemetria.
7. Use **Salvar no Arduino** para manter a configuração após reiniciar. A confirmação de gravação só aparece após a resposta do controlador. A operação grava a configuração atual do controlador, incluindo os demais ajustes já aplicados.

A calibração precisa de duas pressões efetivamente conhecidas, obtidas por uma referência de medição adequada. Digitar valores sem aplicar essas pressões não calibra o sensor. Valores iguais, leituras iguais, números inválidos e coeficientes que não cabem no formato do Mega são rejeitados. A escala pode ser negativa, conforme a orientação das portas pneumáticas.

## Zerar um canal já calibrado

Equalize as portas para estabelecer 0 Pa e espere a leitura estabilizar. **Zerar canal** prepara um novo offset usando a escala existente. Confira a prévia, selecione **Aplicar calibração** e depois **Salvar no Arduino**. Um canal sem escala precisa primeiro da calibração por dois pontos; a zeragem sozinha não determina a escala física.

## Cancelamento e confirmação

**Cancelar coleta** descarta a coleta em andamento sem alterar o Arduino. Trocar o canal descarta as referências ainda não aplicadas, evitando usar os pontos de outra sala. **Cancelar espera** abandona somente o acompanhamento de uma resposta: não desfaz um comando que o Arduino já possa ter executado. Não há reenvio automático em caso de resposta ausente.

A calibração não altera automaticamente PWM, alimentação, Peltier, setpoints ou modo de operação. A interpretação dos sete módulos diferenciais e suas referências pneumáticas deve seguir [o comissionamento](commissioning.md).
