# Protocolo USB serial v2 — hardware NB3

Mega 2560 ↔ Raspberry Pi: 115200 baud, 8N1, JSON UTF-8 compacto, uma mensagem por linha (`\n`). Máximo de comando: 384 bytes. Esta versão identifica a montagem **NB3** e é incompatível com o protocolo v1, que usava alimentações individuais de ventoinha. A interface aceita telemetria somente com `v: 2` e `hardware: "NB3"`; firmware e aplicação precisam ser atualizados juntos.

Sem temporizador de sessão, watchdog de comunicação ou mudança de saída em perda de conexão. A interface é o limite de autenticação: USB e processos locais da Pi são considerados confiáveis; não expor a porta serial pela rede.

Comando: `{"v":2,"type":"command","id":1,"op":"setpoints","temperature":22,"pressure":-10}`.
Resposta: `{"v":2,"type":"ack","id":1,"ok":true}` ou `{"v":2,"type":"ack","id":1,"ok":false,"error":"motivo"}`. Rejeitar NaN, infinito, tipos incorretos, valores não representáveis como float32 no Mega e índices fora dos limites. Essa validação numérica não é um limite arbitrário de temperatura ou pressão do processo. `id` é inteiro positivo, único por conexão. A Pi só confirma alterações após ACK e não repete comandos de atuação automaticamente após timeout.

## Operações

| op | Campos | Regra |
|---|---|---|
| get_state | nenhum | solicita telemetria imediata |
| setpoints | temperature (°C), pressure (Pa diferencial; alvo de P6) | operador no automático; ADMIN em ambos os modos |
| manual_unlock | nenhum | a Pi envia somente após autenticar um administrador; habilita comandos manuais no Mega |
| mode | value: auto/manual | manual exige manual_unlock; auto limpa autorização manual |
| outputs | fans: [0..255,0..255,0..255], fan_power: bool, peltier: 0 ou 255 | somente manual autorizado; PWM independente, alimentação única compartilhada, sem intertravamento ou timeout |
| pid | loop: pressure, kp, ki, kd (não negativos) | somente manual autorizado |
| calibrate | channel: 0..6, offset (contagens), scale (Pa/contagem, não zero) | somente manual autorizado |
| temperature_address | channel: 0..5, address: 16 dígitos hex (ROM DS18B20), swap: bool opcional | somente manual autorizado; fixa identidade física dos seis canais |
| tach | channel: 0..2, pulses_per_rev: inteiro 1..255 | somente manual autorizado; configura pulsos por volta do tacômetro |
| save | nenhum | somente manual autorizado; persiste setpoints, PID, calibração, ROMs e pulsos/volta em EEPROM; saídas/modo/sessão não são persistidos |

Índice de ventoinhas: 0 = Delta exaustão 1; 1 = Delta exaustão 2; 2 = NMB insuflamento. Exemplo manual: `{"v":2,"type":"command","id":2,"op":"outputs","fans":[90,130,200],"fan_power":true,"peltier":255}`. Esse vetor é permitido no manual; não se impõe relação entre PWMs nesse modo.

`fan_power` é um único booleano. O único IRF4905 acionado por D4 alimenta as três ventoinhas juntas. Não existe comando para desligar a alimentação de apenas uma delas; implementar isso exigiria três estágios de potência independentes. PWM zero não comprova desligamento mecânico de uma ventoinha.

No automático, as duas exaustoras têm PWM estritamente maior que o insuflamento e `fan_power` fica verdadeiro. Isso não é uma garantia de pressão negativa: o PID usa a pressão diferencial medida em **P6**, e o desempenho precisa ser verificado fisicamente. Renomear ou mover um ambiente na planta não muda o canal do PID.

## Telemetria

Publicada a 1 Hz, além de `get_state`:

```json
{"v":2,"hardware":"NB3","type":"telemetry","seq":1,"ms":1000,"mode":"auto","manual_authorized":false,"temperatures":[22,22,22,22,22,22],"pressures":[0,0,0,0,0,0,0],"differentials":[0,0,0,0,0,0],"raw_pressures":[100,100,100,100,100,100,100],"calibrated":[true,true,true,true,true,true,true],"temperature_addresses":["2800000000000001","2800000000000002","2800000000000003","2800000000000004","2800000000000005","2800000000000006"],"temp_mean":22,"setpoints":{"temperature":22,"pressure":-10},"fans":[128,128,64],"fan_power":true,"fan_rpm":[1800,1800,1200],"tach_ppr":[2,2,2],"peltier":0,"peltier_control":"on_off","pid":{"pressure":{"kp":4,"ki":0.2,"kd":0},"temperature":{"kp":10,"ki":0.1,"kd":0}}}
```

Valores inválidos/desconectados/não calibrados são `null`, nunca zero fabricado. `temperatures` e `differentials` têm 6 itens; `pressures`, `raw_pressures`, `calibrated` têm 7 (último = P7/ambiente). `temperature_addresses` tem 6 ROMs configuradas, string vazia para canais ainda não associados. O firmware também envia `calibration` (7 objetos com `offset` e `scale`) e `discovered_addresses` (ROMs detectadas na inicialização).

`pressures[i] = (raw-offset)*scale`; `differentials[i] = pressures[i]-pressures[6]`. Os sete sensores MPS são diferenciais; a interpretação dessa subtração depende das referências pneumáticas reais. Módulos já ligados diretamente entre sala e ambiente exigem revisão da fórmula para não subtrair ambiente duas vezes. O sétimo módulo não é um barômetro absoluto.

`fan_rpm` contém três números não negativos ou `null` enquanto não há uma janela de medição válida. `tach_ppr` contém três inteiros de 1 a 255. O valor inicial de 2 pulsos por volta é provisório e precisa ser confirmado na documentação/medição de cada ventoinha. RPM zero depois de uma janela sem pulsos significa ausência de pulsos detectados: não comprova motor desligado, pois fio, pull-up ou ajuste de pulsos podem estar incorretos. O RPM é monitoramento e não acrescenta um intertravamento.

A média térmica só é válida com os seis sensores válidos. PID pressão usa erro `medida_P6 - setpoint`: erro positivo aumenta exaustão. O Peltier é montado para **resfriar** o ar e opera em Liga/Desliga: liga se `média > setpoint + 0,5°C`, desliga se `média <= setpoint` e mantém a saída dentro da banda. Sem medida válida, conserva o esforço calculado anteriormente (nenhum intertravamento adicional); telemetria/alarmes sinalizam a falha. O PWM enviado é esforço lógico 0..255; o firmware faz a inversão elétrica devida ao BC548 no sinal PWM.

## Identificação e persistência

P1..P6 são identificadores de canais físicos. A associação confirmada é: **P1 Paramentação; P2 Desparamentação; P3 Corredor Central; P4 Sala de Autoclave; P5 Laboratório 1; P6 Laboratório 2**. O PID de pressão usa sempre **P6/Laboratório 2**. Renomear um ambiente na interface não muda essa referência física. As ROMs dos seis DS18B20 também precisam ser associadas aos canais correspondentes.

O layout EEPROM NB3 é a versão 2. Um registro da versão anterior não é reutilizado: o firmware carrega os valores iniciais, exigindo recadastrar/conferir calibrações, ROMs, PID, setpoints e pulsos por volta e então executar `save`. A gravação é explícita e o ACK de `save` só confirma depois de concluída.

Sem ACK, não presumir sucesso; mudanças não são reenviadas automaticamente. Telemetria continua sendo a fonte do estado real. Na abertura/reconexão a Pi envia apenas `get_state`: nunca reaplica comandos antigos nem assume sessão ADMIN a partir do estado do Arduino.

## Peltier a partir da versão 0.4.0

O campo `peltier` conserva os códigos 0 (Desligado) e 255 (Ligado) para compatibilidade do JSONL v2; os valores intermediários são rejeitados em comandos, sem alteração parcial dos ventiladores. D5 usa escrita digital, sem PWM. A telemetria inclui `peltier_control: "on_off"`. A Pi continua aceitando a telemetria antiga sem esse campo, inclusive registros PWM, e indica quando é necessário atualizar o Arduino. O comando PID térmico é rejeitado pelo firmware novo. O objeto `pid.temperature` e seus campos na EEPROM são mantidos como dados legados, sem atuação, preservando o layout/CRC e as calibrações da EEPROM v2. O CSV mantém suas colunas anteriores; novas amostras do Peltier usam apenas 0 e 255.

## Associação de temperatura na versão 0.5.0

Na partida, o Mega procura ROMs válidas do tipo DS18B20 e distribui os sensores não utilizados, em ordem pseudoaleatória, somente entre as salas ainda sem associação válida. ROMs já configuradas são preservadas inclusive quando não são encontradas no barramento. Não há sorteio a cada reconexão e não há associação de um sensor a duas salas. Se a distribuição acrescentar sensores, a configuração é gravada cooperativamente em EEPROM v2, uma vez, sem emitir ACK de comando com id zero. A estrutura e os coeficientes de calibração existentes são preservados. A telemetria inclui `temperature_auto_assignment: true` para identificar esse recurso.

`temperature_address` conserva o comportamento anterior quando `swap` está ausente ou falso: duplicações são rejeitadas. Com `swap: true`, escolher um endereço de outra sala troca os dois vínculos atomicamente. Ambas as temperaturas são invalidadas até a próxima leitura real; a alteração só é persistida após `save`. A interface 0.5.0 usa esse modo para facilitar a correção física posterior. Autenticação ADMIN e modo manual continuam obrigatórios para o comando.
