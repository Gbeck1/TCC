import json

import pytest

from tcc_monitor.transport import decode_message


def encode(message):
    return (json.dumps(message, separators=(",", ":")) + "\n").encode("utf-8")


def test_decodes_complete_telemetry_and_missing_sensor(telemetry):
    telemetry["temperatures"][3] = None
    telemetry["temp_mean"] = None
    decoded = decode_message(encode(telemetry))
    assert decoded["temperatures"][3] is None
    assert decoded["temp_mean"] is None
    assert decoded["pressures"][6] == 0.0


@pytest.mark.parametrize(
    "field,value",
    [
        ("temperatures", [22] * 5),
        ("pressures", [0] * 6),
        ("differentials", [0] * 7),
        ("temperatures", [True] + [22] * 5),
        ("temperatures", [float("nan")] + [22] * 5),
        ("fans", [0, 0, 256]),
        ("fan_power", [1, True, True]),
        ("fan_power", [True, True, True]),
        ("fan_power", 1),
        ("fan_rpm", [1000, 2000]),
        ("fan_rpm", [1000, -1, 2000]),
        ("fan_rpm", [1000, float("inf"), 2000]),
        ("fan_rpm", [1000, True, 2000]),
        ("tach_ppr", [2, 2]),
        ("tach_ppr", [0, 2, 2]),
        ("tach_ppr", [2, 256, 2]),
        ("tach_ppr", [2, 2.5, 2]),
        ("tach_ppr", [2, True, 2]),
        ("hardware", "OTHER"),
        ("mode", "unexpected"),
        ("v", 1),
    ],
)
def test_rejects_malformed_telemetry(telemetry, field, value):
    telemetry[field] = value
    with pytest.raises(ValueError):
        decode_message(encode(telemetry))


@pytest.mark.parametrize("line", [b"", b"not-json\n", b"[]\n", b"\xff\n", b'{"v":2,"type":"unknown"}\n'])
def test_rejects_invalid_frames(line):
    with pytest.raises(ValueError):
        decode_message(line)


def test_ack_is_typed_and_id_is_preserved():
    decoded = decode_message(encode({"v": 2, "type": "ack", "id": 42, "ok": False, "error": "manual_only"}))
    assert decoded["id"] == 42
    assert decoded["ok"] is False
    assert decoded["error"] == "manual_only"


@pytest.mark.parametrize("field", ["hardware", "fan_rpm", "tach_ppr"])
def test_rejects_incomplete_nb3_telemetry(telemetry, field):
    del telemetry[field]
    with pytest.raises(ValueError):
        decode_message(encode(telemetry))


def test_stopped_and_unavailable_rpm_are_distinct(telemetry):
    telemetry["fan_rpm"] = [0, None, 1234.5]
    decoded = decode_message(encode(telemetry))
    assert decoded["fan_rpm"] == [0, None, 1234.5]


def test_rejects_v1_ack_after_protocol_migration():
    with pytest.raises(ValueError):
        decode_message(encode({"v": 1, "type": "ack", "id": 1, "ok": True}))


@pytest.mark.parametrize("ack", [
    {"v": 2, "type": "ack", "id": 0, "ok": True},
    {"v": 2, "type": "ack", "id": 1, "ok": 1},
    {"v": 2, "type": "ack", "id": True, "ok": True},
])
def test_rejects_invalid_ack_fields(ack):
    with pytest.raises(ValueError):
        decode_message(encode(ack))
