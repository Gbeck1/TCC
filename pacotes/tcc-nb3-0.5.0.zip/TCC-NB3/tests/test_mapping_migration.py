"""NB3 room placement changes presentation, never physical sensor identity."""

import copy
import csv
import hashlib
import json
import sqlite3

import pytest

from tcc_monitor.storage import Store


CONFIRMED_MAPPING = {
    1: "gowning",
    2: "degowning",
    3: "corridor",
    4: "autoclave",
    5: "laboratory_1",
    6: "laboratory_2",
}


def remapped():
    mapping = CONFIRMED_MAPPING.copy()
    mapping[1], mapping[6] = mapping[6], mapping[1]
    return mapping


def test_new_database_uses_confirmed_physical_locations(tmp_path):
    store = Store(tmp_path)
    try:
        rooms = store.rooms()
        assert {room["id"]: room["location"] for room in rooms} == CONFIRMED_MAPPING
        assert all(room["mapping_confirmed"] for room in rooms)
        assert all(room["name"] != f"Sala {room['id']}" for room in rooms)
    finally:
        store.close()


def test_reassigning_rooms_preserves_history_by_source_channel(tmp_path, telemetry):
    store = Store(tmp_path)
    telemetry["temperatures"] = [21.0, 22.0, 23.0, 24.0, 25.0, 26.0]
    telemetry["differentials"] = [-1.0, -2.0, -3.0, -4.0, -5.0, -6.0]
    store.record(telemetry)
    before = {channel: store.history(channel) for channel in range(1, 7)}
    try:
        store.assign_rooms(remapped(), confirmed=True)
        assert {room["id"]: room["location"] for room in store.rooms()} == remapped()
        assert {channel: store.history(channel) for channel in range(1, 7)} == before
    finally:
        store.close()
    reopened = Store(tmp_path)
    try:
        assert {room["id"]: room["location"] for room in reopened.rooms()} == remapped()
        assert all(room["mapping_confirmed"] for room in reopened.rooms())
        assert reopened.history(6)[0]["temperature"] == 26.0
        assert reopened.history(1)[0]["pressure"] == -1.0
    finally:
        reopened.close()


@pytest.mark.parametrize("mapping", [
    {key: value for key, value in CONFIRMED_MAPPING.items() if key != 6},
    {**CONFIRMED_MAPPING, 6: "gowning"},
    {**CONFIRMED_MAPPING, 6: "unknown"},
    {**CONFIRMED_MAPPING, 7: "laboratory_2"},
    {str(key): value for key, value in CONFIRMED_MAPPING.items()},
])
def test_invalid_room_assignment_has_no_partial_effect(tmp_path, mapping):
    store = Store(tmp_path)
    try:
        before = store.rooms()
        with pytest.raises(ValueError):
            store.assign_rooms(mapping, confirmed=True)
        assert store.rooms() == before
    finally:
        store.close()


def make_legacy_database(path, telemetry, powers):
    """Construct the previous shipped schema, without invoking v2 migrations."""
    snapshot = copy.deepcopy(telemetry)
    snapshot["v"] = 1
    snapshot["fan_power"] = powers
    for field in ("hardware", "fan_rpm", "tach_ppr"):
        snapshot.pop(field, None)
    snapshot["temperatures"] = [21.0, 22.0, 23.0, 24.0, 25.0, 26.0]
    snapshot["differentials"] = [-1.0, -2.0, -3.0, -4.0, -5.0, -6.0]
    payload = json.dumps(snapshot, separators=(",", ":"))
    salt = "0102030405060708090a0b0c0d0e0f10"
    digest = hashlib.pbkdf2_hmac("sha256", b"legacy-password", bytes.fromhex(salt), 260000).hex()
    encoded = f"pbkdf2_sha256$260000${salt}${digest}"
    with sqlite3.connect(path / "monitor.sqlite3") as db:
        db.executescript("""
            CREATE TABLE users (username TEXT PRIMARY KEY, password TEXT NOT NULL, role TEXT NOT NULL);
            CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT);
            INSERT INTO metadata VALUES ('initialized','1');
            CREATE TABLE rooms (
              id INTEGER PRIMARY KEY, name TEXT NOT NULL,
              temp_min REAL NOT NULL, temp_max REAL NOT NULL,
              pressure_min REAL NOT NULL, pressure_max REAL NOT NULL);
            CREATE TABLE samples (id INTEGER PRIMARY KEY, timestamp REAL NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE alarms (
              id INTEGER PRIMARY KEY, timestamp REAL NOT NULL, room_id INTEGER NOT NULL,
              room_name TEXT NOT NULL, parameter TEXT NOT NULL, message TEXT NOT NULL, active INTEGER NOT NULL);
            INSERT INTO alarms VALUES (1,1700000000,6,'Nome histórico','temperatura','Evento anterior',1);
        """)
        db.execute("INSERT INTO users VALUES (?,?,?)", ("ADMIN", encoded, "admin"))
        for room in range(1, 7):
            name = "Nome personalizado" if room == 3 else f"Sala {room}"
            db.execute("INSERT INTO rooms VALUES (?,?,?,?,?,?)", (room, name, 18.0, 28.0, -30.0, -1.0))
        db.execute("INSERT INTO samples VALUES (1,?,?)", (1700000000.5, payload))
    return payload


def test_legacy_schema_migration_preserves_credentials_history_and_custom_names(tmp_path, telemetry):
    payload = make_legacy_database(tmp_path, telemetry, [True, True, True])
    store = Store(tmp_path)
    try:
        assert store.authenticate("ADMIN", "legacy-password") == "admin"
        assert store.authenticate("ADMIN", "15234") is None
        rooms = store.rooms()
        assert {room["id"]: room["location"] for room in rooms} == CONFIRMED_MAPPING
        assert all(room["mapping_confirmed"] for room in rooms)
        assert rooms[2]["name"] == "Nome personalizado"
        assert all(room["name"] != f"Sala {room['id']}" for room in rooms)
        assert store.history(6)[0] == {"timestamp": 1700000000.5, "temperature": 26.0, "pressure": -6.0}
        assert store.alarm_log()[0]["room_name"] == "Nome histórico"
        with sqlite3.connect(tmp_path / "monitor.sqlite3") as db:
            assert db.execute("SELECT payload FROM samples WHERE id=1").fetchone()[0] == payload
    finally:
        store.close()
    reopened = Store(tmp_path)
    try:
        assert reopened.rooms()[2]["name"] == "Nome personalizado"
        assert reopened.authenticate("ADMIN", "legacy-password") == "admin"
        assert reopened.history(6)[0]["temperature"] == 26.0
    finally:
        reopened.close()


@pytest.mark.parametrize("legacy_power,expected", [
    ([True, True, True], "True"),
    ([False, False, False], "False"),
    ([False, True, True], ""),
])
def test_legacy_csv_does_not_invent_rpm_or_collapse_mixed_power(tmp_path, telemetry, legacy_power, expected):
    make_legacy_database(tmp_path, telemetry, legacy_power)
    store = Store(tmp_path)
    csv_path = tmp_path / "legacy.csv"
    try:
        assert store.export_csv(csv_path) == 1
    finally:
        store.close()
    with csv_path.open(encoding="utf-8-sig", newline="") as file:
        row = next(csv.DictReader(file))
    assert row["fans_power"] == expected
    assert [row[f"fan_{i}_rpm"] for i in range(1, 4)] == ["", "", ""]
    assert [row[f"tach_{i}_ppr"] for i in range(1, 4)] == ["", "", ""]
    assert row["room_6_temperature_c"] == "26.0"
