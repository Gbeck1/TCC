"""Exercise the application boundary used by the touch interface."""

import time

import pytest

from tcc_monitor.service import AppError, MonitorService


def eventually(predicate, timeout=4.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.02)
    assert predicate(), "The simulator did not publish the expected state"


@pytest.fixture
def service(tmp_path):
    instance = MonitorService(data_dir=tmp_path, demo=True)
    instance.start()
    eventually(lambda: instance.snapshot is not None)
    try:
        yield instance
    finally:
        instance.close()


def enter_manual(service):
    service.login("ADMIN", "15234")
    service.set_mode("manual")
    eventually(lambda: service.snapshot["mode"] == "manual")


def test_calibration_and_save_return_ids_for_confirmed_actions(service):
    enter_manual(service)
    service.drain_events()
    calibration_id = service.calibrate(0, 1234.0, 0.002)
    save_id = service.save_controller()
    assert type(calibration_id) is int and type(save_id) is int
    assert 0 < calibration_id < save_id
    events = []

    def both_confirmed():
        events.extend(service.drain_events())
        ids = {event["id"] for event in events if event["type"] == "ack" and event["ok"]}
        return {calibration_id, save_id} <= ids

    eventually(both_confirmed)
    assert service.snapshot["calibration"][0] == {"offset": 1234.0, "scale": 0.002}


def test_calibration_timeout_identifies_the_unconfirmed_action(service):
    enter_manual(service)
    service.drain_events()
    service.transport.send = lambda command: None
    service.ACK_TIMEOUT = 0.01
    command_id = service.calibrate(0, 10, 0.01)
    service._on_event({"type": "command_sent", "id": command_id})
    time.sleep(0.03)
    service._on_event({"type": "tick"})
    errors = [event for event in service.drain_events() if event["type"] == "error"]
    assert any(event.get("id") == command_id and event.get("op") == "calibrate" for event in errors)


def test_operator_cannot_enable_manual_or_send_actuator_commands(service):
    assert not service.admin
    with pytest.raises(AppError):
        service.set_mode("manual")
    with pytest.raises(AppError):
        service.outputs([0, 0, 255], True, 255)
    with pytest.raises(AppError):
        service.set_pid("pressure", 1, 0, 0)
    with pytest.raises(AppError):
        service.add_user("extra", "password", "admin")
    service.setpoints(20.0, -18.0)
    eventually(lambda: service.snapshot["setpoints"] == {"temperature": 20.0, "pressure": -18.0})


def test_admin_must_enter_manual_before_direct_control(service):
    service.login("ADMIN", "15234")
    assert service.admin
    with pytest.raises(AppError):
        service.outputs([0, 0, 255], True, 255)
    with pytest.raises(AppError):
        service.calibrate(0, 0, 0.001)
    with pytest.raises(AppError):
        service.set_tach(0, 2)


def test_manual_independence_and_logout_leave_outputs_unchanged(service):
    enter_manual(service)
    service.outputs([0, 3, 255], True, 255)
    eventually(lambda: service.snapshot["fans"] == [0, 3, 255] and service.snapshot["peltier"] == 255)
    service.logout()
    assert not service.admin
    with pytest.raises(AppError):
        service.outputs([1, 1, 1], True, 0)
    # More than one telemetry cycle: logout must not enqueue an automatic reset.
    seq = service.snapshot["seq"]
    eventually(lambda: service.snapshot["seq"] > seq)
    assert service.snapshot["mode"] == "manual"
    assert service.snapshot["fans"] == [0, 3, 255]
    assert service.snapshot["fan_power"] is True
    assert service.snapshot["peltier"] == 255


def test_wrong_password_does_not_authorize_and_users_remain_private(service):
    with pytest.raises(AppError):
        service.login("ADMIN", "wrong")
    assert not service.admin
    service.login("ADMIN", "15234")
    service.add_user("ANA", "senha-de-teste", "operator")
    users = service.users()
    assert any(user["username"] == "ANA" and user["role"] == "operator" for user in users)
    assert all(set(user).isdisjoint({"password", "password_hash", "hash", "salt"}) for user in users)
    service.logout()
    service.login("ANA", "senha-de-teste")
    assert service.username == "ANA"
    assert not service.admin
    with pytest.raises(AppError):
        service.change_password("ADMIN", "replacement")


def test_password_change_and_room_configuration_persist(tmp_path):
    first = MonitorService(data_dir=tmp_path, demo=True)
    first.start()
    try:
        first.login("ADMIN", "15234")
        first.change_password("ADMIN", "nova-senha-15234")
        first.update_room(6, "Sala mais negativa", 18.0, 29.0, -30.0, -1.0)
    finally:
        first.close()
    second = MonitorService(data_dir=tmp_path, demo=True)
    second.start()
    try:
        with pytest.raises(AppError):
            second.login("ADMIN", "15234")
        second.login("ADMIN", "nova-senha-15234")
        assert second.admin
        room = next(room for room in second.rooms() if room["id"] == 6)
        assert room["name"] == "Sala mais negativa"
        assert room["temp_min"] == 18.0
        assert room["pressure_max"] == -1.0
    finally:
        second.close()


def test_tach_and_common_power_controls_round_trip_through_service(service):
    with pytest.raises(AppError):
        service.set_tach(0, 4)
    enter_manual(service)
    with pytest.raises(AppError):
        service.outputs([20, 30, 255], [False, True, True], 100)
    service.set_tach(2, 4)
    eventually(lambda: service.snapshot["tach_ppr"][2] == 4)
    service.outputs([20, 30, 255], False, 255)
    eventually(lambda: service.snapshot["fan_power"] is False)
    assert service.snapshot["fans"] == [20, 30, 255]
    assert service.snapshot["peltier"] == 255


def test_room_mapping_confirmation_is_explicit_and_persistent(tmp_path):
    mapping = {1: "laboratory_1", 2: "laboratory_2", 3: "corridor",
               4: "autoclave", 5: "gowning", 6: "degowning"}
    service = MonitorService(data_dir=tmp_path, demo=True)
    try:
        service.assign_rooms(mapping, confirmed=False)
        assert {room["id"]: room["location"] for room in service.rooms()} == mapping
        assert not any(room["mapping_confirmed"] for room in service.rooms())
    finally:
        service.close()
    reopened = MonitorService(data_dir=tmp_path, demo=True)
    try:
        assert {room["id"]: room["location"] for room in reopened.rooms()} == mapping
        assert not any(room["mapping_confirmed"] for room in reopened.rooms())
        reopened.assign_rooms(mapping, confirmed=True)
        assert all(room["mapping_confirmed"] for room in reopened.rooms())
    finally:
        reopened.close()
