import copy

import pytest

from tcc_monitor.simulator import SimulatedController
from tcc_monitor.transport import decode_message
from tcc_monitor.validation import peltier_switch
import json


def test_cooling_switch_keeps_state_in_hysteresis_band_and_stops_at_target():
    controller = SimulatedController()
    for temperature, expected in [(22.5, 0), (22.51, 255), (22.3, 255),
                                  (22, 0), (22.3, 0), (23, 255), (21, 0)]:
        controller.temperature = [temperature] * 6
        controller._control(.1)
        assert controller.peltier == expected
        assert controller.telemetry()["peltier_control"] == "on_off"


@pytest.mark.parametrize("missing", [None, float("nan"), float("inf"), True])
@pytest.mark.parametrize("previous", [0, 255])
def test_invalid_temperature_preserves_last_output_without_a_shutdown_interlock(missing, previous):
    controller = SimulatedController()
    controller.peltier = previous
    controller.temperature = [20] * 5 + [missing]
    controller._control(.1)
    assert controller.peltier == previous
    assert controller.telemetry()["temp_mean"] is None


@pytest.mark.parametrize("value", [1, 128, 254, True, False, 255.0, None])
def test_switch_rejects_intermediate_or_wrongly_typed_commands(value):
    with pytest.raises(ValueError):
        peltier_switch(value)


def test_decoder_accepts_legacy_pwm_telemetry_but_validates_new_on_off_firmware(telemetry):
    legacy = copy.deepcopy(telemetry)
    legacy["peltier"] = 128
    assert decode_message(json.dumps(legacy).encode())["peltier"] == 128
    legacy["peltier_control"] = "on_off"
    with pytest.raises(ValueError):
        decode_message(json.dumps(legacy).encode())
    for output in (0, 255):
        legacy["peltier"] = output
        assert decode_message(json.dumps(legacy).encode())["peltier"] == output
