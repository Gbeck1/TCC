import copy
import csv
import sqlite3

import pytest

from tcc_monitor.storage import Store


@pytest.fixture
def store(tmp_path):
    instance = Store(tmp_path)
    try:
        yield instance
    finally:
        instance.close()


def test_users_are_salted_and_changed_password_survives_reopen(tmp_path):
    store = Store(tmp_path)
    assert store.authenticate("ADMIN", "15234") == "admin"
    assert store.authenticate("ADMIN", "wrong") is None
    store.add_user("operator", "15234", "operator")
    with sqlite3.connect(tmp_path / "monitor.sqlite3") as db:
        encoded = [row[0] for row in db.execute("SELECT password FROM users")]
    assert all(password != "15234" and password.startswith("pbkdf2_sha256$") for password in encoded)
    assert len(set(encoded)) == 2
    store.change_password("ADMIN", "new-password")
    store.close()
    reopened = Store(tmp_path)
    try:
        assert reopened.authenticate("ADMIN", "15234") is None
        assert reopened.authenticate("ADMIN", "new-password") == "admin"
        assert reopened.authenticate("operator", "15234") == "operator"
    finally:
        reopened.close()


def test_alarm_log_records_transitions_and_missing_sensor(store, telemetry):
    store.record(telemetry)
    assert store.alarm_log() == []
    hot = copy.deepcopy(telemetry)
    hot["temperatures"][0] = 35.0
    store.record(hot)
    alarms = store.alarm_log()
    assert len(alarms) == 1
    assert alarms[0]["room_id"] == 1
    assert alarms[0]["parameter"] == "temperatura"
    assert alarms[0]["active"]
    store.record(hot)
    assert len(store.alarm_log()) == 1
    missing = copy.deepcopy(telemetry)
    missing["temperatures"][0] = None
    missing["temp_mean"] = None
    store.record(missing)
    alarms = store.alarm_log()
    assert len(alarms) == 3  # High recovered, sensor fault activated.
    assert sum(bool(alarm["active"]) for alarm in alarms) == 2
    store.record(telemetry)
    alarms = store.alarm_log()
    assert len(alarms) == 4
    assert not alarms[0]["active"]


def test_reference_sensor_failure_has_an_ambient_alarm(store, telemetry):
    telemetry["pressures"][6] = None
    telemetry["differentials"] = [None] * 6
    store.record(telemetry)
    alarms = store.alarm_log()
    assert len(alarms) == 7
    assert any(alarm["room_id"] == 0 and alarm["room_name"] == "Ambiente" for alarm in alarms)


def test_history_preserves_missing_values_and_chronological_order(store, telemetry):
    for number in range(5):
        sample = copy.deepcopy(telemetry)
        sample["seq"] = number
        sample["temperatures"][5] = 20.0 + number if number != 3 else None
        store.record(sample)
    history = store.history(6, limit=3)
    assert [sample["temperature"] for sample in history] == [22.0, None, 24.0]
    assert [sample["timestamp"] for sample in history] == sorted(sample["timestamp"] for sample in history)
    assert all(sample["pressure"] == -10.0 for sample in history)


def test_csv_exports_all_sensors_outputs_and_setpoints(store, telemetry, tmp_path):
    telemetry["temperatures"][4] = None
    telemetry["temp_mean"] = None
    telemetry["peltier"] = 72
    store.record(telemetry)
    csv_path = tmp_path / "sensors.csv"
    assert store.export_csv(csv_path) == 1
    with csv_path.open(encoding="utf-8-sig", newline="") as file:
        rows = list(csv.DictReader(file))
    assert len(rows) == 1
    row = rows[0]
    assert row["room_5_temperature_c"] == ""
    assert row["channel_7_pressure_pa"] == "0.0"
    assert row["room_6_differential_pa"] == "-10.0"
    assert row["fan_3_pwm"] == "64"
    assert row["fans_power"] == "True"
    assert row["fan_1_rpm"] == "1800.0"
    assert row["fan_2_rpm"] == "1850.0"
    assert row["fan_3_rpm"] == "1200.0"
    assert [row[f"tach_{i}_ppr"] for i in range(1, 4)] == ["2", "2", "2"]
    assert not any(f"fan_{i}_power" in row for i in range(1, 4))
    assert row["peltier_pwm"] == "72"
    assert row["pressure_setpoint_pa"] == "-10.0"
    assert row["pid_pressure_ki"] == "0.2"
    assert row["timestamp_utc"].endswith("+00:00")


def test_room_limits_validate_without_partial_update(store):
    original = store.rooms()[0]
    with pytest.raises(ValueError):
        store.update_room(1, "Invalid", 30, 20, -30, -1)
    assert store.rooms()[0] == original
    store.update_room(1, "Sala azul", 17.5, 30.5, -50, -2)
    room = store.rooms()[0]
    assert room["name"] == "Sala azul"
    assert room["pressure_min"] == -50


def test_deleting_other_users_keeps_authentication_state_consistent(store):
    store.add_user("technician", "pw", "operator")
    assert store.authenticate("technician", "pw") == "operator"
    store.delete_user("technician")
    assert store.authenticate("technician", "pw") is None
    assert not any(user["username"] == "technician" for user in store.users())
