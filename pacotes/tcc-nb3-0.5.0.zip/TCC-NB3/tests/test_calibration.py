"""Coeficientes de pressão calculados a partir de referências medidas."""

import math
import struct

import pytest

from tcc_monitor.calibration import calibration_from_points, zero_calibration


def float32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


@pytest.mark.parametrize(
    ("raw_a", "pressure_a", "raw_b", "pressure_b", "offset", "scale"),
    [
        (100, 0, 1100, 100, 100, 0.1),
        (1100, 100, 100, 0, 100, 0.1),
        (100, 0, 1100, -100, 100, -0.1),
        (-1000, -20, 1000, 20, 0, 0.02),
        (100, 20, 1100, 120, -100, 0.1),
        (10.25, 5, 30.75, -5, 20.5, -10 / 20.5),
    ],
)
def test_two_known_points_define_offset_and_signed_scale(
    raw_a, pressure_a, raw_b, pressure_b, offset, scale
):
    result = calibration_from_points(raw_a, pressure_a, raw_b, pressure_b)
    assert result == pytest.approx({"offset": offset, "scale": scale})
    assert all(type(value) is float for value in result.values())
    for raw, pressure in ((raw_a, pressure_a), (raw_b, pressure_b)):
        assert (raw - result["offset"]) * result["scale"] == pytest.approx(pressure)


@pytest.mark.parametrize("scale", [0.025, -0.025])
@pytest.mark.parametrize("reference", [0, 12.5, -12.5])
def test_zeroing_preserves_scale_at_zero_or_nonzero_reference(scale, reference):
    result = zero_calibration(1234.5, scale, reference)
    assert result["scale"] == scale
    assert all(type(value) is float for value in result.values())
    assert (1234.5 - result["offset"]) * result["scale"] == pytest.approx(reference)


def test_zeroing_defaults_to_zero_pressure():
    assert zero_calibration(-123, -0.1) == {"offset": -123.0, "scale": -0.1}


@pytest.mark.parametrize("raw", [-8388608, 8388607])
def test_adc_endpoints_are_valid_but_do_not_expand_the_signed_24_bit_domain(raw):
    result = zero_calibration(raw, 0.01)
    assert result["offset"] == raw


def test_two_point_calibration_accepts_full_adc_range():
    result = calibration_from_points(-8388608, -10, 8388607, 10)
    assert result["scale"] > 0
    for raw, pressure in ((-8388608, -10), (8388607, 10)):
        assert (raw - result["offset"]) * result["scale"] == pytest.approx(pressure)


@pytest.mark.parametrize(
    "points",
    [
        (123456.25, -12.3, 234567.75, 45.6),
        (8388600.25, -10, 8388601.25, -20),
        (-34567.75, 200, 45678.25, -30),
    ],
)
def test_known_references_are_restored_with_float32_coefficient_tolerance(points):
    result = calibration_from_points(*points)
    offset, scale = float32(result["offset"]), float32(result["scale"])
    # The MCU rounds each operation to float32. The tolerance includes the
    # offset quantization in raw counts and the scale's relative precision.
    for raw, pressure in zip(points[::2], points[1::2]):
        predicted = float32(float32(float32(raw) - offset) * scale)
        tolerance = (
            abs(scale) * (abs(raw) + abs(offset)) * 2**-23
            + abs(pressure) * 2**-22
            + 1e-6
        )
        assert predicted == pytest.approx(pressure, abs=tolerance)


@pytest.mark.parametrize(
    "bad", [True, False, None, "100", [], {}, math.nan, math.inf, -math.inf, 10**1000]
)
@pytest.mark.parametrize("argument", range(4))
def test_two_point_calibration_rejects_non_numeric_or_nonfinite_inputs(bad, argument):
    arguments = [100, 0, 200, 10]
    arguments[argument] = bad
    with pytest.raises(ValueError):
        calibration_from_points(*arguments)


@pytest.mark.parametrize(
    "bad", [True, False, None, "100", [], {}, math.nan, math.inf, -math.inf, 10**1000]
)
@pytest.mark.parametrize("argument", range(3))
def test_zeroing_rejects_non_numeric_or_nonfinite_inputs(bad, argument):
    arguments = [100, 0.01, 0]
    arguments[argument] = bad
    with pytest.raises(ValueError):
        zero_calibration(*arguments)


@pytest.mark.parametrize("raw", [-8388609, 8388608, -8388608.01, 8388607.01])
def test_raw_outside_adc_domain_is_rejected(raw):
    with pytest.raises(ValueError):
        zero_calibration(raw, 1)
    with pytest.raises(ValueError):
        calibration_from_points(raw, 0, 100, 10)
    with pytest.raises(ValueError):
        calibration_from_points(100, 0, raw, 10)


@pytest.mark.parametrize("points", [(100, 0, 100, 10), (100, 10, 200, 10)])
def test_two_points_require_distinct_raw_counts_and_reference_pressures(points):
    with pytest.raises(ValueError):
        calibration_from_points(*points)


@pytest.mark.parametrize(
    "points",
    [
        (0, 0, 1e-10, 1e38),  # Scale overflows float32.
        (0, -3e38, 1, 3e38),  # Difference overflows float32.
        (0, 0, 5e-324, 1),  # Division overflows Python float.
        (0, 0, 1, 1e-50),  # Scale rounds to zero in float32.
        (0, 0, 8388607, 5e-324),  # Division underflows to zero.
    ],
)
def test_unrepresentable_two_point_scales_are_rejected(points):
    with pytest.raises(ValueError):
        calibration_from_points(*points)


@pytest.mark.parametrize("scale", [0, -0.0, 1e39, -1e39, 1e-50, -1e-50])
def test_zeroing_rejects_zero_or_unrepresentable_scale(scale):
    with pytest.raises(ValueError):
        zero_calibration(100, scale)


@pytest.mark.parametrize("reference", [1, -1, 1e38])
def test_zeroing_rejects_offset_overflow_on_the_mega(reference):
    with pytest.raises(ValueError):
        zero_calibration(100, 1e-39, reference)


def test_smallest_nonzero_float32_scale_is_preserved():
    scale = float32(2**-149)
    assert zero_calibration(100, scale)["scale"] == scale


def test_no_implicit_quantization_changes_the_provided_scale_or_raw_mean():
    scale = 0.123456789123
    raw_mean = 8388600.25
    result = zero_calibration(raw_mean, scale)
    assert result == {"offset": raw_mean, "scale": scale}
    assert result["scale"] != float32(scale)
    assert result["offset"] != float32(raw_mean)


@pytest.mark.parametrize("sign", [1, -1])
def test_references_must_fit_float32_even_when_the_two_point_coefficients_do(sign):
    pressure_a = sign * 1e40
    pressure_b = pressure_a + sign * 1e30
    scale = (pressure_b - pressure_a) / 100
    offset = 100 - pressure_a / scale
    assert math.isfinite(float32(scale))
    assert math.isfinite(float32(offset))
    with pytest.raises(ValueError, match="32 bits"):
        calibration_from_points(100, pressure_a, 200, pressure_b)


@pytest.mark.parametrize("reference", [1e40, -1e40])
def test_zero_reference_must_fit_float32_even_when_its_offset_does(reference):
    assert math.isfinite(float32(100 - reference / 1e10))
    with pytest.raises(ValueError, match="32 bits"):
        zero_calibration(100, 1e10, reference)


def test_large_representable_pressure_references_do_not_have_arbitrary_process_limits():
    result = calibration_from_points(100, 1e38, 200, 1.1e38)
    assert result == pytest.approx({"offset": -900.0, "scale": 1e35})
