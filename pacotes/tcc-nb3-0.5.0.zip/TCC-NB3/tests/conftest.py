"""Shared protocol fixtures independent of physical hardware."""

import sys
from pathlib import Path

import pytest


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "raspberry"))


@pytest.fixture
def telemetry():
    return {
        "v": 2,
        "type": "telemetry",
        "hardware": "NB3",
        "seq": 1,
        "ms": 1000,
        "mode": "auto",
        "manual_authorized": False,
        "temperatures": [22.0] * 6,
        "pressures": [-10.0] * 6 + [0.0],
        "differentials": [-10.0] * 6,
        "raw_pressures": [100] * 7,
        "calibrated": [True] * 7,
        "temperature_addresses": [
            "2801000000000029", "2802000000000070", "2803000000000047",
            "28040000000000C2", "28050000000000F5", "28060000000000AC",
        ],
        "temp_mean": 22.0,
        "setpoints": {"temperature": 22.0, "pressure": -10.0},
        "fans": [128, 128, 64],
        "fan_power": True,
        "fan_rpm": [1800.0, 1850.0, 1200.0],
        "tach_ppr": [2, 2, 2],
        "peltier": 0,
        "pid": {
            "pressure": {"kp": 4.0, "ki": 0.2, "kd": 0.0},
            "temperature": {"kp": 10.0, "ki": 0.1, "kd": 0.0},
        },
    }
