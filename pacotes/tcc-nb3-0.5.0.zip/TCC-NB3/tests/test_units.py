"""A interface usa porcentagem; a comunicação preserva os 256 códigos PWM."""

import math

import pytest

from tcc_monitor.units import percent_to_pwm, pwm_to_percent


@pytest.mark.parametrize(
    ("percent", "pwm"),
    [(0, 0), (0.0, 0), (25, 64), (50, 128), (75, 191), (100, 255), (100.0, 255)],
)
def test_percent_conversion_and_half_up_rounding(percent, pwm):
    result = percent_to_pwm(percent)
    assert result == pwm
    assert type(result) is int


@pytest.mark.parametrize(
    ("pwm", "percent"),
    [(0, 0.0), (64, 64 * 100 / 255), (128, 128 * 100 / 255), (255, 100.0)],
)
def test_raw_conversion_keeps_precision(pwm, percent):
    result = pwm_to_percent(pwm)
    assert result == pytest.approx(percent)
    assert type(result) is float


def test_all_raw_codes_roundtrip_without_loss():
    for pwm in range(256):
        assert percent_to_pwm(pwm_to_percent(pwm)) == pwm


def test_conversion_is_monotonic():
    values = [percent_to_pwm(step / 100) for step in range(10001)]
    assert values == sorted(values)
    assert set(values) == set(range(256))
    percentages = [pwm_to_percent(pwm) for pwm in range(256)]
    assert all(left < right for left, right in zip(percentages, percentages[1:]))


@pytest.mark.parametrize(
    "value",
    [True, False, None, "50", "", [], {}, math.nan, math.inf, -math.inf,
     -0.01, 100.01, -1, 101, 10**1000],
)
def test_percent_rejects_invalid_or_missing_data(value):
    with pytest.raises(ValueError):
        percent_to_pwm(value)


@pytest.mark.parametrize(
    "value",
    [True, False, None, "128", "", [], {}, 0.0, 128.0, 255.0,
     math.nan, math.inf, -math.inf, -1, 256, 10**1000],
)
def test_raw_pwm_requires_an_integer_in_range(value):
    with pytest.raises(ValueError):
        pwm_to_percent(value)


@pytest.mark.parametrize("convert", [percent_to_pwm, pwm_to_percent])
def test_argument_is_required(convert):
    with pytest.raises(TypeError):
        convert()
