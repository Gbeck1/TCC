import copy
import time

import pytest

from tcc_monitor.service import AppError, MonitorService
from tcc_monitor.simulator import SimulatedController


def command(op, **fields):
    return {"v": 2, "type": "command", "id": 1, "op": op, **fields}


def test_explicit_swap_preserves_six_unique_sensors_the_mean_and_actuators():
    controller = SimulatedController()
    controller.apply(command("manual_unlock"))
    controller.apply(command("mode", value="manual"))
    before = controller.telemetry()
    assert controller.apply(command("temperature_address", channel=5,
                                    address=before["temperature_addresses"][0], swap=True))["ok"]
    after = controller.telemetry()
    expected = before["temperature_addresses"].copy()
    expected[0], expected[5] = expected[5], expected[0]
    assert after["temperature_addresses"] == expected
    assert len(set(after["temperature_addresses"])) == 6
    assert after["temperatures"][5] == before["temperatures"][0]
    assert after["temperatures"][0] == before["temperatures"][5]
    assert after["temp_mean"] == pytest.approx(before["temp_mean"])
    for key in ("fans", "fan_power", "peltier", "setpoints", "pid", "calibration", "mode"):
        assert after[key] == before[key]


@pytest.mark.parametrize("swap", [None, 1, "true", []])
def test_invalid_swap_option_has_no_partial_effect(swap):
    controller = SimulatedController()
    controller.apply(command("manual_unlock"))
    controller.apply(command("mode", value="manual"))
    before = copy.deepcopy(controller.telemetry())
    assert not controller.apply(command("temperature_address", channel=1,
                                        address=before["temperature_addresses"][0], swap=swap))["ok"]
    assert controller.addresses == before["temperature_addresses"]
    assert controller.temperature == before["temperatures"]


def test_swap_requires_admin_manual_and_round_trips_through_service(tmp_path):
    service = MonitorService(data_dir=tmp_path, demo=True)
    service.start()
    def wait_for(predicate):
        deadline = time.monotonic() + 3
        while not predicate() and time.monotonic() < deadline:
            time.sleep(.02)
        assert predicate()
    try:
        wait_for(lambda: service.snapshot is not None)
        address = service.snapshot["temperature_addresses"][0]
        with pytest.raises(AppError):
            service.set_temperature_address(5, address, True)
        service.login("ADMIN", "15234")
        with pytest.raises(AppError):
            service.set_temperature_address(5, address, True)
        service.set_mode("manual")
        wait_for(lambda: service.snapshot["mode"] == "manual")
        before = service.snapshot["temperature_addresses"]
        command_id = service.set_temperature_address(5, address, True)
        assert type(command_id) is int
        wait_for(lambda: service.snapshot["temperature_addresses"][5] == address)
        assert service.snapshot["temperature_addresses"][0] == before[5]
    finally:
        service.close()
