#!/usr/bin/env bash
set -euo pipefail

project_dir=$(CDPATH='' cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
desktop_dir=''
if [[ ${1:-} == --desktop-dir ]]; then
  [[ $# == 2 ]] || { printf 'Uso: %s [--desktop-dir DIRETORIO]\n' "$0" >&2; exit 2; }
  desktop_dir=$2
elif [[ $# -ne 0 ]]; then
  printf 'Uso: %s [--desktop-dir DIRETORIO]\n' "$0" >&2
  exit 2
elif command -v xdg-user-dir >/dev/null 2>&1; then
  desktop_dir=$(xdg-user-dir DESKTOP)
fi
desktop_dir=${desktop_dir:-"$HOME/Desktop"}
mkdir -p -- "$desktop_dir"

# Desktop Exec is not a shell command. Quote its reserved characters without eval.
# Keep a fixed application command; all user-supplied paths are arguments.
python3 - "$project_dir" "$desktop_dir" <<'PY'
from pathlib import Path
import sys

project = Path(sys.argv[1])
desktop = Path(sys.argv[2])
def desktop_quote(value):
    value = str(value)
    if any(c in value for c in '\n\r\x00'):
        raise SystemExit('Caminhos com quebras de linha não são suportados pelo formato desktop.')
    # Literal '%' must be escaped before the desktop field-code expansion.
    value = value.replace('%', '%%')
    for char in ('\\', '"', '`', '$'):
        value = value.replace(char, '\\' + char)
    # Desktop strings are unescaped before the Exec argument parser runs.
    return ('"' + value + '"').replace('\\', '\\\\')

target = desktop / 'tcc-monitor.desktop'
if target.exists():
    content = target.read_text(encoding='utf-8')
    if 'X-TCC-Monitor-Launcher=true\n' not in content:
        raise SystemExit(f'Arquivo existente preservado: {target}')
lines = [
    '[Desktop Entry]',
    'Version=1.0',
    'Type=Application',
    'Name=TCC — Arduino e Raspberry Pi',
    'Comment=Monitoramento e controle da maquete',
    'Exec=/usr/bin/env bash ' + desktop_quote(project / 'scripts/run.sh'),
    'Icon=utilities-system-monitor',
    'Terminal=false',
    'Categories=Education;',
    'StartupNotify=true',
    'X-TCC-Monitor-Launcher=true',
]
target.write_text('\n'.join(lines) + '\n', encoding='utf-8')
target.chmod(0o755)
print(target)
PY

if command -v gio >/dev/null 2>&1; then
  gio set "$desktop_dir/tcc-monitor.desktop" metadata::trusted true 2>/dev/null || true
fi
printf 'Atalho criado. Se a área de trabalho perguntar, selecione Permitir iniciar. Não foi configurado início automático.\n'
