#!/usr/bin/env bash
# Run as the Raspberry Pi desktop user, not with sudo. Only OS setup uses sudo.
set -euo pipefail

project_dir=$(CDPATH='' cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
python_bin=python3
desktop_dir=''
skip_system=false
create_desktop=true
usage() {
  cat <<'HELP'
Uso: bash scripts/install_raspberry.sh [opções]
  --desktop-dir DIRETORIO  Pasta do atalho, por exemplo ~/Desktop
  --no-desktop             Não criar o atalho nesta execução
  --skip-system            Usar pré-requisitos existentes; não executar sudo/apt
  --python CAMINHO         Python para criar a .venv (padrão: python3)
  --help                   Mostrar esta ajuda
Execute com o usuário normal da Pi. O script não inicia a aplicação nem grava o Mega.
HELP
}
while (($#)); do
  case "$1" in
    --desktop-dir|--python)
      [[ $# -ge 2 ]] || { usage >&2; exit 2; }
      if [[ $1 == --desktop-dir ]]; then desktop_dir=$2; else python_bin=$2; fi
      shift 2 ;;
    --no-desktop) create_desktop=false; shift ;;
    --skip-system) skip_system=true; shift ;;
    --help|-h) usage; exit 0 ;;
    *) usage >&2; exit 2 ;;
  esac
done
if [[ $(id -u) == 0 ]]; then
  printf 'Execute como usuário normal: bash scripts/install_raspberry.sh\nO sudo será usado apenas para os pacotes do sistema e o grupo serial.\n' >&2
  exit 1
fi
if [[ $(uname -s) != Linux ]]; then
  printf 'Este instalador precisa de Linux/Raspberry Pi OS.\n' >&2
  exit 1
fi
if [[ $skip_system == false ]]; then
  case $(uname -m) in
    aarch64|armv6l|armv7l|armv8l) ;;
    *) printf 'Instalação do sistema destinada à Raspberry Pi. Para verificar pré-requisitos existentes, use --skip-system.\n' >&2; exit 1 ;;
  esac
  command -v sudo >/dev/null || { printf 'O usuário precisa de acesso a sudo para instalar os pacotes.\n' >&2; exit 1; }
  command -v apt-get >/dev/null || { printf 'Use Raspberry Pi OS ou outra distribuição compatível com apt.\n' >&2; exit 1; }
  sudo apt-get update
  sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y python3-venv python3-tk xdg-user-dirs avrdude
  getent group dialout >/dev/null || { printf 'Grupo dialout não encontrado no sistema.\n' >&2; exit 1; }
  desktop_user=$(id -un)
  case " $(id -nG "$desktop_user") " in
    *' dialout '*) ;;
    *) sudo usermod -aG dialout "$desktop_user"
       printf 'Acesso serial configurado. Encerre e abra a sessão do usuário antes de conectar ao Mega.\n' ;;
  esac
fi
command -v "$python_bin" >/dev/null || { printf 'Python não encontrado: %s\n' "$python_bin" >&2; exit 1; }
"$python_bin" - <<'PY'
import sys
if sys.version_info < (3, 9):
    raise SystemExit('Use Python 3.9 ou superior.')
try:
    import tkinter, sqlite3, venv
except ImportError as exc:
    raise SystemExit(f'Pré-requisito ausente: {exc}. Instale python3-tk e python3-venv.')
print(f'Python {sys.version.split()[0]} / Tk {tkinter.TkVersion}: disponíveis')
PY
venv_dir="$project_dir/.venv"
if [[ -L $venv_dir ]]; then
  printf 'A .venv existente é um link. Ela foi preservada; use uma cópia limpa do pacote de instalação.\n' >&2
  exit 1
fi
if [[ ! -x $venv_dir/bin/python ]]; then
  if [[ -e $venv_dir ]] && [[ ! -d $venv_dir || -n $(ls -A -- "$venv_dir") ]]; then
    printf 'A .venv existente não é um ambiente válido e foi preservada. Verifique-a antes de instalar.\n' >&2
    exit 1
  fi
  "$python_bin" -m venv "$venv_dir"
fi
export PIP_CACHE_DIR="${PIP_CACHE_DIR:-$venv_dir/.cache/pip}"
if [[ -f $project_dir/wheels/pyserial-3.5-py2.py3-none-any.whl ]]; then
  [[ -f $project_dir/wheels/SHA256SUMS ]] || { printf 'Faltou wheels/SHA256SUMS. Pacote preservado, instalação interrompida.\n' >&2; exit 1; }
  (cd "$project_dir/wheels" && sha256sum --check SHA256SUMS)
  "$venv_dir/bin/python" -m pip install --disable-pip-version-check --no-index --find-links "$project_dir/wheels" -r "$project_dir/requirements.txt"
else
  "$venv_dir/bin/python" -m pip install --disable-pip-version-check -r "$project_dir/requirements.txt"
fi
"$venv_dir/bin/python" -m pip check
PYTHONPATH="$project_dir/raspberry${PYTHONPATH:+:$PYTHONPATH}" "$venv_dir/bin/python" - <<'PY'
import serial, tkinter
from tcc_monitor.ui import MonitorApp
from tcc_monitor.calibration import calibration_from_points
assert calibration_from_points(1000, 0, 2000, 100) == {'offset': 1000.0, 'scale': 0.1}
print(f'Aplicação, calibração, Tk e comunicação serial {serial.__version__}: disponíveis')
PY
if [[ $create_desktop == true ]]; then
  if [[ -n $desktop_dir ]]; then
    bash "$project_dir/scripts/install_desktop.sh" --desktop-dir "$desktop_dir"
  else
    bash "$project_dir/scripts/install_desktop.sh"
  fi
fi
printf '\nInstalação concluída neste computador. Inicie pelo atalho ou execute:\n'
printf '  bash %q\n' "$project_dir/scripts/run.sh"
printf 'Não foi criado autostart. Históricos, usuários e calibrações existentes não foram apagados.\n'
