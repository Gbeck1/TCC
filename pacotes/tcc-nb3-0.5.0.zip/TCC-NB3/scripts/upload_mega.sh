#!/usr/bin/env bash
# Optional, explicit upload of the compiled NB3 image. Never run by the installer.
set -euo pipefail
project_dir=$(CDPATH='' cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
if [[ $# -lt 1 || $# -gt 2 || ${1:-} == --help || ${1:-} == -h ]]; then
  printf 'Uso: bash scripts/upload_mega.sh /dev/serial/by-id/PORTA [arquivo.hex]\nFeche o aplicativo antes de gravar. A porta deve ser a do Arduino Mega 2560.\n'
  [[ ${1:-} == --help || ${1:-} == -h ]] && exit 0
  exit 2
fi
port=$1
hex=${2:-"$project_dir/firmware/compiled/mega_controller.hex"}
[[ -e $port ]] || { printf 'Porta não encontrada: %s\n' "$port" >&2; exit 1; }
[[ -s $hex ]] || { printf 'Arquivo compilado não encontrado: %s\n' "$hex" >&2; exit 1; }
command -v avrdude >/dev/null || { printf 'Instale avrdude (incluído pelo instalador da Pi).\n' >&2; exit 1; }
exec avrdude -p atmega2560 -c wiring -P "$port" -b 115200 -D -U "flash:w:$hex:i"
