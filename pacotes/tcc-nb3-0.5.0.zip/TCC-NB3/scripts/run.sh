#!/usr/bin/env bash
set -euo pipefail

project_dir=$(CDPATH='' cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
cd "$project_dir"
if [[ -n "${TCC_PYTHON:-}" ]]; then
  python_bin=$TCC_PYTHON
elif [[ -x "$project_dir/.venv/bin/python" ]]; then
  python_bin="$project_dir/.venv/bin/python"
else
  python_bin=python3
fi
if ! "$python_bin" -c 'import tkinter, serial' >/dev/null 2>&1; then
  message='Instale python3-tk e as dependências do projeto na .venv. Consulte README.md.'
  printf '%s\n' "$message" >&2
  if command -v zenity >/dev/null 2>&1; then
    zenity --error --text="$message" || true
  elif command -v xmessage >/dev/null 2>&1; then
    xmessage "$message" || true
  fi
  exit 1
fi
export PYTHONPATH="$project_dir/raspberry${PYTHONPATH:+:$PYTHONPATH}"
exec "$python_bin" -m tcc_monitor "$@"
