"""Touch numeric editor: confirming a value never sends an actuator command."""
from __future__ import annotations

import math
import tkinter as tk
from tkinter import ttk


class NumericKeypad(tk.Toplevel):
    def __init__(self, app, target, label, *, validator=None, on_close=None):
        super().__init__(app)
        self.target = target
        self.validator = validator
        self.on_close = on_close
        self.previous_grab = self.grab_current()
        self.title(label)
        self.transient(target.winfo_toplevel())
        self.resizable(False, False)
        self.configure(background="#edf3fa")
        self.protocol("WM_DELETE_WINDOW", self.close)
        body = ttk.Frame(self, padding=12)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=label, font=("DejaVu Sans", 14, "bold"), wraplength=390).grid(
            row=0, column=0, columnspan=4, sticky="w", pady=(0, 8))
        self.value = tk.StringVar(self, target.get())
        self.entry = ttk.Entry(body, textvariable=self.value, font=("DejaVu Sans", 23), justify="right", width=16)
        self.entry.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(0, 8))
        self.status = tk.StringVar(self, "")
        style = ttk.Style(self)
        style.configure("Number.TButton", font=("DejaVu Sans", 17, "bold"), padding=(10, 10))
        self.keys = {}
        for row, keys in enumerate((("7", "8", "9"), ("4", "5", "6"),
                                    ("1", "2", "3"), ("±", "0", ",")), 2):
            for column, char in enumerate(keys):
                button = ttk.Button(body, text=char, width=3, takefocus=False,
                                    style="Number.TButton", command=lambda c=char: self.press(c))
                button.grid(row=row, column=column, sticky="nsew", padx=3, pady=3)
                self.keys[char] = button
        for row, (text, command) in enumerate((("Apagar", lambda: self.press("BACKSPACE")),
                                               ("Limpar", lambda: self.press("CLEAR")),
                                               ("Cancelar", self.close), ("Concluir", self.confirm)), 2):
            button = ttk.Button(body, text=text, takefocus=False, command=command,
                                style="Primary.TButton" if text == "Concluir" else "TButton")
            button.grid(row=row, column=3, sticky="nsew", padx=(8, 0), pady=3)
            self.keys[text] = button
        ttk.Label(body, textvariable=self.status, foreground="#ba3447", wraplength=390).grid(
            row=6, column=0, columnspan=4, sticky="w", pady=(4, 0))
        self.bind("<Return>", lambda _: self.confirm())
        self.bind("<Escape>", lambda _: self.close())
        self.update_idletasks()
        x = app.winfo_rootx() + max(0, (app.winfo_width() - self.winfo_width()) // 2)
        y = app.winfo_rooty() + max(0, (app.winfo_height() - self.winfo_height()) // 2)
        self.geometry(f"+{x}+{y}")
        self.grab_set()
        self.entry.focus_set()
        self.entry.selection_range(0, "end")

    def press(self, char):
        self.status.set("")
        if char == "CLEAR":
            self.value.set("")
        elif char == "±":
            text = self.value.get()
            self.value.set(text[1:] if text.startswith("-") else "-" + text)
            self.entry.selection_clear()
            self.entry.icursor("end")
        else:
            selected = self.entry.selection_present()
            if selected:
                self.entry.delete("sel.first", "sel.last")
            if char == "BACKSPACE":
                if not selected:
                    position = self.entry.index("insert")
                    if position:
                        self.entry.delete(position - 1, position)
            else:
                self.entry.insert("insert", char)
        self.entry.focus_set()

    def confirm(self):
        text = self.value.get().strip()
        try:
            if not math.isfinite(float(text.replace(",", "."))):
                raise ValueError("Informe um número finito.")
            if self.validator:
                self.validator(text)
        except (ValueError, TypeError, OverflowError):
            self.status.set("Confira o valor e o intervalo permitido para este campo.")
            return
        if self.target.winfo_exists() and self.target.instate(("!disabled", "!readonly")):
            self.target.delete(0, "end")
            self.target.insert(0, text)
        self.close()

    def close(self):
        self.grab_release()
        self.destroy()
        if self.on_close:
            self.on_close(self.target)
        if self.previous_grab is not None and self.previous_grab.winfo_exists():
            self.previous_grab.grab_set()
        if self.target.winfo_exists():
            self.target.focus_set()
