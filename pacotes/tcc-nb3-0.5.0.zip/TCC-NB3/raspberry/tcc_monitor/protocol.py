"""Identidade do protocolo e da placa física, compartilhada pelo aplicativo."""

VERSION = 2
HARDWARE = "NB3"
