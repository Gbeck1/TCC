# Identidade visual

A imagem `unisal.png` foi preparada com base na referência visual enviada pelo usuário no chat. O nome e a identidade UNISAL pertencem à instituição. Somente essa marca é exibida no canto superior esquerdo do cabeçalho.

Para substituir a imagem incluída, coloque outro PNG em `unisal.png` nesta pasta ou informe um arquivo externo:

```bash
bash scripts/run.sh --unisal-logo /caminho/da/marca-unisal.png
```

A imagem é preservada em suas proporções e reduzida para caber no cabeçalho. PNG com fundo branco ou transparente é adequado.
