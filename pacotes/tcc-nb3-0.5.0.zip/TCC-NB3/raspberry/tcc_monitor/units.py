"""Conversão entre o PWM percentual da interface e o PWM de 8 bits serial."""

import math
from typing import Union


def percent_to_pwm(value: Union[int, float]) -> int:
    """Converte 0–100% em 0–255, arredondando meio ponto para cima."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("PWM percentual deve ser um número entre 0 e 100.")
    if not 0 <= value <= 100 or not math.isfinite(value):
        raise ValueError("PWM percentual deve ser um número finito entre 0 e 100.")
    return math.floor(value * 255 / 100 + 0.5)


def pwm_to_percent(value: int) -> float:
    """Converte um código PWM inteiro de 8 bits em percentual sem arredondar."""
    if type(value) is not int or not 0 <= value <= 255:
        raise ValueError("PWM deve ser inteiro entre 0 e 255.")
    return value * 100 / 255
