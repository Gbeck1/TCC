"""Run with python -m tcc_monitor, normally through the desktop launcher."""

import argparse
import sys
import tkinter as tk

from .service import AppError, MonitorService
from .ui import MonitorApp


def main(argv=None):
    parser = argparse.ArgumentParser(description="Interface touch TCC NB3 · Mega 2560/Raspberry Pi · protocolo v2")
    parser.add_argument("--port", help="Porta USB do Mega NB3, por exemplo /dev/ttyACM0")
    parser.add_argument("--demo", action="store_true", help="Simulação explícita, sem conexão ou atuação no hardware")
    parser.add_argument("--data-dir", help="Diretório do banco de dados e configuração local")
    parser.add_argument("--fullscreen", action="store_true", help="Tela cheia; Esc retorna à janela")
    parser.add_argument("--unisal-logo", help="Arquivo PNG da marca UNISAL a exibir no cabeçalho")
    args = parser.parse_args(argv)
    service = None
    try:
        service = MonitorService(data_dir=args.data_dir, port=args.port, demo=args.demo)
        service.start()
        app = MonitorApp(service, demo=args.demo, fullscreen=args.fullscreen, unisal_logo=args.unisal_logo)
        app.mainloop()
    except (AppError, tk.TclError, OSError) as exc:
        print(f"Não foi possível iniciar a interface: {exc}", file=sys.stderr)
        return 1
    finally:
        if service is not None:
            service.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
