"""Cálculo dos coeficientes de pressão usados pelo firmware do Mega."""
from __future__ import annotations

import math

from .validation import calibration, number


RAW_MIN = -8388608
RAW_MAX = 8388607


def _finite_number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} deve ser um número finito.")
    try:
        value = float(value)
    except OverflowError as exc:
        raise ValueError(f"{name} deve ser um número finito.") from exc
    if not math.isfinite(value):
        raise ValueError(f"{name} deve ser um número finito.")
    return value


def _raw_number(value, name):
    value = _finite_number(value, name)
    if not RAW_MIN <= value <= RAW_MAX:
        raise ValueError(f"{name} deve estar entre {RAW_MIN} e {RAW_MAX} contagens.")
    return value


def _coefficients(offset, scale):
    # A mesma validação do comando serial impede coeficientes que não cabem
    # nos floats de 32 bits do Arduino, inclusive escala arredondada para zero.
    calibration(0, offset, scale)
    return {"offset": float(offset), "scale": float(scale)}


def calibration_from_points(raw_a, pressure_a, raw_b, pressure_b):
    """Ajusta Pa = (raw - offset) * scale a duas referências conhecidas.

    As leituras raw podem ser médias fracionárias de amostras do HX710B.
    A escala pode ser negativa, conforme a orientação das portas de pressão.
    """
    raw_a = _raw_number(raw_a, "Leitura A")
    raw_b = _raw_number(raw_b, "Leitura B")
    pressure_a = number(_finite_number(pressure_a, "Pressão A"), "Pressão A")
    pressure_b = number(_finite_number(pressure_b, "Pressão B"), "Pressão B")
    if raw_a == raw_b:
        raise ValueError("As duas leituras raw devem ser diferentes.")
    if pressure_a == pressure_b:
        raise ValueError("As duas pressões de referência devem ser diferentes.")
    scale = (pressure_b - pressure_a) / (raw_b - raw_a)
    if scale == 0:
        raise ValueError("A escala calculada não pode ser zero.")
    offset = raw_a - pressure_a / scale
    return _coefficients(offset, scale)


def zero_calibration(raw, scale, reference_pressure=0.0):
    """Ajusta o offset à pressão conhecida e preserva a escala existente."""
    raw = _raw_number(raw, "Leitura raw")
    scale = _finite_number(scale, "Escala")
    reference_pressure = number(
        _finite_number(reference_pressure, "Pressão de referência"), "Pressão de referência"
    )
    if scale == 0:
        raise ValueError("A escala não pode ser zero.")
    offset = raw - reference_pressure / scale
    return _coefficients(offset, scale)
