"""Controlador e processo fictícios, apenas para demonstração sem hardware."""
from __future__ import annotations

import copy
import math

from . import validation as check
from .protocol import VERSION, HARDWARE


class SimulatedController:
    def __init__(self):
        self.mode = "auto"
        self.authorized = False
        self.fans = [100, 100, 50]
        self.power = True
        self.tach_ppr = [2, 2, 2]  # Provisional until model-specific verification.
        self.rpm = [None, None, None]
        self.peltier = 0
        self.setpoints = {"temperature": 22.0, "pressure": -10.0}
        self.pid = {"pressure": {"kp": 4.0, "ki": 0.2, "kd": 0.0},
                    "temperature": {"kp": 10.0, "ki": 0.1, "kd": 0.0}}
        self.integrals = {"pressure": 0.0, "temperature": 0.0}
        self.previous_measurements = {"pressure": None, "temperature": None}
        self.temperature = [24.0 + i * .1 for i in range(6)]
        self.pressure = [-2.0 * (i + 1) for i in range(6)] + [0.0]
        self.calibration = [{"offset": 0.0, "scale": .001} for _ in range(7)]
        self.addresses = []
        for i in range(6):
            base = bytes([0x28, i + 1, 0, 0, 0, 0, 0])
            self.addresses.append((base + bytes([check.crc8(base)])).hex().upper())
        self.ms = 0
        self.seq = 0

    def apply(self, command):
        ack = {"v": VERSION, "type": "ack", "id": command.get("id", 0), "ok": False}
        try:
            if type(command.get("v")) is not int or command["v"] != VERSION or command.get("type") != "command" or type(command.get("id")) is not int or not 1 <= command["id"] <= 2147483647:
                raise ValueError("Comando v2/id inválido.")
            op = command.get("op")
            if op in ("outputs", "pid", "calibrate", "temperature_address", "tach", "save"):
                if self.mode != "manual" or not self.authorized:
                    raise ValueError("Operação exige modo manual autorizado.")
            if op == "get_state":
                pass
            elif op == "manual_unlock":
                self.authorized = True
            elif op == "mode":
                value = command.get("value")
                if value not in ("auto", "manual"):
                    raise ValueError("Modo inválido.")
                if value == "manual" and not self.authorized:
                    raise ValueError("Manual não autorizado.")
                self.mode = value
                if value == "auto":
                    self.authorized = False
                    self.integrals = dict.fromkeys(self.integrals, 0.0)
                    self.previous_measurements = dict.fromkeys(self.previous_measurements, None)
                    self._control(.1)
            elif op == "setpoints":
                temperature = check.number(command.get("temperature"))
                pressure = check.number(command.get("pressure"))
                self.setpoints = {"temperature": temperature, "pressure": pressure}
            elif op == "outputs":
                check.outputs(command.get("fans"), command.get("fan_power"), command.get("peltier"))
                check.peltier_switch(command.get("peltier"))
                self.fans = command["fans"].copy()
                self.power = command["fan_power"]
                self.peltier = command["peltier"]
            elif op == "pid":
                loop = command.get("loop")
                check.gains(loop, command.get("kp"), command.get("ki"), command.get("kd"))
                if loop == "temperature":
                    raise ValueError("Peltier usa controle Liga/Desliga.")
                self.pid[loop] = {key: float(command[key]) for key in ("kp", "ki", "kd")}
                self.integrals[loop] = 0.0
            elif op == "calibrate":
                check.calibration(command.get("channel"), command.get("offset"), command.get("scale"))
                self.calibration[command["channel"]] = {key: float(command[key]) for key in ("offset", "scale")}
            elif op == "temperature_address":
                check.temperature_address(command.get("channel"), command.get("address"))
                address = command["address"].upper()
                swap = command.get("swap", False)
                if type(swap) is not bool:
                    raise ValueError("Troca de sensores deve ser booleana.")
                previous = next((i for i, value in enumerate(self.addresses)
                                 if value == address and i != command["channel"]), None)
                if previous is not None:
                    if not swap:
                        raise ValueError("ROM já associada a outra sala.")
                    self.addresses[previous] = self.addresses[command["channel"]]
                    self.temperature[previous], self.temperature[command["channel"]] = (
                        self.temperature[command["channel"]], self.temperature[previous])
                self.addresses[command["channel"]] = address
            elif op == "tach":
                check.tach(command.get("channel"), command.get("pulses_per_rev"))
                self.tach_ppr[command["channel"]] = command["pulses_per_rev"]
                self.rpm[command["channel"]] = None
            elif op == "save":
                pass  # Demo never pretends to write a real Mega's EEPROM.
            else:
                raise ValueError("Operação desconhecida.")
            ack["ok"] = True
        except (ValueError, TypeError, KeyError) as exc:
            ack["error"] = str(exc)
        return ack

    def _pid(self, loop, measurement, setpoint, dt):
        error = measurement - setpoint
        gains = self.pid[loop]
        previous = self.previous_measurements[loop]
        derivative = 0.0 if previous is None else (measurement - previous) / dt
        trial_integral = max(-255, min(255, self.integrals[loop] + gains["ki"] * error * dt))
        trial = gains["kp"] * error + trial_integral + gains["kd"] * derivative
        if 0 <= trial <= 255 or trial > 255 and error < 0 or trial < 0 and error > 0:
            self.integrals[loop] = trial_integral
        result = gains["kp"] * error + self.integrals[loop] + gains["kd"] * derivative
        self.previous_measurements[loop] = measurement
        return min(255, max(0, result))

    def _control(self, dt):
        effort = self._pid("pressure", self.pressure[5] - self.pressure[6], self.setpoints["pressure"], dt)
        exhaust = max(1, min(255, round(effort)))
        supply = min(exhaust - 1, max(0, int(exhaust * .6)))
        self.fans = [exhaust, exhaust, supply]
        self.power = True
        mean = self._temperature_mean()
        if mean is not None:
            if mean > self.setpoints["temperature"] + 0.5:
                self.peltier = 255
            elif mean <= self.setpoints["temperature"]:
                self.peltier = 0

    def _temperature_mean(self):
        if len(self.temperature) != 6 or any(
                isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
                for v in self.temperature):
            return None
        return sum(self.temperature) / 6

    def advance(self, dt=1.0):
        dt = check.number(dt)
        if dt <= 0:
            return
        # This model is illustrative, not a fan curve, thermal design or tuning source.
        steps = min(100, max(1, math.ceil(dt / .1)))
        step = dt / steps
        alpha = 1 - math.exp(-step / 5.0)
        for _ in range(steps):
            if self.mode == "auto":
                self._control(max(.001, step))
            exhaust = sum(self.fans[i] if self.power else 0 for i in (0, 1)) / 2
            supply = self.fans[2] if self.power else 0
            for i in range(6):
                target = (-.14 * exhaust + .10 * supply) * (i + 1) / 6
                self.pressure[i] += (target - self.pressure[i]) * alpha
                target_temp = 25 - 10 * self.peltier / 255 + .05 * i
                if isinstance(self.temperature[i], (int, float)) and not isinstance(self.temperature[i], bool):
                    self.temperature[i] += (target_temp - self.temperature[i]) * alpha
        self.ms += round(dt * 1000)
        # Illustrative speed, not datasheet fan curves or proof of real TACH.
        self.rpm = [round((900 + 7000 * effort / 255) if self.power else 0, 1) for effort in self.fans]

    def telemetry(self):
        self.seq += 1
        raw = []
        for pressure, coefficients in zip(self.pressure, self.calibration):
            # ADC codes have a signed 24-bit domain, including in demonstration.
            code = pressure / coefficients["scale"] + coefficients["offset"]
            raw.append(round(max(-8388608, min(8388607, code))))
        return copy.deepcopy({
            "v": VERSION, "hardware": HARDWARE, "type": "telemetry", "simulation": True, "seq": self.seq, "ms": self.ms,
            "mode": self.mode, "manual_authorized": self.authorized,
            "temperatures": [v if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
                             else None for v in self.temperature], "pressures": self.pressure,
            "differentials": [p - self.pressure[6] for p in self.pressure[:6]],
            "raw_pressures": raw,
            "calibrated": [True] * 7, "calibration": self.calibration,
            "temperature_addresses": self.addresses, "discovered_addresses": self.addresses,
            "temperature_auto_assignment": True,
            "temp_mean": self._temperature_mean(), "setpoints": self.setpoints,
            "fans": self.fans, "fan_power": self.power, "fan_rpm": self.rpm, "tach_ppr": self.tach_ppr,
            "peltier": self.peltier, "peltier_control": "on_off", "pid": self.pid,
        })
