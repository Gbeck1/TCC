"""SQLite local: usuários, configuração de salas, histórico e alarmes."""
from __future__ import annotations

import csv
import hashlib
import hmac
import json
import math
import secrets
import sqlite3
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


LOCATION_NAMES = {
    "gowning": "Paramentação",
    "degowning": "Desparamentação",
    "corridor": "Corredor Central",
    "autoclave": "Sala de Autoclave",
    "laboratory_1": "Laboratório 1",
    "laboratory_2": "Laboratório 2",
}
# Physical P1..P6 assignments explicitly supplied by the user for NB3.
DEFAULT_LOCATIONS = dict(enumerate(LOCATION_NAMES, start=1))


def utc_text(timestamp):
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat(timespec="milliseconds")


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    iterations = 260000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), iterations)
    return f"pbkdf2_sha256${iterations}${salt}${digest.hex()}"


def password_matches(password, encoded):
    try:
        algorithm, iterations, salt, digest = encoded.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), int(iterations))
        return hmac.compare_digest(actual.hex(), digest)
    except (ValueError, TypeError):
        return False


class Store:
    def __init__(self, data_dir):
        self.path = Path(data_dir).expanduser()
        self.path.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.path / "monitor.sqlite3", check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
              username TEXT PRIMARY KEY, password TEXT NOT NULL,
              role TEXT NOT NULL CHECK(role IN ('admin','operator')));
            CREATE TABLE IF NOT EXISTS rooms (
              id INTEGER PRIMARY KEY, name TEXT NOT NULL,
              temp_min REAL NOT NULL, temp_max REAL NOT NULL,
              pressure_min REAL NOT NULL, pressure_max REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS samples (
              id INTEGER PRIMARY KEY, timestamp REAL NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS alarms (
              id INTEGER PRIMARY KEY, timestamp REAL NOT NULL, room_id INTEGER NOT NULL,
              room_name TEXT NOT NULL, parameter TEXT NOT NULL,
              message TEXT NOT NULL, active INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS alarm_state (key TEXT PRIMARY KEY, active INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS audit (
              id INTEGER PRIMARY KEY, timestamp REAL NOT NULL,
              username TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL);
        """)
        with self.lock, self.db:
            # Bootstrap once only: deleting/changing ADMIN never restores its old password.
            self.db.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")
            if not self.db.execute("SELECT 1 FROM metadata WHERE key='initialized'").fetchone():
                self.db.execute("INSERT INTO users VALUES (?,?,?)", ("ADMIN", password_hash("15234"), "admin"))
                self.db.execute("INSERT INTO metadata VALUES ('initialized','1')")
            for room in range(1, 7):
                self.db.execute("INSERT OR IGNORE INTO rooms(id,name,temp_min,temp_max,pressure_min,pressure_max) VALUES (?,?,?,?,?,?)",
                                (room, f"Sala {room}", 18.0, 28.0, -30.0, -1.0))
            columns = {row["name"] for row in self.db.execute("PRAGMA table_info(rooms)")}
            if "location" not in columns:
                self.db.execute("ALTER TABLE rooms ADD COLUMN location TEXT NOT NULL DEFAULT ''")
            for room_id, location in DEFAULT_LOCATIONS.items():
                self.db.execute("UPDATE rooms SET location=? WHERE id=? AND location=''", (location, room_id))
                self.db.execute("UPDATE rooms SET name=? WHERE id=? AND name=?",
                                (LOCATION_NAMES[location], room_id, f"Sala {room_id}"))
            self.db.execute("INSERT OR IGNORE INTO metadata VALUES ('room_mapping_confirmed','1')")

    def close(self):
        with self.lock:
            self.db.close()

    def authenticate(self, username, password):
        with self.lock:
            row = self.db.execute("SELECT password,role FROM users WHERE username=?", (username,)).fetchone()
            return row["role"] if row and password_matches(password, row["password"]) else None

    def users(self):
        with self.lock:
            return [dict(r) for r in self.db.execute("SELECT username,role FROM users ORDER BY username")]

    def add_user(self, username, password, role):
        if not isinstance(username, str) or not username.strip() or len(username) > 48:
            raise ValueError("Nome de usuário deve ter 1 a 48 caracteres.")
        if role not in ("admin", "operator"):
            raise ValueError("Perfil deve ser admin ou operator.")
        if not isinstance(password, str) or not password or len(password) > 128:
            raise ValueError("Senha deve ter 1 a 128 caracteres.")
        try:
            with self.lock, self.db:
                self.db.execute("INSERT INTO users VALUES (?,?,?)", (username.strip(), password_hash(password), role))
        except sqlite3.IntegrityError as exc:
            raise ValueError("Usuário já existe.") from exc

    def delete_user(self, username):
        with self.lock, self.db:
            row = self.db.execute("SELECT role FROM users WHERE username=?", (username,)).fetchone()
            if not row:
                raise ValueError("Usuário não encontrado.")
            count = self.db.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0]
            if row["role"] == "admin" and count <= 1:
                raise ValueError("Mantenha pelo menos um administrador cadastrado.")
            self.db.execute("DELETE FROM users WHERE username=?", (username,))

    def change_password(self, username, password):
        if not isinstance(password, str) or not password or len(password) > 128:
            raise ValueError("Senha deve ter 1 a 128 caracteres.")
        with self.lock, self.db:
            cursor = self.db.execute("UPDATE users SET password=? WHERE username=?", (password_hash(password), username))
            if not cursor.rowcount:
                raise ValueError("Usuário não encontrado.")

    def rooms(self):
        with self.lock:
            confirmed = self.db.execute("SELECT value FROM metadata WHERE key='room_mapping_confirmed'").fetchone()[0] == "1"
            return [dict(r, mapping_confirmed=confirmed) for r in self.db.execute("SELECT * FROM rooms ORDER BY id")]

    def assign_rooms(self, mapping, confirmed=True):
        if (not isinstance(mapping, dict) or any(type(key) is not int for key in mapping)
                or any(not isinstance(value, str) for value in mapping.values())
                or set(mapping) != set(range(1, 7)) or set(mapping.values()) != set(LOCATION_NAMES)):
            raise ValueError("Associe os seis canais P1–P6 uma vez a cada um dos seis ambientes.")
        if type(confirmed) is not bool:
            raise ValueError("Confirmação de associação deve ser booleana.")
        with self.lock, self.db:
            for room_id, location in mapping.items():
                current = self.db.execute("SELECT name,location FROM rooms WHERE id=?", (room_id,)).fetchone()
                # Keep deliberately customized room labels; update canonical labels on reassignment.
                old_default = LOCATION_NAMES.get(current["location"])
                name = LOCATION_NAMES[location] if current["name"] in (old_default, f"Sala {room_id}") else current["name"]
                self.db.execute("UPDATE rooms SET location=?,name=? WHERE id=?", (location, name, room_id))
            self.db.execute("UPDATE metadata SET value=? WHERE key='room_mapping_confirmed'", ("1" if confirmed else "0",))

    def update_room(self, room_id, name, temp_min, temp_max, pressure_min, pressure_max):
        limits = [temp_min, temp_max, pressure_min, pressure_max]
        if isinstance(room_id, bool) or room_id not in range(1, 7):
            raise ValueError("Sala deve estar entre 1 e 6.")
        if not isinstance(name, str) or not name.strip() or len(name) > 48:
            raise ValueError("Nome da sala deve ter 1 a 48 caracteres.")
        if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in limits):
            raise ValueError("Limites devem ser números finitos.")
        if temp_min >= temp_max or pressure_min >= pressure_max:
            raise ValueError("Limite mínimo deve ser menor que o máximo.")
        with self.lock, self.db:
            self.db.execute("UPDATE rooms SET name=?,temp_min=?,temp_max=?,pressure_min=?,pressure_max=? WHERE id=?",
                            (name.strip(), *limits, room_id))

    def _alarm(self, key, active, room_id, room_name, parameter, message, timestamp):
        row = self.db.execute("SELECT active FROM alarm_state WHERE key=?", (key,)).fetchone()
        previous = bool(row[0]) if row else False
        if active != previous:
            self.db.execute("INSERT INTO alarms(timestamp,room_id,room_name,parameter,message,active) VALUES (?,?,?,?,?,?)",
                            (timestamp, room_id, room_name, parameter, message if active else "Normalizado: " + message, int(active)))
        self.db.execute("INSERT OR REPLACE INTO alarm_state VALUES (?,?)", (key, int(active)))

    def record(self, snapshot):
        now = time.time()
        with self.lock, self.db:
            self.db.execute("INSERT INTO samples(timestamp,payload) VALUES (?,?)",
                            (now, json.dumps(snapshot, ensure_ascii=False, allow_nan=False, separators=(",", ":"))))
            for room in self.rooms():
                idx = room["id"] - 1
                for parameter, values, low, high, unit in [
                    ("temperatura", snapshot["temperatures"], room["temp_min"], room["temp_max"], "°C"),
                    ("pressão", snapshot["differentials"], room["pressure_min"], room["pressure_max"], "Pa"),
                ]:
                    value = values[idx]
                    key = f"{room['id']}:{parameter}"
                    self._alarm(key + ":fault", value is None, room["id"], room["name"], parameter,
                                "Leitura indisponível / sensor sem calibração ou desconectado", now)
                    self._alarm(key + ":low", value is not None and value < low, room["id"], room["name"], parameter,
                                f"Abaixo do mínimo ({low:g} {unit})", now)
                    self._alarm(key + ":high", value is not None and value > high, room["id"], room["name"], parameter,
                                f"Acima do máximo ({high:g} {unit})", now)
            self._alarm("ambient:fault", snapshot["pressures"][6] is None, 0, "Ambiente", "pressão",
                        "Referência ambiente indisponível / sem calibração", now)

    def history(self, room_id, limit=300):
        if room_id not in range(1, 7):
            raise ValueError("Sala inválida.")
        with self.lock:
            rows = self.db.execute("SELECT timestamp,payload FROM samples ORDER BY id DESC LIMIT ?",
                                   (max(1, min(int(limit), 10000)),)).fetchall()
        result = []
        for row in reversed(rows):
            payload = json.loads(row["payload"])
            result.append({"timestamp": row["timestamp"], "temperature": payload["temperatures"][room_id - 1],
                           "pressure": payload["differentials"][room_id - 1]})
        return result

    def alarm_log(self, limit=200):
        with self.lock:
            rows = self.db.execute("SELECT timestamp,room_id,room_name,parameter,message,active FROM alarms ORDER BY id DESC LIMIT ?",
                                   (max(1, min(int(limit), 10000)),)).fetchall()
        return [dict(row) for row in rows]

    def audit(self, username, action, detail):
        with self.lock, self.db:
            self.db.execute("INSERT INTO audit(timestamp,username,action,detail) VALUES (?,?,?,?)",
                            (time.time(), username, action, detail))

    def export_csv(self, path):
        fields = ["timestamp_utc", "seq", "mode", "temperature_setpoint_c", "pressure_setpoint_pa", "temp_mean_c"]
        fields += [f"room_{i}_temperature_c" for i in range(1, 7)]
        fields += [f"room_{i}_differential_pa" for i in range(1, 7)]
        fields += [f"channel_{i}_pressure_pa" for i in range(1, 8)]
        fields += [f"channel_{i}_raw" for i in range(1, 8)]
        fields += [f"channel_{i}_calibrated" for i in range(1, 8)]
        fields += [f"fan_{i}_pwm" for i in range(1, 4)] + ["fans_power", "peltier_pwm"]
        fields += [f"fan_{i}_rpm" for i in range(1, 4)] + [f"tach_{i}_ppr" for i in range(1, 4)]
        fields += [f"pid_{loop}_{term}" for loop in ("pressure", "temperature") for term in ("kp", "ki", "kd")]
        fields += ["protocol_version", "hardware"] + [f"fan_{i}_power_legacy" for i in range(1, 4)]
        count = 0
        with self.lock, open(path, "w", newline="", encoding="utf-8-sig") as file:
            writer = csv.writer(file)
            writer.writerow(fields)
            for row in self.db.execute("SELECT timestamp,payload FROM samples ORDER BY id"):
                p = json.loads(row["payload"])
                values = [utc_text(row["timestamp"]), p["seq"], p["mode"], p["setpoints"]["temperature"],
                          p["setpoints"]["pressure"], p["temp_mean"]]
                for key in ("temperatures", "differentials", "pressures", "raw_pressures", "calibrated", "fans"):
                    values.extend(p[key])
                power = p["fan_power"]
                legacy_power = power if isinstance(power, list) else [None] * 3
                # Old mixed per-channel states cannot be misreported as one NB3 rail.
                common_power = power if type(power) is bool else power[0] if len(power) == 3 and len(set(power)) == 1 else None
                values.extend([common_power, p["peltier"]])
                values.extend(p.get("fan_rpm", [None] * 3))
                values.extend(p.get("tach_ppr", [None] * 3))
                values.extend(p["pid"][loop][term] for loop in ("pressure", "temperature") for term in ("kp", "ki", "kd"))
                values.extend([p.get("v", 1), p.get("hardware", "")])
                values.extend(legacy_power)
                writer.writerow(values)
                count += 1
        return count
