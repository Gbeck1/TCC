"""Real pyserial I/O against a pseudo-terminal, without an attached Arduino."""

import json
import os
import select
import threading
import time
import tty

import pytest

from tcc_monitor.service import MonitorService
from tcc_monitor.simulator import SimulatedController
from tcc_monitor.transport import MAX_TELEMETRY_BYTES


pytestmark = pytest.mark.skipif(os.name != "posix", reason="PTY is a POSIX facility")


def eventually(predicate, timeout=4.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.02)
    assert predicate(), "Expected USB protocol state was not observed"


class SerialControllerStub:
    """A firmware endpoint able to fragment, reject, or lose protocol replies."""

    def __init__(self):
        self.master, self.slave = os.openpty()
        tty.setraw(self.slave)
        self.port = os.ttyname(self.slave)
        self.controller = SimulatedController()
        self.commands = []
        self.withhold_ack = set()
        self.ack_delays = {}
        self.command_times = {}
        self.ack_times = {}
        self.reject_unlock = False
        self.periodic_telemetry = True
        self.stop = threading.Event()
        self.closed = False
        self.write_lock = threading.Lock()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.thread.start()

    def send(self, message, split=False):
        data = (json.dumps(message, separators=(",", ":")) + "\n").encode("utf-8")
        with self.write_lock:
            if split:
                middle = len(data) // 2
                os.write(self.master, data[:middle])
                time.sleep(0.01)
                os.write(self.master, data[middle:])
            else:
                os.write(self.master, data)

    def _run(self):
        buffer = bytearray()
        pending_acks = []
        last_telemetry = time.monotonic()
        while not self.stop.is_set():
            readable, _, _ = select.select([self.master], [], [], 0.02)
            if readable:
                try:
                    buffer.extend(os.read(self.master, 4096))
                except OSError:
                    break
                while b"\n" in buffer:
                    line, _, remainder = buffer.partition(b"\n")
                    buffer = bytearray(remainder)
                    command = json.loads(line)
                    self.commands.append(command)
                    self.command_times[command["id"]] = time.monotonic()
                    if self.reject_unlock and command["op"] == "manual_unlock":
                        ack = {"v": 2, "type": "ack", "id": command["id"], "ok": False, "error": "denied_in_test"}
                    else:
                        ack = self.controller.apply(command)
                    if command["op"] not in self.withhold_ack:
                        delay = self.ack_delays.get(command["op"], 0.0)
                        if delay:
                            pending_acks.append((time.monotonic() + delay, ack))
                        else:
                            self.ack_times[ack["id"]] = time.monotonic()
                            self.send(ack)
                    self.send(self.controller.telemetry(), split=True)
            now = time.monotonic()
            for due, ack in list(pending_acks):
                if now >= due:
                    self.ack_times[ack["id"]] = time.monotonic()
                    self.send(ack)
                    pending_acks.remove((due, ack))
            if now - last_telemetry >= 0.2:
                self.controller.advance(now - last_telemetry)
                if self.periodic_telemetry:
                    self.send(self.controller.telemetry(), split=True)
                last_telemetry = now

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.stop.set()
        self.thread.join(timeout=1)
        os.close(self.master)
        os.close(self.slave)


@pytest.fixture
def serial_pair(tmp_path):
    endpoint = SerialControllerStub()
    endpoint.start()
    service = MonitorService(data_dir=tmp_path, port=endpoint.port)
    service.start()
    try:
        eventually(lambda: service.snapshot is not None)
        yield service, endpoint
    finally:
        service.close()
        endpoint.close()


def test_serial_fragmented_telemetry_and_ack_sequence(serial_pair):
    service, endpoint = serial_pair
    assert endpoint.commands[0]["op"] == "get_state"
    service.login("ADMIN", "15234")
    service.set_mode("manual")
    eventually(lambda: service.snapshot["mode"] == "manual")
    manual_ops = [command["op"] for command in endpoint.commands if command["op"] != "get_state"]
    assert manual_ops[:2] == ["manual_unlock", "mode"]
    service.outputs([0, 2, 255], True, 255)
    eventually(lambda: service.snapshot["fans"] == [0, 2, 255] and service.snapshot["peltier"] == 255)
    assert service.snapshot["fan_power"] is True
    acks = [event for event in service.drain_events() if event["type"] == "ack"]
    assert any(event["ok"] for event in acks)


def test_failed_unlock_never_enqueues_manual_mode(serial_pair):
    service, endpoint = serial_pair
    endpoint.reject_unlock = True
    service.login("ADMIN", "15234")
    service.set_mode("manual")
    eventually(lambda: any(command["op"] == "manual_unlock" for command in endpoint.commands))
    # Let the service process the negative ACK and another telemetry cycle.
    initial_seq = service.snapshot["seq"]
    eventually(lambda: service.snapshot["seq"] > initial_seq + 1)
    assert not any(command["op"] == "mode" for command in endpoint.commands)
    assert service.snapshot["mode"] == "auto"


def test_lost_actuator_ack_is_not_retransmitted(serial_pair):
    service, endpoint = serial_pair
    service.login("ADMIN", "15234")
    service.set_mode("manual")
    eventually(lambda: service.snapshot["mode"] == "manual")
    endpoint.withhold_ack.add("outputs")
    service.outputs([0, 0, 240], True, 0)
    eventually(lambda: service.snapshot["peltier"] == 0)
    # Wait past the configured ACK timeout while telemetry continues to arrive.
    time.sleep(service.ACK_TIMEOUT + 0.35)
    commands = [command for command in endpoint.commands if command["op"] == "outputs"]
    assert len(commands) == 1
    assert service.snapshot["fans"] == [0, 0, 240]
    assert service.snapshot["peltier"] == 0


def test_oversized_line_is_discarded_and_next_frame_recovers(serial_pair):
    service, endpoint = serial_pair
    service.drain_events()
    previous_seq = service.snapshot["seq"]
    with endpoint.write_lock:
        os.write(endpoint.master, b"x" * (MAX_TELEMETRY_BYTES + 32) + b"\n")
    eventually(lambda: service.snapshot["seq"] > previous_seq + 1)
    events = service.drain_events()
    assert any(event["type"] == "error" for event in events)
    assert service.snapshot["temperatures"][0] is not None


def test_stale_telemetry_warns_without_expiring_manual_access(serial_pair):
    service, endpoint = serial_pair
    service.login("ADMIN", "15234")
    service.set_mode("manual")
    eventually(lambda: service.snapshot["mode"] == "manual")
    endpoint.periodic_telemetry = False
    eventually(lambda: "históricos" in service.status, timeout=4.5)
    assert service.admin
    assert service.snapshot["mode"] == "manual"
    service.outputs([0, 0, 255], True, 255)
    eventually(lambda: service.snapshot["peltier"] == 255)
    assert service.snapshot["fans"] == [0, 0, 255]


def test_command_queue_waits_for_matching_ack_and_starts_timeout_when_sent(serial_pair):
    service, endpoint = serial_pair
    service.login("ADMIN", "15234")
    service.set_mode("manual")
    eventually(lambda: service.snapshot["mode"] == "manual")
    service.drain_events()
    # Each ACK arrives before its own deadline, but the second arrives later
    # than ACK_TIMEOUT measured from enqueueing. Queue time must not expire it.
    endpoint.ack_delays["outputs"] = service.ACK_TIMEOUT * 0.65
    service.outputs([11, 22, 33], True, 0)
    service.outputs([44, 55, 66], True, 255)
    outputs = lambda: [command for command in endpoint.commands if command["op"] == "outputs"]
    eventually(lambda: len(outputs()) == 1)
    # An unrelated ACK must not release the queued command.
    endpoint.send({"v": 2, "type": "ack", "id": 123456789, "ok": True})
    time.sleep(0.25)
    assert len(outputs()) == 1
    eventually(lambda: len(outputs()) == 2)
    first, second = outputs()
    assert endpoint.command_times[second["id"]] >= endpoint.ack_times[first["id"]]
    eventually(lambda: second["id"] in endpoint.ack_times)
    # Wait for service parsing, which follows the endpoint's write.
    observed = []

    def both_acks_received():
        observed.extend(service.drain_events())
        accepted = {event["id"] for event in observed if event["type"] == "ack" and event["ok"]}
        return first["id"] in accepted and second["id"] in accepted

    eventually(both_acks_received)
    assert not any(event["type"] == "error" for event in observed)
    assert len(outputs()) == 2  # Neither actuator command was retransmitted.
    assert service.snapshot["fans"] == [44, 55, 66]


def test_disconnection_reports_in_flight_command_without_waiting_for_reconnect(serial_pair):
    service, endpoint = serial_pair
    service.login("ADMIN", "15234")
    service.set_mode("manual")
    eventually(lambda: service.snapshot["mode"] == "manual")
    service.drain_events()
    endpoint.withhold_ack.add("outputs")
    service.outputs([0, 7, 255], True, 0)
    eventually(lambda: service.snapshot["peltier"] == 0 and service.snapshot["fans"] == [0, 7, 255])
    endpoint.close()
    eventually(lambda: service.status.startswith("Desconectado:"))
    errors = [event for event in service.drain_events() if event["type"] == "error"]
    assert any("outputs" in event["message"] and "resultado desconhecido" in event["message"].lower() for event in errors)
    assert service.snapshot["mode"] == "manual"
    assert service.snapshot["fans"] == [0, 7, 255]
    assert len([command for command in endpoint.commands if command["op"] == "outputs"]) == 1
