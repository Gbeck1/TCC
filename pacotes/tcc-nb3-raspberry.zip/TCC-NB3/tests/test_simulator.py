"""The simulator exercises the same permission and actuator contract as USB."""

import copy
import json

import pytest

from tcc_monitor.simulator import SimulatedController


def command(op, **fields):
    return {"v": 2, "type": "command", "id": 1, "op": op, **fields}


def manual(controller):
    assert controller.apply(command("manual_unlock"))["ok"]
    assert controller.apply(command("mode", value="manual"))["ok"]


def test_manual_requires_unlock_and_auto_clears_it():
    controller = SimulatedController()
    assert not controller.apply(command("mode", value="manual"))["ok"]
    assert controller.telemetry()["mode"] == "auto"
    manual(controller)
    assert controller.telemetry()["manual_authorized"] is True
    assert controller.apply(command("mode", value="auto"))["ok"]
    assert controller.telemetry()["manual_authorized"] is False
    assert not controller.apply(command("mode", value="manual"))["ok"]


def test_auto_forbids_direct_outputs_and_preserves_exhaust_priority():
    controller = SimulatedController()
    assert not controller.apply(
        command("outputs", fans=[0, 0, 255], fan_power=True, peltier=255)
    )["ok"]
    assert controller.apply(command("setpoints", temperature=18.0, pressure=-35.0))["ok"]
    for _ in range(150):
        controller.advance(0.25)
        state = controller.telemetry()
        assert state["fans"][0] > state["fans"][2]
        assert state["fans"][1] > state["fans"][2]
        assert state["fan_power"] is True


def test_manual_outputs_remain_independent_without_timeout():
    controller = SimulatedController()
    manual(controller)
    requested = {"fans": [0, 1, 255], "fan_power": True, "peltier": 231}
    assert controller.apply(command("outputs", **requested))["ok"]
    for _ in range(20):
        controller.advance(120.0)
    state = controller.telemetry()
    assert state["mode"] == "manual"
    assert state["manual_authorized"] is True
    for key, value in requested.items():
        assert state[key] == value


@pytest.mark.parametrize(
    "fields",
    [
        {"fans": [-1, 0, 0], "fan_power": True, "peltier": 0},
        {"fans": [0, 256, 0], "fan_power": True, "peltier": 0},
        {"fans": [0, 0], "fan_power": True, "peltier": 0},
        {"fans": [True, 0, 0], "fan_power": True, "peltier": 0},
        {"fans": [0, 0, 0], "fan_power": [True, True, 1], "peltier": 0},
        {"fans": [0, 0, 0], "fan_power": [True, True, True], "peltier": 0},
        {"fans": [0, 0, 0], "fan_power": 1, "peltier": 0},
        {"fans": [0, 0, 0], "fan_power": True, "peltier": 256},
    ],
)
def test_invalid_outputs_do_not_partially_change_state(fields):
    controller = SimulatedController()
    manual(controller)
    before = copy.deepcopy(controller.telemetry())
    assert not controller.apply(command("outputs", **fields))["ok"]
    after = controller.telemetry()
    for key in ("fans", "fan_power", "peltier"):
        assert after[key] == before[key]


def test_pid_and_calibration_require_manual_and_validate_domain():
    controller = SimulatedController()
    assert not controller.apply(command("pid", loop="pressure", kp=2, ki=1, kd=0))["ok"]
    manual(controller)
    assert controller.apply(command("pid", loop="pressure", kp=2.5, ki=0.4, kd=0.1))["ok"]
    assert controller.telemetry()["pid"]["pressure"] == {"kp": 2.5, "ki": 0.4, "kd": 0.1}
    assert not controller.apply(command("pid", loop="pressure", kp=-1, ki=0, kd=0))["ok"]
    assert not controller.apply(command("calibrate", channel=7, offset=0, scale=1))["ok"]
    assert not controller.apply(command("calibrate", channel=0, offset=0, scale=0))["ok"]
    assert controller.apply(command("calibrate", channel=0, offset=1234, scale=0.002))["ok"]


def test_command_rejects_nonfinite_setpoints():
    controller = SimulatedController()
    before = controller.telemetry()["setpoints"].copy()
    assert not controller.apply(command("setpoints", temperature=float("nan"), pressure=-10))["ok"]
    assert not controller.apply(command("setpoints", temperature=22, pressure=float("inf")))["ok"]
    assert controller.telemetry()["setpoints"] == before


def test_pressure_pid_uses_room_six_relative_to_ambient():
    reference = SimulatedController()
    changed_other_rooms = SimulatedController()
    changed_other_rooms.pressure[:5] = [200, -200, 300, -300, 400]
    reference.advance(0.01)
    changed_other_rooms.advance(0.01)
    assert reference.telemetry()["fans"] == changed_other_rooms.telemetry()["fans"]
    more_negative = SimulatedController()
    assert more_negative.apply(command("setpoints", temperature=22, pressure=-40))["ok"]
    more_negative.advance(0.01)
    assert more_negative.telemetry()["fans"][0] > reference.telemetry()["fans"][0]
    shifted_reference = SimulatedController()
    shifted_reference.pressure = [pressure + 100 for pressure in shifted_reference.pressure]
    shifted_reference.advance(0.01)
    assert shifted_reference.telemetry()["fans"] == reference.telemetry()["fans"]


def test_temperature_pid_uses_all_six_temperatures_mean():
    mixed = SimulatedController()
    uniform = SimulatedController()
    mixed.temperature = [18, 20, 22, 24, 26, 28]
    uniform.temperature = [23] * 6
    mixed.advance(0.01)
    uniform.advance(0.01)
    assert mixed.telemetry()["peltier"] == uniform.telemetry()["peltier"]
    lower_target = SimulatedController()
    lower_target.temperature = [23] * 6
    assert lower_target.apply(command("setpoints", temperature=18, pressure=-10))["ok"]
    lower_target.advance(0.01)
    assert lower_target.telemetry()["peltier"] > uniform.telemetry()["peltier"]


def test_ds18b20_roms_require_crc_and_unique_room_assignment():
    controller = SimulatedController()
    manual(controller)
    addresses = controller.telemetry()["temperature_addresses"]
    assert not controller.apply(command("temperature_address", channel=0, address="2800000000000000"))["ok"]
    assert not controller.apply(command("temperature_address", channel=0, address=addresses[1]))["ok"]
    assert controller.apply(command("temperature_address", channel=0, address=addresses[0]))["ok"]


def test_extreme_calibration_cannot_break_demo_telemetry():
    controller = SimulatedController()
    manual(controller)
    ack = controller.apply(command("calibrate", channel=0, offset=0, scale=1e-320))
    # Values outside the AVR numeric domain may be rejected. If accepted, they
    # must still leave the simulated serial endpoint able to emit valid JSON.
    assert type(ack["ok"]) is bool
    json.dumps(controller.telemetry(), allow_nan=False)


def test_common_power_switches_all_fans_without_changing_manual_pwm():
    controller = SimulatedController()
    manual(controller)
    requested = {"fans": [0, 51, 255], "fan_power": False, "peltier": 113}
    assert controller.apply(command("outputs", **requested))["ok"]
    controller.advance(2.0)
    state = controller.telemetry()
    assert state["fan_power"] is False
    assert state["fans"] == [0, 51, 255]
    assert state["peltier"] == 113
    assert state["fan_rpm"] == [0, 0, 0]
    requested["fan_power"] = True
    assert controller.apply(command("outputs", **requested))["ok"]
    controller.advance(2.0)
    state = controller.telemetry()
    assert state["fan_power"] is True
    assert state["fan_rpm"][2] > 0


def test_tach_configuration_requires_manual_and_has_three_independent_channels():
    controller = SimulatedController()
    assert not controller.apply(command("tach", channel=0, pulses_per_rev=4))["ok"]
    manual(controller)
    initial = controller.telemetry()["tach_ppr"].copy()
    assert controller.apply(command("tach", channel=1, pulses_per_rev=4))["ok"]
    expected = initial.copy()
    expected[1] = 4
    assert controller.telemetry()["tach_ppr"] == expected


@pytest.mark.parametrize("channel,ppr", [
    (-1, 2), (3, 2), (True, 2), (0, 0), (0, 256),
    (0, True), (0, 2.5), (0, float("nan")), (0, float("inf")),
])
def test_invalid_tach_configuration_has_no_partial_effect(channel, ppr):
    controller = SimulatedController()
    manual(controller)
    original = controller.telemetry()["tach_ppr"].copy()
    assert not controller.apply(command("tach", channel=channel, pulses_per_rev=ppr))["ok"]
    assert controller.telemetry()["tach_ppr"] == original


def test_simulator_identifies_nb3_and_rejects_legacy_commands():
    controller = SimulatedController()
    state = controller.telemetry()
    assert state["v"] == 2
    assert state["hardware"] == "NB3"
    assert type(state["fan_power"]) is bool
    assert len(state["fan_rpm"]) == 3
    assert not controller.apply({"v": 1, "type": "command", "id": 1, "op": "manual_unlock"})["ok"]
