# TCC NB3 — Arduino Mega 2560 e Raspberry Pi 3B

Sistema local de monitoramento e controle de seis salas de uma maquete. O Mega lê os sensores e controla as saídas; a Raspberry Pi apresenta a interface touch e guarda históricos, usuários e alarmes. A comunicação é por USB serial, sem servidor web ou dependência de Internet para operar.

A interface é um **programa Python/Tkinter**, adequado à Raspberry Pi 3B e às versões de 32 ou 64 bits do Raspberry Pi OS que ofereçam Python 3.9 ou superior. A tela abre somente pelo ícone ou comando de execução. Há um botão **Sair**; não há inicialização automática.

Os comandos **Automático** e **Manual · ADMIN** ficam dentro da aba **Manutenção**, junto ao estado da conexão e às informações dos atuadores. O cabeçalho contém somente a marca UNISAL no canto superior esquerdo e os comandos de sessão. A interface foi ajustada para tela touch de 7″: leituras com fonte de 20 pontos em 800×480, pressão e temperatura em linhas separadas, nomes maiores e campos/botões ampliados. A planta preserva os setpoints e os limites de pressão e temperatura. Os ambientes têm cores próprias, com indicação textual de **SEM DADOS/ANTERIOR** e **ALARME** quando necessário.

Em telas de até 1024×600, a aplicação ocupa a tela inteira ao abrir pelo ícone. O botão **Sair** permanece no cabeçalho; **Esc** retorna à janela e **F11** alterna tela cheia. A manutenção oferece setas grandes para rolar as páginas e também aceita a roda do mouse. Os gráficos exibem temperatura em laranja, pressão em azul, setpoints em verde e os limites atuais em vermelho. Veja [docs/interface.md](docs/interface.md).

Os controles e os estados PWM dos ventiladores usam **0 a 100%**. O Peltier usa somente **Liga/Desliga**. A conversão para os códigos de 8 bits é feita apenas na apresentação: firmware, protocolo e colunas PWM do CSV continuam usando 0 a 255. Por exemplo, 50% é enviado como 128; a leitura desse código corresponde a aproximadamente 50,2%. Os controles aceitam também percentuais fracionários.

A imagem UNISAL foi preparada a partir da referência fornecida pelo usuário e já está incluída. Para usar outro PNG, informe:

```bash
bash scripts/run.sh --unisal-logo /caminho/da/marca-unisal.png
```

Também é possível substituir `raspberry/tcc_monitor/assets/unisal.png`, para a imagem aparecer pelo atalho da área de trabalho. Créditos dos elementos visuais: [assets/README.md](raspberry/tcc_monitor/assets/README.md).

## O que está implementado

- Firmware em uma única aba: [mega_controller.ino](firmware/mega_controller/mega_controller.ino).
- Seis DS18B20, associados às salas pelo endereço ROM, e sete módulos de pressão HX710B: seis salas e uma referência ambiente.
- Três ventoinhas com PWM independente e tacômetros; um único IRF4905 liga/desliga a alimentação das três juntas. Peltier com saída digital Liga/Desliga em D5.
- PID de pressão baseado em **P6/Laboratório 2** e controle térmico Liga/Desliga baseado na média dos seis DS18B20.
- Modo automático com PWM das duas exaustoras estritamente maior que o do insuflamento. PWM maior não comprova maior vazão: a pressão negativa precisa ser confirmada nas medições.
- Modo manual ADMIN com três PWMs independentes, alimentação comum das ventoinhas e Peltier, sem intertravamento entre os atuadores, temporizador de sessão ou desligamento por perda de comunicação.
- Planta esquemática de seis salas, temperaturas, pressões diferenciais, setpoints, limites, gráficos por sala, manutenção, usuários, log de alarmes e exportação CSV.

A planta segue a disposição fornecida, de forma esquemática e sem escala arquitetônica. As três colunas têm larguras aproximadas de 32%, 34% e 34%; na esquerda, Laboratório 1 ocupa a parte superior e Laboratório 2 a inferior; no centro, Corredor Central acima de Autoclave; na direita, Desparamentação acima de Paramentação:

```text
┌──────────────────┬───────────────────┬───────────────────┐
│ Laboratório 1 P5 │ Corredor Central  │ Desparamentação   │
│                  │ P3                │ P2                │
├──────────────────┤                   │                   │
│ Laboratório 2 P6 │                   ├───────────────────┤
│                  │                   │ Paramentação P1   │
│                  ├───────────────────┤                   │
│                  │ Autoclave P4      │                   │
└──────────────────┴───────────────────┴───────────────────┘
```

A associação dos canais foi confirmada: **P1 Paramentação, P2 Desparamentação, P3 Corredor Central, P4 Sala de Autoclave, P5 Laboratório 1, P6 Laboratório 2**. P6 permanece a referência do PID; o nome/posição gráfica não redefine o canal físico. A pinagem NB3 está em [docs/wiring.md](docs/wiring.md); calibre e valide a montagem seguindo [docs/commissioning.md](docs/commissioning.md).

## Teclado numérico e Peltier

Na versão 0.4.0, tocar num campo numérico editável abre o teclado numérico. Concluir apenas preenche o campo; Aplicar saídas envia o comando. Cancelar preserva o valor anterior. O Peltier tem a opção Ligar e indicação do estado recebido do Arduino, sem campo de percentual.

No automático, o Peltier resfria usando a média dos seis sensores: liga acima do setpoint + 0,5°C, desliga ao atingir o setpoint e conserva o estado entre esses valores. Sem média válida, conserva a última saída. O PID ajustável continua sendo o da pressão P6. Esta mudança exige gravar o novo firmware para valer também no automático; o layout EEPROM v2 foi mantido. Consulte [a atualização por SSH](docs/update-0.4.md).

## Instalar na Raspberry Pi

O pacote `tcc-nb3-raspberry.zip` inclui o instalador, dependência Python para instalação offline e o firmware compilado. Copie pelo pendrive e extraia a pasta `TCC-NB3` na pasta pessoal da Pi. Siga [docs/installation.md](docs/installation.md). No Raspberry Pi OS 64 bits com desktop, entre como `beck` e execute:

```bash
cd ~/TCC-NB3
bash scripts/install_raspberry.sh
```

O instalador prepara pacotes do sistema e a `.venv`, configura o acesso serial e cria o ícone de desktop. Ele não inicia a aplicação, não grava o Mega e não apaga bancos existentes. Execute sem `sudo`; apenas as operações do sistema pedirão a elevação necessária. Para instalação manual:

Use Raspberry Pi OS com ambiente gráfico. No diretório do projeto:

```bash
sudo apt update
sudo apt install python3-venv python3-tk
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Tkinter, SQLite e as ferramentas de gráficos fazem parte do Python/sistema. A única dependência Python de execução adicional é `pyserial==3.5`. A biblioteca GPIO da Pi não é necessária: as entradas e saídas físicas são controladas pelo Mega.

Para acesso serial, adicione o usuário de desktop ao grupo correspondente e encerre/inicie a sessão:

```bash
sudo usermod -aG dialout "$USER"
```

Depois, conecte o cabo USB e identifique o dispositivo estável:

```bash
ls -l /dev/serial/by-id/
bash scripts/run.sh --port /dev/serial/by-id/SEU_DISPOSITIVO
```

O programa pode procurar a porta se `--port` for omitido. Em uma instalação com vários conversores USB, prefira informar `/dev/serial/by-id/...`. A abertura de certas placas Mega/USB pode reiniciar o microcontrolador pelo circuito de auto-reset; confira a montagem antes da primeira conexão. O programa não reenvia comandos de atuação antigos ao reconectar.

Para testar a interface sem placas:

```bash
bash scripts/run.sh --demo
```

O modo `--demo` utiliza por padrão um banco separado, em `~/.local/share/tcc-monitor-demo/monitor.sqlite3`. Seus dados não comprovam leitura dos sensores ou atuação real. O atalho de produção não utiliza esse argumento.

## Ícone na área de trabalho

Depois de instalar as dependências:

```bash
bash scripts/install_desktop.sh
```

Será criado `tcc-monitor.desktop` na pasta de desktop do usuário. Clique no ícone para abrir. Dependendo do ambiente gráfico, selecione “Permitir iniciar” na primeira abertura. Não é criado serviço, tarefa de login ou arquivo de autostart. Para escolher outra pasta:

```bash
bash scripts/install_desktop.sh --desktop-dir /caminho/da/area-de-trabalho
```

O atalho acompanha o diretório atual do projeto; reinstale-o se mover a pasta. O lançador prioriza `.venv/bin/python`. Para outro interpretador, use `TCC_PYTHON=/caminho/python bash scripts/run.sh`. O botão **Sair** fecha o programa e a porta serial sem enviar um comando de desligamento: o Mega conserva seu estado enquanto não houver reset ou perda de alimentação. Após reset, o firmware reinicia no modo automático, com a configuração salva e sem sessão manual.

## Acessos e modos

O acesso inicial sem senha é **Operador**. O usuário inicial **ADMIN** tem a senha **15234**. Na primeira utilização, entre e altere essa senha na aba de usuários. As senhas são armazenadas como hashes PBKDF2 com salt no banco local, não como texto aberto. Alterar a senha afeta o login da interface; o Mega não guarda o cadastro de usuários.

O operador pode acompanhar medições e históricos, exportar dados, ajustar os setpoints e configurar a identificação/limites locais das salas. Para comandar diretamente PWM, alimentação das ventoinhas ou Peltier, autentique um administrador e ative **Manual**. Os campos manuais dos ventiladores usam 0 a 100%, com conversão para os limites físicos de PWM, sem impor relação entre as três ventoinhas. O controle de alimentação é único para as três ventoinhas, porque o NB3 usa um único IRF4905. PWM zero pode não parar uma ventoinha; desligar `fan_power` corta a alimentação das três em conjunto. Desligamento elétrico individual exigiria três estágios de potência.

No **Automático**, as saídas são calculadas pelo Mega e o usuário altera os setpoints. O ajuste de ganhos PID, calibração, associação de ROMs e pulsos por volta dos tacômetros é realizado em manutenção no modo manual autorizado. A ação “Salvar controlador” grava setpoints, PID, calibração, ROMs e pulsos por volta em EEPROM; não grava saídas, autorização ADMIN ou modo manual. Essa gravação é explícita, evitando escrita contínua na EEPROM. O layout EEPROM do NB3 é versão 2: uma configuração antiga é descartada, e os ajustes precisam ser conferidos e salvos novamente.

Não há expiração de sessão nem troca automática para o modo automático ao fechar/desconectar a interface. A idade da telemetria é sinalizada ao usuário, sem impor um bloqueio temporal adicional aos comandos manuais. Logout encerra o acesso administrativo da interface, sem alterar as saídas em execução. Quem tem acesso direto à porta USB ou ao sistema da Pi pode produzir comandos de protocolo; USB e processos locais são considerados confiáveis. A autenticação da interface não substitui isolamento do sistema operacional.

As validações de mensagens rejeitam tipos incorretos, números não finitos ou não representáveis no firmware e valores fora do domínio físico de PWM. Essas validações do formato/protocolo não limitam o processo a uma faixa arbitrária de temperatura ou pressão e não acrescentam intertravamentos de atuação no modo manual.

## Calibração de pressão pela interface

Abra **Manutenção → Calibração**, entre como ADMIN e selecione Manual. Escolha P1–P7, capture duas pressões de referência conhecidas e use **Calcular → Aplicar calibração → Salvar no Arduino**. A coleta permite a média de 1 a 30 novas leituras, e a interface aguarda a confirmação do controlador. Há também **Zerar canal**, que prepara o ajuste de zero preservando a escala já calibrada.

Com o firmware NB3 instalado, esses ajustes não exigem alterar ou reenviar o sketch. O procedimento completo, incluindo a diferença entre aplicar na memória atual e gravar após reiniciar, está em [docs/calibration.md](docs/calibration.md).

## Preparar e compilar o Arduino

Abra `firmware/mega_controller/mega_controller.ino` no Arduino IDE, selecione **Arduino Mega or Mega 2560 / ATmega2560** e instale as bibliotecas listadas em `firmware/dependencies.txt`. Todo o código do controlador fica nessa aba.

Com Arduino CLI:

```bash
arduino-cli core update-index
arduino-cli core install arduino:avr@1.8.6
arduino-cli lib install 'ArduinoJson@6.21.5' 'OneWire@2.3.8' 'DallasTemperature@4.0.6'
arduino-cli compile --fqbn arduino:avr:mega:cpu=atmega2560 --jobs 2 \
  --build-path /tmp/tcc-mega-build firmware/mega_controller
arduino-cli upload --fqbn arduino:avr:mega:cpu=atmega2560 \
  --port /dev/ttyACM0 --input-dir /tmp/tcc-mega-build firmware/mega_controller
```

Escolha a porta real no upload. Só grave na placa depois de conferir [a ligação dos drivers de potência](docs/wiring.md). Os sketches são compilados para o Mega, mesmo quando o compilador é executado em x86_64; o aplicativo Python deve também ser validado na Pi física.

O ambiente de nuvem utiliza Arduino CLI 1.5.1 com checksum oficial. A instalação do core oficial `arduino:avr@1.8.6` por esse CLI exige acesso a `downloads.arduino.cc`; se a política negar esse domínio, essa rota fica bloqueada. Uma compilação com toolchain AVR/core empacotados pela distribuição é uma rota distinta: seu resultado não comprova instalação do core oficial 1.8.6. Não desative TLS ou validação de assinatura/checksum. Para o CLI usar o proxy da nuvem, preserve as variáveis da plataforma e defina `ARDUINO_NETWORK_PROXY="$HTTPS_PROXY"` somente naquele ambiente.

## Dados, alarmes e protocolo

Os dados de produção ficam em `~/.local/share/tcc-monitor/monitor.sqlite3`, em SQLite. O parâmetro `--data-dir /outro/diretorio` permite escolher um local separado para testes ou backup. Feche o programa antes de copiar o banco, ou use um backup consistente do SQLite. Não apague o diretório para corrigir uma conexão serial: ele contém usuários, limites e históricos.

A pressão exibida em cada sala é relativa ao sensor 7: `pressão_sala - pressão_ambiente`, em Pa. Os MPS20N0040D-D são sensores diferenciais: as duas portas pneumáticas e a referência comum determinam o significado de cada leitura. O software não transforma esses módulos em sensores absolutos. Consulte o comissionamento para evitar subtrair o ambiente duas vezes. Sem calibração ou leitura válida, a interface mostra ausência de medida; zero não substitui um sensor ausente. Os alarmes são avaliados pela interface a partir da telemetria recebida e não comandam atuadores. Enquanto a Pi estiver fechada/desconectada, ela não registra novas amostras ou novos alarmes. Os valores mínimo/máximo dos alarmes não são intertravamentos.

Use a exportação CSV para salvar o histórico disponível: horários UTC, seis temperaturas, seis pressões diferenciais, sete pressões calibradas/contagens/estados de calibração, setpoints, modo, PWMs, alimentação comum, RPM/pulsos por volta, Peltier e ganhos PID. O protocolo **v2** exige identificação de hardware **NB3** na telemetria; aplicação e firmware devem ser atualizados juntos. Os comandos, ACKs, unidades e regras de autorização estão descritos em [docs/protocol.md](docs/protocol.md). O programa só confirma comandos após a resposta do Mega; sem ACK, confira a telemetria e não presuma que a mudança ocorreu.

## Validação

Na versão NB3, **261 testes Python passaram**, cobrindo comunicação pyserial por pseudo-terminal, autorização, protocolo v2, alimentação comum, RPM/PPR, migração do banco, conversão dos controles percentuais e cálculo/zeragem da calibração. A interface passou por teste gráfico em **800×480**, incluindo a planta ampliada, a marca UNISAL, controles em porcentagem e fluxo completo de calibração com confirmação de comandos. Um harness externo executando o `.ino` real, com hardware simulado, passou em **273 verificações**. Esses testes não validam os circuitos físicos.

```bash
.venv/bin/python -m pip install pytest
PYTHONPATH=raspberry .venv/bin/python -m pytest -q
```

A compilação NB3 para o Mega passou: **24.552 bytes de flash** e **5.311/8.192 bytes de SRAM**, restando 2.881 bytes para pilha/heap. A rota de compilação disponível na nuvem usa **AVR GCC 14.2**, core Arduino distribuído pelo Debian **1.8.7+dfsg-1~deb13u1** e as bibliotecas fixadas acima. Os pacotes foram obtidos com metadados APT oficiais assinados e checksums verificados. O helper local é `/workspace/.cloud-setup/tcc/build-firmware-debian.sh`; é uma ferramenta dessa máquina, não um caminho existente na Pi nem um substituto para a instalação Arduino IDE/CLI descrita acima.

O core oficial `arduino:avr@1.8.6` continua sem validação nessa máquina devido ao bloqueio de `downloads.arduino.cc`. Os ensaios de software e de tela virtual não validam toque, execução na Pi física, carga máxima dinâmica de memória ou funcionamento elétrico.

Verifique também a interface em uma tela de 800×480 ou superior, a associação física das ROMs, a calibração dos sete canais, o sentido do PWM, o acionamento dos MOSFETs, a capacidade da fonte e a resposta do PID de pressão e do controle térmico. O controle térmico inicial supõe que o Peltier esteja montado para **resfriar** o ar insuflado; aquecimento/reversão de polaridade não são implementados.
