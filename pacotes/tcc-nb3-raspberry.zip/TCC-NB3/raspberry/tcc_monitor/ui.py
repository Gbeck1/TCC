"""Touch-friendly Tk interface; serial work and persistence live in service.py."""

from __future__ import annotations

import math
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter import font as tkfont

from .service import AppError
from .units import percent_to_pwm, pwm_to_percent
from .calibration_ui import PressureCalibration
from .keyboard import NumericKeypad


BG = "#edf3fa"
INK = "#19334f"
BLUE = "#1967b4"
RED = "#ba3447"
GREEN = "#187957"
NAVY = "#133556"
AMBER = "#ad5e0d"
MUTED = "#5c7289"
ROOM_COLORS = {
    "laboratory_1": ("#2679b4", "#edf7ff"),
    "laboratory_2": ("#465bb2", "#f0f1ff"),
    "corridor": ("#507c99", "#f0f7fb"),
    "autoclave": ("#b77b24", "#fff7e8"),
    "gowning": ("#16857a", "#eaf8f5"),
    "degowning": ("#a65c86", "#fff0f7"),
}

LOCATIONS = (
    ("laboratory_1", "Laboratório 1"),
    ("laboratory_2", "Laboratório 2"),
    ("corridor", "Corredor"),
    ("autoclave", "Autoclave"),
    ("gowning", "Paramentação"),
    ("degowning", "Desparamentação"),
)
LOCATION_LABELS = dict(LOCATIONS)
LOCATION_KEYS = {label: key for key, label in LOCATIONS}
DEFAULT_LOCATIONS = ("gowning", "degowning", "corridor", "autoclave", "laboratory_1", "laboratory_2")
# Normalized room rectangles follow the supplied laboratory plan, independently
# of which sensor channel the operator associates with each physical location.
ROOM_BOUNDS = {
    "laboratory_1": (0.0, 0.0, .32, .50),
    "laboratory_2": (0.0, .50, .32, 1.0),
    "corridor": (.32, 0.0, .66, .50),
    "autoclave": (.32, .50, .66, 1.0),
    "degowning": (.66, 0.0, 1.0, .50),
    "gowning": (.66, .50, 1.0, 1.0),
}


def number(value, digits=1):
    """Missing data stays visibly missing instead of becoming a fabricated zero."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return "--"
    return f"{value:.{digits}f}" if math.isfinite(value) else "--"


def at(values, index):
    return values[index] if isinstance(values, (list, tuple)) and len(values) > index else None


def reading(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return "--"
    if abs(value) >= 100000:
        return f"{value:.3g}"
    text = f"{value:.1f}".rstrip("0").rstrip(".")
    return "0" if text == "-0" else text


def percent_text(value):
    return "--" if value is None else f"{pwm_to_percent(value):.1f}".rstrip("0").rstrip(".")


def decimal(value):
    """Accept both Portuguese decimal commas and decimal points in touch forms."""
    parsed = float(str(value).replace(",", "."))
    if not math.isfinite(parsed):
        raise ValueError("Digite um número finito.")
    return parsed


def timestamp(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            return datetime.fromtimestamp(value).strftime("%d/%m/%Y %H:%M:%S")
        except (OverflowError, OSError, ValueError):
            pass
    return str(value)


class ScrollFrame(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, highlightthickness=0, background=BG)
        navigation = ttk.Frame(self)
        ttk.Button(navigation, text="▲", width=2, style="Scroll.TButton",
                   command=lambda: self.canvas.yview_scroll(-3, "units")).pack(fill="x")
        scrollbar = ttk.Scrollbar(navigation, orient="vertical", command=self.canvas.yview)
        scrollbar.pack(fill="y", expand=True)
        ttk.Button(navigation, text="▼", width=2, style="Scroll.TButton",
                   command=lambda: self.canvas.yview_scroll(3, "units")).pack(fill="x")
        self.content = ttk.Frame(self.canvas, padding=10)
        self.window = self.canvas.create_window(0, 0, window=self.content, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        navigation.pack(side="right", fill="y")
        self.content.bind("<Configure>", lambda _: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.window, width=e.width))

    @staticmethod
    def wheel(event):
        widget = event.widget
        while widget is not None and not isinstance(widget, ScrollFrame):
            widget = getattr(widget, "master", None)
        if widget is not None:
            step = -1 if getattr(event, "num", None) == 4 or getattr(event, "delta", 0) > 0 else 1
            widget.canvas.yview_scroll(step * 3, "units")
            return "break"


class FormDialog(tk.Toplevel):
    """Forms keep their own validation state, with the shared touch keyboard."""

    def __init__(self, app, title, fields, submit, action="Confirmar"):
        super().__init__(app)
        self.app = app
        self.title(app.window_title(title))
        self.transient(app)
        self.resizable(False, False)
        body = ttk.Frame(self, padding=14)
        body.pack(fill="both", expand=True)
        self.values = {}
        for row, (key, label, default, secret) in enumerate(fields, 1):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=6)
            value = tk.StringVar(value=str(default))
            entry = ttk.Entry(body, textvariable=value, width=25, show="●" if secret else "")
            entry.grid(row=row, column=1, sticky="ew", pady=6)
            self.values[key] = value
            if row == 1:
                entry.focus_set()
        row = len(fields) + 1
        controls = ttk.Frame(body)
        controls.grid(row=row, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        ttk.Button(controls, text="Teclado", command=app.show_keyboard).pack(side="left")
        ttk.Button(controls, text="Cancelar", command=self.destroy).pack(side="right", padx=3)

        def accept():
            try:
                submit({key: value.get() for key, value in self.values.items()})
            except (AppError, ValueError, TypeError) as exc:
                messagebox.showerror(app.window_title("Não foi possível concluir"), str(exc), parent=self)
            else:
                self.destroy()
                app.refresh_lists()

        ttk.Button(controls, text=action, command=accept).pack(side="right", padx=3)
        self.bind("<Return>", lambda _: accept())
        self.bind("<Escape>", lambda _: self.destroy())
        self.update_idletasks()
        x = app.winfo_rootx() + max(0, (app.winfo_width() - self.winfo_width()) // 2)
        y = app.winfo_rooty() + max(0, (app.winfo_height() - self.winfo_height()) // 2)
        self.geometry(f"+{x}+{y}")


class GraphWindow(tk.Toplevel):
    def __init__(self, app, room):
        super().__init__(app)
        self.app, self.room = app, room
        self.title(app.window_title(f"Histórico · P{room['id']}/T{room['id']} · {room['name']}"))
        self.geometry(f"{min(app.winfo_screenwidth(), 960)}x{min(app.winfo_screenheight(), 560)}+0+0")
        self.minsize(760, 440)
        self.configure(background=BG)
        self.transient(app)
        self.attributes("-fullscreen", bool(app.attributes("-fullscreen")))
        header = tk.Frame(self, background=NAVY, padx=10, pady=5)
        header.pack(fill="x")
        brand = tk.Canvas(header, width=164, height=44, background="white", highlightthickness=0)
        brand.pack(side="left", padx=(0, 12))
        app._draw_branding(brand, 0, 0, 164, 44)
        self.heading = tk.Label(header, text="", font=("DejaVu Sans", 15, "bold"),
                                foreground="white", background=NAVY, anchor="w", justify="left")
        self.heading.pack(side="left", fill="x", expand=True)
        ttk.Button(header, text="Voltar", style="Toolbar.TButton", command=self.destroy).pack(side="right", padx=(8, 0))
        self.temperature = tk.Canvas(self, background="white", highlightthickness=0, height=150)
        self.pressure = tk.Canvas(self, background="white", highlightthickness=0, height=150)
        self.temperature.pack(fill="both", expand=True, padx=10, pady=(8, 4))
        self.pressure.pack(fill="both", expand=True, padx=10, pady=(4, 4))
        self.caption = ttk.Label(self, text="", font=("DejaVu Sans", 11))
        self.caption.pack(fill="x", padx=12, pady=(0, 5))
        self._timer = None
        self.bind("<Destroy>", self._destroyed)
        self.bind("<Escape>", lambda _: self.destroy())
        self.temperature.bind("<Configure>", lambda _: self._redraw())
        self.pressure.bind("<Configure>", lambda _: self._redraw())
        self._history = []
        self.refresh()

    def _destroyed(self, event):
        if event.widget is self and self._timer:
            self.after_cancel(self._timer)
            self._timer = None

    def refresh(self):
        try:
            self.room = next((room for room in self.app.service.rooms() if room["id"] == self.room["id"]), self.room)
            self.title(self.app.window_title(f"Histórico · P{self.room['id']}/T{self.room['id']} · {self.room['name']}"))
            self.heading.configure(text=f"{self.room['name']}\nHistórico · P{self.room['id']} / T{self.room['id']}")
            history = self.app.service.history(self.room["id"], limit=300)
            self._history = history
            self._redraw()
            span = (f"{datetime.fromtimestamp(history[0]['timestamp']).strftime('%H:%M:%S')} – "
                    f"{datetime.fromtimestamp(history[-1]['timestamp']).strftime('%H:%M:%S')}"
                    if history else "Sem amostras registradas")
            self.caption.configure(text=f"{len(history)} amostras · {span}")
        except (AppError, KeyError, TypeError) as exc:
            self.caption.configure(text=str(exc))
        self._timer = self.after(2000, self.refresh)

    def _redraw(self):
        setpoints = (self.app.service.snapshot or {}).get("setpoints", {})
        self._plot(self.temperature, self._history, "temperature", "Temperatura", "#bd6617", "°C",
                   setpoints.get("temperature"), (self.room["temp_min"], self.room["temp_max"]))
        self._plot(self.pressure, self._history, "pressure", "Pressão diferencial", BLUE, "Pa",
                   setpoints.get("pressure"), (self.room["pressure_min"], self.room["pressure_max"]))

    @staticmethod
    def _plot(canvas, rows, field, title, color, unit="", setpoint=None, limits=None):
        canvas.delete("all")
        width, height = max(canvas.winfo_width(), 300), max(canvas.winfo_height(), 120)
        left, right, top, bottom = 70, width - 24, 57, height - 27
        canvas.create_rectangle(0, 0, 5, height, fill=color, outline="")
        canvas.create_text(15, 5, text=title, anchor="nw", font=("DejaVu Sans", 14, "bold"), fill=INK)
        values = [row.get(field) for row in rows]
        current = values[-1] if values else None
        canvas.create_text(width - 16, 2, text=f"{reading(current)} {unit}", anchor="ne",
                           font=("DejaVu Sans", 19, "bold"), fill=color)
        canvas.create_text(15, 30, text=f"SP: {reading(setpoint)} {unit}", anchor="nw",
                           font=("DejaVu Sans", 11), fill=GREEN)
        if limits is not None:
            canvas.create_text(215, 30, text=f"Limites: {reading(limits[0])} a {reading(limits[1])} {unit}",
                               anchor="nw", font=("DejaVu Sans", 11), fill=RED)
        valid = [v for v in values if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)]
        if not valid:
            canvas.create_text(width / 2, (top + bottom) / 2, text="Sem medida válida", fill=MUTED,
                               font=("DejaVu Sans", 13))
            return
        # Follow the measured variation and the target so small temperature or
        # pressure changes remain visible on the 7-inch display.
        references = [setpoint]
        extent = valid + [v for v in references if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)]
        low, high = min(extent), max(extent)
        margin = max((high - low) * .1, .5)
        low, high = low - margin, high + margin
        for i in range(3):
            y = top + (bottom - top) * i / 2
            canvas.create_line(left, y, right, y, fill="#e0e6eb")
            canvas.create_text(left - 8, y, anchor="e", text=reading(high - (high-low)*i/2), fill=INK,
                               font=("DejaVu Sans", 11))
        canvas.create_line(left, top, left, bottom, right, bottom, fill="#91a4b0")
        for reference, reference_color in [(setpoint, GREEN)] + [(v, RED) for v in limits or ()]:
            if (isinstance(reference, (int, float)) and not isinstance(reference, bool)
                    and math.isfinite(reference) and low <= reference <= high):
                y = bottom - (bottom - top) * (reference - low) / (high - low)
                canvas.create_line(left, y, right, y, fill=reference_color, dash=(5, 4))
        first_time = rows[0].get("timestamp")
        last_time = rows[-1].get("timestamp")
        use_time = (all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
                        for v in (first_time, last_time)) and last_time > first_time)
        if use_time:
            for tick in range(4):
                instant = first_time + (last_time - first_time) * tick / 3
                canvas.create_text(left + (right - left) * tick / 3, height - 7,
                                   text=datetime.fromtimestamp(instant).strftime("%H:%M:%S"),
                                   anchor="sw" if tick == 0 else "se" if tick == 3 else "s",
                                   font=("DejaVu Sans", 11), fill=MUTED)
        previous = None
        for index, value in enumerate(values):
            if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
                previous = None
                continue
            fraction = ((rows[index]["timestamp"] - first_time) / (last_time - first_time)
                        if use_time else index / max(1, len(values) - 1))
            x = left + (right - left) * fraction
            y = bottom - (bottom - top) * (value - low) / (high - low)
            if previous:
                canvas.create_line(*previous, x, y, fill=color, width=3)
            else:
                canvas.create_oval(x - 2, y - 2, x + 2, y + 2, fill=color, outline=color)
            previous = x, y


class MonitorApp(tk.Tk):
    def __init__(self, service, *, demo=False, fullscreen=False, unisal_logo=None):
        super().__init__()
        self.service = service
        self.demo = demo
        self._keyboard = None
        self._numeric_keyboard = None
        self._entry = None
        self._timer = None
        self._last_seq = None
        self._logged_in = False
        self._ticks = 0
        self._plant_rooms = []
        self._graph_windows = {}
        self._brand_image = None
        self.title(self.window_title("TCC NB3 · Monitoramento e controle"))
        self.geometry("800x480")
        self.minsize(800, 480)
        self.configure(background=BG)
        compact_display = self.winfo_screenwidth() <= 1024 and self.winfo_screenheight() <= 600
        self.attributes("-fullscreen", fullscreen or compact_display)
        self.protocol("WM_DELETE_WINDOW", self.request_close)
        self.bind("<Escape>", lambda _: self.attributes("-fullscreen", False))
        self.bind("<F11>", lambda _: self.attributes("-fullscreen", not self.attributes("-fullscreen")))
        self.bind_all("<FocusIn>", self._remember_entry, add="+")
        for sequence in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.bind_all(sequence, ScrollFrame.wheel, add="+")
        self._style()
        self._room_title_font = tkfont.Font(family="DejaVu Sans", size=12, weight="bold")
        self._reading_fonts = {size: tkfont.Font(family="DejaVu Sans", size=size, weight="bold") for size in (20, 22, 24)}
        self._detail_font = tkfont.Font(family="DejaVu Sans", size=11)
        self._load_branding(unisal_logo)
        self._header()
        self.message = tk.StringVar(value="")
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, padx=8, pady=(2, 0))
        self.plant = ttk.Frame(self.tabs)
        self.maintenance_panel = ttk.Frame(self.tabs)
        ttk.Label(self.maintenance_panel, textvariable=self.message, anchor="w", font=("DejaVu Sans", 11),
                  wraplength=750).pack(side="bottom", fill="x", padx=10, pady=3)
        self.maintenance_controls = ttk.Frame(self.maintenance_panel, padding=(10, 5), style="White.TFrame")
        self.maintenance_controls.pack(fill="x")
        self.maintenance = ttk.Notebook(self.maintenance_panel)
        self.maintenance.pack(fill="both", expand=True, pady=(4, 0))
        self.alarms = ttk.Frame(self.tabs, padding=8)
        self.user_tab = ttk.Frame(self.tabs, padding=8)
        for child, title in [(self.plant, "Planta"), (self.maintenance_panel, "Manutenção"),
                             (self.alarms, "Alarmes / CSV"), (self.user_tab, "Usuários")]:
            self.tabs.add(child, text=title)
        self._make_plant()
        self._make_maintenance()
        self._make_alarms()
        self._make_users()
        self.refresh_lists()
        self._poll()

    def window_title(self, text):
        return text

    def _load_branding(self, filename):
        """Use an authentic supplied PNG; the fallback is a textual identification."""
        path = Path(filename).expanduser() if filename else Path(__file__).parent / "assets" / "unisal.png"
        if not path.is_file():
            if filename:
                raise AppError(f"Imagem UNISAL não encontrada: {path}")
            return
        try:
            original = tk.PhotoImage(master=self, file=str(path))
            factor = max(1, math.ceil(max(original.width() / 138, original.height() / 44)))
            self._brand_image = original.subsample(factor, factor)
        except tk.TclError as exc:
            raise AppError("Não foi possível carregar a marca UNISAL. Use uma imagem PNG válida.") from exc

    def _draw_branding(self, canvas, left, top, width, height):
        if width < 140 or height < 36:
            return
        center_y = top + height / 2
        canvas.create_rectangle(left, top, left + width, top + height, fill="white", outline="#d8e5ee", tags="branding")
        if self._brand_image is not None:
            canvas.create_image(left + width / 2, center_y, image=self._brand_image, tags="branding")
        else:
            canvas.create_text(left + width / 2, center_y, text="UNISAL", fill=NAVY,
                               font=("DejaVu Sans", 20, "bold"), tags="branding")

    def _style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        for named in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont", "TkCaptionFont"):
            tkfont.nametofont(named).configure(family="DejaVu Sans", size=13)
        self.option_add("*TCombobox*Listbox.font", ("DejaVu Sans", 14))
        self.option_add("*TCombobox.font", ("DejaVu Sans", 14))
        self.option_add("*TEntry.font", ("DejaVu Sans", 14))
        style.configure(".", font=("DejaVu Sans", 13), background=BG, foreground=INK)
        style.configure("TButton", padding=(12, 10), background="#dceafb", foreground=NAVY,
                        borderwidth=0, font=("DejaVu Sans", 12, "bold"))
        style.map("TButton", background=[("disabled", "#e5e9ef"), ("pressed", "#c2d9f6"), ("active", "#cadef7")],
                  foreground=[("disabled", "#8492a5")])
        style.configure("Primary.TButton", background=BLUE, foreground="white")
        style.map("Primary.TButton", background=[("disabled", "#c7d4e3"), ("pressed", "#124d89"), ("active", "#2479ce")],
                  foreground=[("disabled", "#6d7f92"), ("!disabled", "white")])
        style.configure("Manual.TButton", background="#fff0d4", foreground="#89510d")
        style.map("Manual.TButton", background=[("disabled", "#e5e9ef"), ("active", "#ffe3ad")],
                  foreground=[("disabled", "#8492a5")])
        style.configure("Toolbar.TButton", background="#244e73", foreground="white", padding=(10, 10))
        style.configure("Scroll.TButton", padding=(8, 10), font=("DejaVu Sans", 13, "bold"))
        style.configure("TCombobox", padding=(7, 8), arrowsize=22, font=("DejaVu Sans", 14))
        style.configure("TCheckbutton", padding=(6, 10), indicatorsize=22)
        style.configure("Vertical.TScrollbar", arrowsize=22)
        style.map("Toolbar.TButton", background=[("active", "#386990"), ("pressed", "#244e73")],
                  foreground=[("!disabled", "white")])
        style.configure("White.TFrame", background="white")
        style.configure("White.TLabel", background="white", foreground=INK)
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(12, 11), background="#e0e9f4", foreground=INK,
                        font=("DejaVu Sans", 12, "bold"))
        style.map("TNotebook.Tab", background=[("selected", BLUE), ("active", "#d4e6fc")],
                  foreground=[("selected", "white")])
        style.configure("Treeview", rowheight=44, background="white", fieldbackground="white", font=("DejaVu Sans", 12))
        style.configure("Treeview.Heading", font=("DejaVu Sans", 12, "bold"), background="#dceafb", foreground=NAVY, padding=(4, 8))
        style.configure("TEntry", padding=(7, 8), font=("DejaVu Sans", 14))

    def _header(self):
        header = tk.Frame(self, background=NAVY, padx=10, pady=4)
        header.pack(fill="x")
        self.branding_canvas = tk.Canvas(header, width=164, height=48, background="white", highlightthickness=0)
        self.branding_canvas.pack(side="left")
        self._draw_branding(self.branding_canvas, 0, 0, 164, 48)
        self.identity = tk.StringVar()
        tk.Label(header, textvariable=self.identity, background=NAVY, foreground="#d7e7f5",
                 font=("DejaVu Sans", 12), anchor="w").pack(side="left", padx=10)
        ttk.Button(header, text="Sair", width=4, style="Toolbar.TButton", command=self.request_close).pack(side="right")
        ttk.Button(header, text="Teclado", width=7, style="Toolbar.TButton", command=self.show_keyboard).pack(side="right", padx=4)
        self.login_button = ttk.Button(header, text="Entrar", width=12, style="Toolbar.TButton", command=self.login_dialog)
        self.login_button.pack(side="right", padx=3)
        self.connection = tk.StringVar(value="Desconectado")
        self.mode = tk.StringVar(value="Modo: —")

    def _maintenance_mode_controls(self):
        operation = ttk.Frame(self.maintenance_controls, style="White.TFrame")
        operation.pack(side="left")
        ttk.Label(operation, text="Modo de operação", style="White.TLabel",
                  font=("DejaVu Sans", 12, "bold")).pack(anchor="w")
        self.connection_label = tk.Label(operation, textvariable=self.connection, font=("DejaVu Sans", 11),
                                         foreground=MUTED, background="white", anchor="w")
        self.connection_label.pack(anchor="w")
        self.mode_label = tk.Label(self.maintenance_controls, textvariable=self.mode, font=("DejaVu Sans", 12, "bold"),
                                   foreground=BLUE, background="#e6f1ff", padx=9, pady=3)
        self.mode_label.pack(side="left", padx=10)
        self.auto_button = ttk.Button(self.maintenance_controls, text="Automático", style="Primary.TButton",
                                      command=lambda: self._invoke(self.service.set_mode, "auto"))
        self.auto_button.pack(side="right")
        self.manual_button = ttk.Button(self.maintenance_controls, text="Manual · ADMIN", style="Manual.TButton",
                                        command=lambda: self._invoke(self.service.set_mode, "manual"))
        self.manual_button.pack(side="right", padx=6)

    def _make_plant(self):
        self.overview = tk.StringVar(value="Média térmica: — °C     Ambiente: — Pa")
        ttk.Label(self.plant, textvariable=self.overview, padding=(10, 4), font=("DejaVu Sans", 12)).pack(anchor="w")
        self.plant_canvas = tk.Canvas(self.plant, background=BG, highlightthickness=0)
        self.plant_canvas.pack(fill="both", expand=True, padx=5)
        self.plant_canvas.bind("<Configure>", lambda _: self._draw_plant())
        self.plant_canvas.bind("<Button-1>", self._plant_click)

    def _page(self, name):
        scroll = ScrollFrame(self.maintenance)
        self.maintenance.add(scroll, text=name)
        return scroll.content

    def _input(self, parent, label, row, default="", column=0, width=15, manual=False, keyboard="numeric"):
        pady = 2 if manual else 4
        ttk.Label(parent, text=label).grid(row=row, column=column, sticky="w", padx=4, pady=pady)
        value = tk.StringVar(value=str(default))
        entry = ttk.Entry(parent, textvariable=value, width=width)
        entry.grid(row=row, column=column + 1, sticky="w", padx=4, pady=pady)
        if keyboard == "numeric":
            validator = (lambda raw: percent_to_pwm(decimal(raw))) if manual else None
            self.bind_numeric_entry(entry, label, validator=validator)
        if manual:
            self.manual_widgets.append(entry)
        return value

    def _make_maintenance(self):
        self._maintenance_mode_controls()
        page = self._page("Setpoints")
        ttk.Label(page, text="Setpoints globais: temperatura média dos seis sensores e pressão diferencial do canal P6.",
                  wraplength=680).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 8))
        self.sp_temp = self._input(page, "Temperatura (°C)", 1)
        self.sp_pressure = self._input(page, "Pressão P6 (Pa)", 2)
        ttk.Button(page, text="Carregar valores", command=self._load_setpoints).grid(row=3, column=0, pady=10, sticky="w")
        ttk.Button(page, text="Enviar setpoints", command=lambda: self._invoke(lambda:
            self.service.setpoints(decimal(self.sp_temp.get()), decimal(self.sp_pressure.get())))).grid(row=3, column=1, pady=10)
        self.thermal_info = tk.StringVar(value="Controle térmico: aguardando dados.")
        ttk.Label(page, textvariable=self.thermal_info, wraplength=680).grid(
            row=4, column=0, columnspan=4, sticky="w", pady=8)

        page = self._page("Saídas")
        for column, label in enumerate(("Equipamento", "PWM (%)", "Estado atual")):
            ttk.Label(page, text=label, font=("DejaVu Sans", 13, "bold")).grid(row=0, column=column, sticky="w", padx=4, pady=(0, 4))
        self.fan_vars = []
        self.manual_widgets = []
        self.output_status = [tk.StringVar(value="--") for _ in range(4)]
        for i, name in enumerate(["Ventilador Exaustão 1", "Ventilador Exaustão 2", "Ventilador Insuflamento"]):
            value = self._input(page, name, i + 1, 0, width=10, manual=True)
            self.fan_vars.append(value)
            ttk.Label(page, textvariable=self.output_status[i]).grid(row=i + 1, column=2, sticky="w", padx=16)
        self.fan_power = tk.BooleanVar(value=False)
        box = ttk.Checkbutton(page, text="Alimentação dos ventiladores", variable=self.fan_power)
        box.grid(row=4, column=0, columnspan=2, sticky="w", padx=4, pady=3)
        self.manual_widgets.append(box)
        self.fan_power_status = tk.StringVar(value="--")
        ttk.Label(page, textvariable=self.fan_power_status).grid(row=4, column=2, sticky="w", padx=16)
        ttk.Separator(page, orient="horizontal").grid(row=5, column=0, columnspan=3, sticky="ew", pady=8)
        ttk.Label(page, text="Peltier · Liga/Desliga").grid(row=6, column=0, sticky="w", padx=4)
        self.peltier_on = tk.BooleanVar(value=False)
        self.peltier_switch = ttk.Checkbutton(page, text="Ligar", variable=self.peltier_on)
        self.peltier_switch.grid(row=6, column=1, sticky="w", padx=4)
        self.manual_widgets.append(self.peltier_switch)
        ttk.Label(page, textvariable=self.output_status[3]).grid(row=6, column=2, sticky="w", padx=16)
        ttk.Button(page, text="Carregar valores atuais", command=self._load_outputs).grid(row=7, column=0, sticky="w", pady=3)
        send = ttk.Button(page, text="Aplicar saídas", style="Primary.TButton", command=self._send_outputs)
        send.grid(row=7, column=1, columnspan=2, pady=3)
        self.manual_widgets.append(send)

        page = self._page("PID")
        ttk.Label(page, text="PID da pressão P6. O Peltier usa Liga/Desliga pela média das temperaturas.",
                  wraplength=680).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 8))
        self.pid_loop = tk.StringVar(value="pressure")
        ttk.Label(page, text="Malha").grid(row=1, column=0, sticky="w", padx=4)
        ttk.Combobox(page, textvariable=self.pid_loop, values=("pressure",), state="readonly", width=15).grid(row=1, column=1)
        self.kp = self._input(page, "Kp", 2, width=12)
        self.ki = self._input(page, "Ki", 3, width=12)
        self.kd = self._input(page, "Kd", 4, width=12)
        ttk.Button(page, text="Carregar ganhos atuais", command=self._load_pid).grid(row=5, column=0, pady=10)
        send = ttk.Button(page, text="Enviar PID", command=lambda: self._invoke(lambda:
            self.service.set_pid(self.pid_loop.get(), decimal(self.kp.get()), decimal(self.ki.get()), decimal(self.kd.get()))))
        send.grid(row=5, column=1, pady=10)
        self.manual_widgets.append(send)

        page = self._page("Calibração")
        self.pressure_calibration = PressureCalibration(page, self)
        self.pressure_calibration.pack(fill="x", expand=True)

        page = self._page("Sensores")
        self.rom_room = tk.StringVar(value="1")
        ttk.Label(page, text="Sala DS18B20 (1–6)").grid(row=5, column=0, sticky="w", padx=4)
        ttk.Combobox(page, textvariable=self.rom_room, values=tuple(map(str, range(1, 7))), state="readonly", width=13).grid(row=5, column=1)
        self.rom_address = self._input(page, "ROM (16 dígitos hex)", 6, width=20, keyboard="text")
        send = ttk.Button(page, text="Associar sensor à sala", command=lambda: self._invoke(
            self.service.set_temperature_address, int(self.rom_room.get()) - 1, self.rom_address.get()))
        send.grid(row=7, column=0, columnspan=2, sticky="w", padx=4, pady=6)
        self.manual_widgets.append(send)
        self.roms = tk.StringVar(value="ROMs: aguardando dados")
        ttk.Label(page, textvariable=self.roms, wraplength=680).grid(row=8, column=0, columnspan=3, sticky="w", pady=8)
        save = ttk.Button(page, text="Gravar configuração no Arduino (EEPROM)", command=lambda: self._invoke(self.service.save_controller))
        save.grid(row=9, column=0, columnspan=3, sticky="w", pady=8)
        self.manual_widgets.append(save)
        ttk.Separator(page, orient="horizontal").grid(row=10, column=0, columnspan=3, sticky="ew", pady=10)
        ttk.Label(page, text="TACH: pulsos por volta (PPR). Valor inicial 2 é PROVISÓRIO; confirme na documentação ou meça.",
                  wraplength=680).grid(row=11, column=0, columnspan=3, sticky="w", pady=4)
        self.tach_channel = tk.StringVar(value="1")
        ttk.Label(page, text="Ventoinha / TACH (1–3)").grid(row=12, column=0, sticky="w", padx=4)
        ttk.Combobox(page, textvariable=self.tach_channel, values=("1", "2", "3"), state="readonly", width=13).grid(row=12, column=1)
        self.tach_ppr = self._input(page, "Pulsos por volta (1–255)", 13, "2", width=12)
        ttk.Button(page, text="Carregar PPR atual", command=self._load_tach).grid(row=14, column=0, sticky="w", padx=4, pady=6)
        tach = ttk.Button(page, text="Ajustar PPR do TACH", command=lambda: self._invoke(lambda:
            self.service.set_tach(int(self.tach_channel.get()) - 1, int(self.tach_ppr.get()))))
        tach.grid(row=14, column=1, sticky="w", padx=4, pady=6)
        self.manual_widgets.append(tach)

        page = self._page("Salas / limites")
        ttk.Label(page, text="Nomes e alarmes são salvos na Pi. A pressão dos alarmes é diferencial ao ambiente.",
                  wraplength=680).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 8))
        self.room_id = tk.StringVar(value="1")
        ttk.Label(page, text="Sensor P#/T#").grid(row=1, column=0, sticky="w", padx=4)
        select = ttk.Combobox(page, textvariable=self.room_id, values=tuple(map(str, range(1, 7))), state="readonly", width=13)
        select.grid(row=1, column=1)
        select.bind("<<ComboboxSelected>>", lambda _: self._load_room())
        self.room_name = self._input(page, "Nome", 2, width=22, keyboard="text")
        ttk.Label(page, text="Temperatura (°C)", font=("DejaVu Sans", 13, "bold")).grid(
            row=3, column=0, columnspan=2, sticky="w", padx=4, pady=(12, 4))
        ttk.Label(page, text="Pressão (Pa)", font=("DejaVu Sans", 13, "bold")).grid(
            row=3, column=2, columnspan=2, sticky="w", padx=4, pady=(12, 4))
        self.room_tmin = self._input(page, "Mínima", 4, width=9)
        self.room_tmax = self._input(page, "Máxima", 5, width=9)
        self.room_pmin = self._input(page, "Mínima", 4, column=2, width=9)
        self.room_pmax = self._input(page, "Máxima", 5, column=2, width=9)
        ttk.Button(page, text="Salvar nome e limites", command=self._save_room).grid(row=6, column=0, columnspan=2, pady=10, sticky="w")
        ttk.Button(page, text="Associar sensores à planta", command=self._association_dialog).grid(
            row=7, column=0, columnspan=2, pady=6, sticky="w")
        ttk.Label(page, text="Cada ambiente recebe um par P#/T#. A referência de controle permanece sempre P6, "
                  "independentemente da posição na planta.", wraplength=680).grid(row=8, column=0, columnspan=4, sticky="w", pady=5)

    def _tree(self, parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(frame, columns=[c[0] for c in columns], show="headings", selectmode="browse")
        for key, title, width in columns:
            tree.heading(key, text=title)
            tree.column(key, width=width, minwidth=55, stretch=True)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        return tree

    def _make_alarms(self):
        controls = ttk.Frame(self.alarms)
        controls.pack(fill="x", pady=(0, 6))
        ttk.Label(controls, text="Eventos de alarme e recuperação").pack(side="left")
        ttk.Button(controls, text="Exportar sensores CSV", command=self._export).pack(side="right")
        ttk.Button(controls, text="Atualizar", command=self.refresh_lists).pack(side="right", padx=5)
        self.alarm_tree = self._tree(self.alarms, [("time", "Data/hora", 155), ("room", "Sala", 100),
                                                   ("message", "Evento", 350), ("active", "Estado", 100)])

    def _make_users(self):
        controls = ttk.Frame(self.user_tab)
        controls.pack(fill="x", pady=(0, 6))
        ttk.Label(controls, text="Cadastro e senhas: somente ADMIN").pack(side="left")
        self.user_buttons = []
        for text, command in [("Excluir", self._delete_user), ("Senha", self._password_dialog), ("Adicionar", self._add_user_dialog)]:
            button = ttk.Button(controls, text=text, command=command)
            button.pack(side="right", padx=3)
            self.user_buttons.append(button)
        self.user_tree = self._tree(self.user_tab, [("username", "Usuário", 300), ("role", "Perfil", 200)])

    def _remember_entry(self, event):
        if isinstance(event.widget, (ttk.Entry, tk.Entry)) and not isinstance(event.widget, ttk.Combobox):
            if self._numeric_keyboard and event.widget is self._numeric_keyboard.entry:
                return
            self._entry = event.widget

    def bind_numeric_entry(self, entry, label, *, validator=None):
        entry._numeric_editor = (label, validator)
        entry.bind("<ButtonRelease-1>", lambda _: self._open_numeric_keyboard(entry), add="+")

    def _open_numeric_keyboard(self, entry):
        if not entry.winfo_exists() or not entry.instate(("!disabled", "!readonly")):
            return
        if self._numeric_keyboard and self._numeric_keyboard.winfo_exists():
            self._numeric_keyboard.lift()
            return
        if self._keyboard and self._keyboard.winfo_exists():
            self._keyboard.destroy()
        self._entry = entry
        label, validator = entry._numeric_editor
        self._numeric_keyboard = NumericKeypad(self, entry, label, validator=validator,
                                                on_close=self._numeric_closed)

    def _numeric_closed(self, entry):
        self._numeric_keyboard = None
        self._entry = entry

    def show_keyboard(self):
        if self._entry is not None and hasattr(self._entry, "_numeric_editor"):
            self._open_numeric_keyboard(self._entry)
            return
        if self._keyboard and self._keyboard.winfo_exists():
            self._keyboard.lift()
            return
        keyboard = self._keyboard = tk.Toplevel(self)
        keyboard.title(self.window_title("Teclado touch"))
        keyboard.attributes("-topmost", True)
        keyboard.resizable(False, False)
        box = ttk.Frame(keyboard, padding=5)
        box.pack(fill="both", expand=True)
        ttk.Label(box, text="Toque primeiro no campo desejado. As senhas continuam ocultas.").grid(row=0, column=0, columnspan=12, sticky="w", pady=3)
        self._uppercase = False
        keys = []
        for row, letters in enumerate(["1234567890.-", "qwertyuiop", "asdfghjkl", "zxcvbnm_@"], 1):
            for column, letter in enumerate(letters):
                button = ttk.Button(box, text=letter, width=3, command=lambda c=letter: self._key(c))
                button.grid(row=row, column=column, padx=1, pady=1)
                keys.append((button, letter))

        def shift():
            self._uppercase = not self._uppercase
            for button, char in keys:
                button.configure(text=char.upper() if self._uppercase else char)

        ttk.Button(box, text="Maiúsculas", command=shift).grid(row=5, column=0, columnspan=3, sticky="ew", pady=3)
        ttk.Button(box, text="Espaço", command=lambda: self._key(" ")).grid(row=5, column=3, columnspan=3, sticky="ew")
        ttk.Button(box, text="Apagar", command=lambda: self._key("BACKSPACE")).grid(row=5, column=6, columnspan=3, sticky="ew")
        ttk.Button(box, text="Fechar", command=keyboard.destroy).grid(row=5, column=9, columnspan=3, sticky="ew")
        keyboard.update_idletasks()
        keyboard.geometry(f"+{self.winfo_rootx()}+{self.winfo_rooty()+max(0,self.winfo_height()-keyboard.winfo_height())}")

    def _key(self, char):
        target = self._entry
        if target is None or not target.winfo_exists():
            return
        try:
            selected = target.selection_present()
            if selected:
                target.delete("sel.first", "sel.last")
            if char == "BACKSPACE":
                if selected:
                    return
                position = target.index("insert")
                if position:
                    target.delete(position - 1, position)
            else:
                target.insert("insert", char.upper() if self._uppercase else char)
        except tk.TclError:
            return

    def _invoke(self, command, *args):
        try:
            command(*args)
            self.message.set("Solicitação enviada. O estado mostrado só muda com a telemetria do controlador.")
            return True
        except (AppError, ValueError, TypeError) as exc:
            messagebox.showerror(self.window_title("Operação não concluída"), str(exc), parent=self)
            return False

    def login_dialog(self):
        if self._logged_in or self.service.admin or self.service.username != "Operador":
            self.service.logout()
            self._logged_in = False
            self.message.set("Sessão encerrada. As saídas do controlador não foram alteradas.")
            self.refresh_lists()
            return

        def login(values):
            self.service.login(values["username"], values["password"])
            self._logged_in = True
            self.message.set("Usuário autenticado. Escolha Manual para liberar os ajustes de atuação.")

        FormDialog(self, "Entrar", [("username", "Usuário", "ADMIN", False),
                                  ("password", "Senha", "", True)], login, "Entrar")

    def _load_setpoints(self):
        data = (self.service.snapshot or {}).get("setpoints", {})
        self.sp_temp.set(data.get("temperature", ""))
        self.sp_pressure.set(data.get("pressure", ""))

    def _load_outputs(self):
        data = self.service.snapshot or {}
        for index, value in enumerate(self.fan_vars):
            current = at(data.get("fans"), index)
            value.set("" if current is None else percent_text(current))
        self.fan_power.set(data.get("fan_power") is True)
        current = data.get("peltier")
        self.peltier_on.set(current is not None and current > 0)

    def _send_outputs(self):
        try:
            fans = [percent_to_pwm(decimal(value.get())) for value in self.fan_vars]
            peltier = 255 if self.peltier_on.get() else 0
        except ValueError:
            messagebox.showerror(self.window_title("Percentual inválido"), "Informe um valor entre 0 e 100%.", parent=self)
            return
        self._invoke(self.service.outputs, fans, self.fan_power.get(), peltier)

    def _load_pid(self):
        gains = (self.service.snapshot or {}).get("pid", {}).get(self.pid_loop.get(), {})
        for key, var in [("kp", self.kp), ("ki", self.ki), ("kd", self.kd)]:
            var.set(gains.get(key, ""))

    def _load_tach(self):
        current = at((self.service.snapshot or {}).get("tach_ppr"), int(self.tach_channel.get()) - 1)
        self.tach_ppr.set("" if current is None else current)

    def _association_dialog(self):
        dialog = tk.Toplevel(self)
        dialog.title(self.window_title("Associar sensores à planta"))
        dialog.transient(self)
        dialog.resizable(False, False)
        frame = ttk.Frame(dialog, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Confirme o ambiente físico de cada par P#/T#. PID de pressão: sempre P6.",
                  wraplength=550).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        values = {}
        for row, room in enumerate(sorted(self.service.rooms(), key=lambda room: room["id"]), 2):
            channel = room["id"]
            ttk.Label(frame, text=f"P{channel} / T{channel}" + (" · PID" if channel == 6 else "")).grid(
                row=row, column=0, sticky="w", padx=(0, 12), pady=5)
            location = room.get("location", DEFAULT_LOCATIONS[channel - 1])
            value = tk.StringVar(value=LOCATION_LABELS.get(location, ""))
            ttk.Combobox(frame, textvariable=value, values=tuple(LOCATION_KEYS), state="readonly", width=27).grid(
                row=row, column=1, sticky="ew", pady=5)
            values[channel] = value

        def save():
            try:
                mapping = {channel: LOCATION_KEYS[value.get()] for channel, value in values.items()}
                if len(set(mapping.values())) != 6:
                    raise ValueError("Associe cada ambiente a exatamente um par P#/T#; há um ambiente repetido.")
                self.service.assign_rooms(mapping, confirmed=True)
            except (AppError, ValueError, KeyError) as exc:
                messagebox.showerror(self.window_title("Associação inválida"), str(exc), parent=dialog)
                return
            self.message.set("Associação dos sensores à planta confirmada e salva na Raspberry Pi.")
            self._load_room()
            self._draw_plant()
            dialog.destroy()

        controls = ttk.Frame(frame)
        controls.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        ttk.Button(controls, text="Cancelar", command=dialog.destroy).pack(side="right", padx=3)
        ttk.Button(controls, text="Confirmar associação", command=save).pack(side="right", padx=3)
        dialog.update_idletasks()
        dialog.geometry(f"+{self.winfo_rootx() + max(0, (self.winfo_width()-dialog.winfo_width())//2)}"
                        f"+{self.winfo_rooty() + max(0, (self.winfo_height()-dialog.winfo_height())//2)}")
        dialog.bind("<Escape>", lambda _: dialog.destroy())

    def _load_room(self):
        room = next((room for room in self.service.rooms() if room["id"] == int(self.room_id.get())), None)
        if room:
            for key, var in [("name", self.room_name), ("temp_min", self.room_tmin), ("temp_max", self.room_tmax),
                             ("pressure_min", self.room_pmin), ("pressure_max", self.room_pmax)]:
                var.set(room.get(key, ""))

    def _save_room(self):
        try:
            self.service.update_room(int(self.room_id.get()), self.room_name.get(), decimal(self.room_tmin.get()),
                                     decimal(self.room_tmax.get()), decimal(self.room_pmin.get()), decimal(self.room_pmax.get()))
        except (AppError, ValueError, TypeError) as exc:
            messagebox.showerror(self.window_title("Configuração inválida"), str(exc), parent=self)
            return
        self.message.set("Nome e limites de alarme salvos na Raspberry Pi.")
        self._draw_plant()

    def _selected_user(self):
        selection = self.user_tree.selection()
        if not selection:
            raise AppError("Selecione um usuário na lista.")
        return self.user_tree.item(selection[0], "values")[0]

    def _add_user_dialog(self):
        def add(values):
            self.service.add_user(values["username"], values["password"], values["role"])
            self.message.set("Usuário adicionado.")
        FormDialog(self, "Adicionar usuário", [("username", "Usuário", "", False),
                   ("password", "Senha", "", True), ("role", "Perfil: operator ou admin", "operator", False)], add)

    def _password_dialog(self):
        try:
            username = self._selected_user()
        except AppError as exc:
            messagebox.showerror(self.window_title("Usuário"), str(exc), parent=self)
            return
        def change(values):
            self.service.change_password(username, values["password"])
            self.message.set(f"Senha de {username} alterada.")
        FormDialog(self, f"Senha de {username}", [("password", "Nova senha", "", True)], change)

    def _delete_user(self):
        try:
            username = self._selected_user()
            if messagebox.askyesno(self.window_title("Excluir usuário"), f"Excluir {username}?", parent=self):
                self.service.delete_user(username)
                self.message.set("Usuário excluído.")
                self.refresh_lists()
        except AppError as exc:
            messagebox.showerror(self.window_title("Usuário"), str(exc), parent=self)

    def _export(self):
        path = filedialog.asksaveasfilename(parent=self, title=self.window_title("Exportar sensores"),
                                          defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if path:
            try:
                count = self.service.export_csv(path)
                self.message.set(f"CSV exportado: {count} registros em {path}")
            except (AppError, OSError) as exc:
                messagebox.showerror(self.window_title("Exportação"), str(exc), parent=self)

    def refresh_lists(self):
        try:
            self.alarm_tree.delete(*self.alarm_tree.get_children())
            for row in self.service.alarm_log(limit=200):
                self.alarm_tree.insert("", "end", values=(timestamp(row.get("timestamp", "")), row.get("room_name", "Sistema"),
                    row.get("message", ""), "ATIVO" if row.get("active") else "Recuperado"),
                    tags=("active" if row.get("active") else "recovered",))
            self.alarm_tree.tag_configure("active", background="#fff0f2", foreground=RED)
            self.alarm_tree.tag_configure("recovered", background="#edf8f1", foreground=GREEN)
            self.user_tree.delete(*self.user_tree.get_children())
            for user in self.service.users() if self.service.admin else []:
                self.user_tree.insert("", "end", values=(user["username"], user["role"]))
            if not self.room_name.get():
                self._load_room()
        except (AppError, KeyError, TypeError) as exc:
            if hasattr(self, "message"):
                self.message.set(str(exc))

    def _draw_plant(self):
        canvas = self.plant_canvas
        canvas.delete("all")
        self._plant_rooms = []
        data = self.service.snapshot or {}
        rooms = self.service.rooms()
        width, height = max(canvas.winfo_width(), 750), max(canvas.winfo_height(), 310)
        gap, padding = 5, 5
        setpoints = data.get("setpoints", {})
        for room in rooms[:6]:
            index = room["id"] - 1
            location = room.get("location", DEFAULT_LOCATIONS[index])
            bounds = ROOM_BOUNDS.get(location)
            if bounds is None:
                continue
            x1, y1, x2, y2 = bounds
            x = padding + x1 * (width - 2 * padding) + gap / 2
            y = padding + y1 * (height - 2 * padding) + gap / 2
            right = padding + x2 * (width - 2 * padding) - gap / 2
            bottom = padding + y2 * (height - 2 * padding) - gap / 2
            card_w, card_h = right - x, bottom - y
            temp = at(data.get("temperatures"), index)
            pressure = at(data.get("differentials"), index)
            invalid = temp is None or pressure is None
            alarm = ((temp is not None and (temp < room["temp_min"] or temp > room["temp_max"]))
                     or (pressure is not None and (pressure < room["pressure_min"] or pressure > room["pressure_max"])))
            stale = bool(data) and any(word in self.service.status.lower() for word in ("históricos", "desconectado"))
            accent, normal_fill = ROOM_COLORS[location]
            outline, fill = ((AMBER, "#fff7e5") if stale else (RED, "#fff0f2") if alarm
                             else (AMBER, "#fff7e5") if invalid else (accent, normal_fill))
            state = "ANTERIOR" if stale else "ALARME" if alarm else "SEM DADOS" if invalid else "OK"
            state_color = AMBER if stale else RED if alarm else AMBER if invalid else GREEN
            canvas.create_rectangle(x, y, right, bottom, fill=fill, outline=outline, width=1,
                                    tags=(f"room-{room['id']}",))
            canvas.create_rectangle(x, y, right, y + 27, fill=outline, outline="",
                                    tags=(f"room-{room['id']}",))
            name = room["name"]
            heading = name
            while heading and self._room_title_font.measure(heading) > card_w - 16:
                heading = heading[:-2].rstrip("…") + "…"
            tags = (f"room-{room['id']}", f"room-text-{room['id']}")
            canvas.create_text(x + 8, y + 3, text=heading, anchor="nw", fill="white",
                               font=self._room_title_font, tags=tags)
            size = 24 if card_h >= 195 else 22 if card_h >= 175 else 20
            value_font = self._reading_fonts[size]
            line_y = y + 29
            for text in (f"P{room['id']}: {reading(pressure)} Pa", f"T{room['id']}: {reading(temp)}°C"):
                item = canvas.create_text(x + 9, line_y, text=text, anchor="nw", fill=INK,
                                          font=value_font, tags=tags)
                line_y = canvas.bbox(item)[3]
            details = (f"SP: {reading(setpoints.get('pressure'))} Pa · {reading(setpoints.get('temperature'))}°C",
                       f"P: {reading(room['pressure_min'])}…{reading(room['pressure_max'])} Pa · "
                       f"T: {reading(room['temp_min'])}…{reading(room['temp_max'])}°C")
            for line in details:
                item = canvas.create_text(x + 8, line_y, text=line, anchor="nw", fill=MUTED,
                                          font=self._detail_font, tags=tags)
                line_y = canvas.bbox(item)[3]
            # A readable state accompanies the colors without taking space from
            # the room name or reducing the size of the measurements.
            if state != "OK":
                canvas.create_text(right - 8, bottom - 3, text=state, anchor="se", fill=state_color,
                                   font=("DejaVu Sans", 11, "bold"), tags=tags)
            self._plant_rooms.append((x, y, right, bottom, room))

    def _plant_click(self, event):
        for x1, y1, x2, y2, room in self._plant_rooms:
            if x1 <= event.x <= x2 and y1 <= event.y <= y2:
                old = self._graph_windows.get(room["id"])
                if old and old.winfo_exists():
                    old.lift()
                else:
                    self._graph_windows[room["id"]] = GraphWindow(self, room)
                break

    def _poll(self):
        try:
            username = self.service.username
            self.identity.set(f"{username[:12]}{'…' if len(username) > 12 else ''}")
            logged = self._logged_in or self.service.admin or self.service.username != "Operador"
            self.login_button.configure(text="Sair da conta" if logged else "Entrar")
            status = self.service.status.lower()
            connection = ("" if self.demo else "Dados anteriores" if "históricos" in status
                          else "Sem conexão" if "desconectado" in status else "Conectado" if "conectado" in status else "Aguardando conexão")
            self.connection.set(connection)
            data = self.service.snapshot or {}
            self.thermal_info.set("Peltier automático: Liga/Desliga pela média; histerese de 0,5°C."
                                  if data.get("peltier_control") == "on_off" else
                                  "Controle térmico automático: requer a atualização do Arduino." if data else
                                  "Controle térmico: aguardando dados.")
            mode = data.get("mode")
            self.mode.set({"auto": "AUTOMÁTICO", "manual": "MANUAL"}.get(mode, "—"))
            self.mode_label.configure(foreground=AMBER if mode == "manual" else BLUE,
                                      background="#fff0d4" if mode == "manual" else "#e6f1ff")
            self.connection_label.configure(foreground=AMBER if self.demo or "históricos" in status
                                              else RED if "desconectado" in status else GREEN)
            self.manual_button.configure(state="normal" if self.service.admin else "disabled")
            manual = self.service.admin and mode == "manual" and bool(data.get("manual_authorized"))
            for widget in self.manual_widgets:
                widget.configure(state="normal" if manual else "disabled")
            if not manual:
                self._load_outputs()
            for widget in self.user_buttons:
                widget.configure(state="normal" if self.service.admin else "disabled")
            rpm = data.get("fan_rpm", [])
            self.overview.set(f"Média: {reading(data.get('temp_mean'))}°C     |     Ambiente P7: {reading(at(data.get('pressures'), 6))} Pa")
            fans, power = data.get("fans", []), data.get("fan_power")
            for index in range(3):
                self.output_status[index].set(f"{percent_text(at(fans,index))}% · {number(at(rpm,index),0)} rpm")
            self.fan_power_status.set("--" if type(power) is not bool else "Ligada" if power else "Desligada")
            peltier = data.get("peltier")
            self.output_status[3].set("--" if peltier is None else "Desligado" if peltier == 0
                                      else "Ligado" if peltier == 255 else f"Parcial ({percent_text(peltier)}%)")
            configured = data.get("temperature_addresses", [])
            discovered = data.get("discovered_addresses", [])
            self.roms.set("ROMs associadas: " + ", ".join(f"{i+1}:{rom or 'não associada'}" for i,rom in enumerate(configured))
                          + ("\nDescobertas: " + ", ".join(discovered) if discovered else ""))
            for event in self.service.drain_events():
                self.pressure_calibration.notify_event(event)
                if event.get("type") == "ack":
                    if event.get("ok"):
                        self.message.set("Alteração aplicada.")
                    else:
                        self.message.set(f"Comando rejeitado: {event.get('error', 'erro sem descrição')}")
                elif event.get("type") == "error":
                    self.message.set(str(event.get("message", event.get("error", "Erro de comunicação"))))
            if data.get("seq") != self._last_seq:
                self._last_seq = data.get("seq")
                self._draw_plant()
            self._ticks += 1
            if self._ticks % 25 == 0:
                self.refresh_lists()
        except (AppError, KeyError, TypeError, ValueError, tk.TclError) as exc:
            self.message.set(f"Erro ao atualizar a interface: {exc}")
        self._timer = self.after(200, self._poll)

    def request_close(self):
        if messagebox.askyesno(self.window_title("Sair da aplicação"),
                              "Encerrar a interface? Nenhum comando de desligamento será enviado. "
                              "O estado do Arduino é preservado enquanto não houver reset ou perda de alimentação.", parent=self):
            if self._timer:
                self.after_cancel(self._timer)
                self._timer = None
            self.service.close()
            self.destroy()
