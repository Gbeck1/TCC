"""I/O em thread: JSON delimitado, ACKs e reconexão sem reaplicar saídas."""
from __future__ import annotations

import json
import queue
import re
import threading
import time

import serial
from serial.tools import list_ports

from .simulator import SimulatedController
from .protocol import VERSION, HARDWARE
from .validation import gains, number, outputs, tach, peltier_switch

MAX_TELEMETRY_BYTES = 8192
MAX_COMMAND_BYTES = 384
ACK_WAIT_SECONDS = 2.0


def decode_message(line):
    if not isinstance(line, bytes) or not line or len(line) > MAX_TELEMETRY_BYTES:
        raise ValueError("Tamanho de mensagem serial inválido.")
    try:
        message = json.loads(line.decode("utf-8"), parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Número JSON não finito.")))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("Mensagem serial não é JSON UTF-8 válido.") from exc
    if not isinstance(message, dict) or type(message.get("v")) is not int or message["v"] != VERSION:
        raise ValueError("Protocolo incompatível; esperado v2 da placa NB3.")
    kind = message.get("type")
    if kind == "ack":
        if type(message.get("id")) is not int or not 1 <= message["id"] <= 2147483647 or type(message.get("ok")) is not bool:
            raise ValueError("ACK inválido.")
        if not message["ok"] and not isinstance(message.get("error"), str):
            raise ValueError("ACK de erro sem motivo.")
        return message
    if kind != "telemetry":
        raise ValueError("Tipo de mensagem desconhecido.")
    if message.get("hardware") != HARDWARE:
        raise ValueError("Placa incompatível; esperado hardware NB3.")
    if message.get("mode") not in ("auto", "manual") or type(message.get("manual_authorized")) is not bool:
        raise ValueError("Estado do controlador inválido.")
    for key in ("seq", "ms"):
        if type(message.get(key)) is not int or message[key] < 0:
            raise ValueError(f"Campo {key} inválido.")
    for key, length in (("temperatures", 6), ("differentials", 6), ("pressures", 7), ("raw_pressures", 7)):
        values = message.get(key)
        if not isinstance(values, list) or len(values) != length:
            raise ValueError(f"Campo {key} precisa de {length} canais.")
        for value in values:
            if value is not None:
                number(value, key)
                if key == "raw_pressures" and type(value) is not int:
                    raise ValueError("Contagens ADC devem ser inteiras.")
    calibrated = message.get("calibrated")
    if not isinstance(calibrated, list) or len(calibrated) != 7 or any(type(x) is not bool for x in calibrated):
        raise ValueError("Estado de calibração inválido.")
    if "temp_mean" not in message:
        raise ValueError("Telemetria sem média térmica.")
    if message["temp_mean"] is not None:
        number(message["temp_mean"])
    rpm = message.get("fan_rpm")
    ppr = message.get("tach_ppr")
    if not isinstance(rpm, list) or len(rpm) != 3:
        raise ValueError("RPM precisa de três canais.")
    for value in rpm:
        if value is not None and number(value, "RPM") < 0:
            raise ValueError("RPM não pode ser negativo.")
    if not isinstance(ppr, list) or len(ppr) != 3:
        raise ValueError("Pulsos por volta precisam de três canais.")
    for channel, value in enumerate(ppr):
        tach(channel, value)
    try:
        number(message["setpoints"]["temperature"])
        number(message["setpoints"]["pressure"])
        outputs(message["fans"], message["fan_power"], message["peltier"])
        for loop in ("pressure", "temperature"):
            pid = message["pid"][loop]
            gains(loop, pid["kp"], pid["ki"], pid["kd"])
    except (KeyError, TypeError) as exc:
        raise ValueError("Telemetria incompleta.") from exc
    addresses = message.get("temperature_addresses")
    if not isinstance(addresses, list) or len(addresses) != 6 or any(
            not isinstance(x, str) or x != "" and not re.fullmatch(r"[0-9a-fA-F]{16}", x) for x in addresses):
        raise ValueError("Associação de sensores de temperatura inválida.")
    if "calibration" in message:
        calibration = message["calibration"]
        if not isinstance(calibration, list) or len(calibration) != 7:
            raise ValueError("Coeficientes de calibração inválidos.")
        for entry in calibration:
            if not isinstance(entry, dict) or "offset" not in entry or "scale" not in entry:
                raise ValueError("Coeficiente incompleto.")
            number(entry["offset"])
            number(entry["scale"])
    if "peltier_control" in message:
        if message["peltier_control"] != "on_off":
            raise ValueError("Controle do Peltier desconhecido.")
        peltier_switch(message["peltier"])
    return message


def encode_command(command):
    try:
        data = (json.dumps(command, ensure_ascii=True, allow_nan=False, separators=(",", ":")) + "\n").encode("ascii")
    except (ValueError, TypeError) as exc:
        raise ValueError("Comando inválido.") from exc
    if len(data) > MAX_COMMAND_BYTES:
        raise ValueError("Comando excede o buffer serial do Arduino.")
    return data


class SerialTransport:
    def __init__(self, callback, port=None):
        self.callback = callback
        self.port = port
        self.outgoing = queue.Queue(maxsize=32)
        self.stop = threading.Event()
        self.connected = threading.Event()
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True, name="tcc-serial")
        self.thread.start()

    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=3)

    def send(self, command):
        data = encode_command(command)
        if not self.connected.is_set():
            raise ValueError("Serial desconectada; comando não enviado.")
        try:
            self.outgoing.put_nowait((command["id"], data))
        except queue.Full as exc:
            raise ValueError("Fila serial ocupada; aguarde os ACKs.") from exc

    def _status(self, status):
        self.callback({"type": "status", "status": status})

    def _select_port(self):
        if self.port:
            return self.port
        ports = [p.device for p in list_ports.comports() if p.vid is not None]
        if len(ports) == 1:
            return ports[0]
        if len(ports) > 1:
            raise ValueError("Mais de uma porta USB serial: informe --port /dev/serial/by-id/...")
        raise ValueError("Mega não encontrado; conecte USB ou informe --port.")

    def _discard_commands(self):
        while True:
            try:
                command_id, _ = self.outgoing.get_nowait()
            except queue.Empty:
                break
            self.callback({"type": "command_lost", "id": command_id, "message": "Conexão perdida; comando descartado, sem reenvio."})

    def _run(self):
        while not self.stop.is_set():
            try:
                port = self._select_port()
                self._status("Conectando " + port)
                # A Mega can reset on USB open; wait for fresh state, never restore outputs.
                with serial.Serial(port, 115200, timeout=.05, write_timeout=.3) as connection:
                    connection.reset_input_buffer()
                    self.connected.set()
                    self._status("USB conectado; aguardando telemetria")
                    connection.write(encode_command({"v": VERSION, "type": "command", "id": 2147483647, "op": "get_state"}))
                    buffer = bytearray()
                    dropping = False
                    in_flight = None
                    sent_at = 0.0
                    last_telemetry = time.monotonic()
                    while not self.stop.is_set():
                        if in_flight is not None and time.monotonic() - sent_at > ACK_WAIT_SECONDS:
                            in_flight = None  # Never retransmit an uncertain actuator command.
                        if in_flight is None:
                            try:
                                command_id, data = self.outgoing.get_nowait()
                            except queue.Empty:
                                pass
                            else:
                                count = connection.write(data)
                                if count != len(data):
                                    raise serial.SerialException("Escrita serial incompleta; resultado desconhecido.")
                                in_flight = command_id
                                sent_at = time.monotonic()
                                self.callback({"type": "command_sent", "id": command_id})
                        chunk = connection.read(max(1, min(connection.in_waiting, 1024)))
                        for byte in chunk:
                            if byte == 10:
                                if not dropping and buffer:
                                    try:
                                        event = decode_message(bytes(buffer))
                                    except ValueError as exc:
                                        self.callback({"type": "error", "message": str(exc)})
                                    else:
                                        if event["type"] == "ack" and event["id"] == in_flight:
                                            in_flight = None
                                        if event["type"] == "telemetry":
                                            last_telemetry = time.monotonic()
                                            self._status("USB conectado — dados atuais")
                                        self.callback(event)
                                buffer.clear()
                                dropping = False
                            elif not dropping:
                                buffer.append(byte)
                                if len(buffer) > MAX_TELEMETRY_BYTES:
                                    buffer.clear()
                                    dropping = True
                                    self.callback({"type": "error", "message": "Linha serial excedeu o limite; descartada até nova linha."})
                        now = time.monotonic()
                        if now - last_telemetry > 3.5:
                            self._status("USB sem telemetria recente — valores exibidos são históricos")
                        self.callback({"type": "tick"})
            except (serial.SerialException, OSError, ValueError) as exc:
                self._status("Desconectado: " + str(exc))
            finally:
                self.connected.clear()
                self._discard_commands()
            self.stop.wait(2)


class DemoTransport:
    def __init__(self, callback, port=None):
        self.callback = callback
        self.controller = SimulatedController()
        self.outgoing = queue.Queue(maxsize=32)
        self.stop = threading.Event()
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True, name="tcc-simulation")
        self.thread.start()

    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=3)

    def send(self, command):
        encode_command(command)
        try:
            self.outgoing.put_nowait(command.copy())
        except queue.Full as exc:
            raise ValueError("Fila de demonstração cheia.") from exc

    def _run(self):
        self.callback({"type": "status", "status": "SIMULAÇÃO — nenhum dispositivo físico"})
        self.callback(self.controller.telemetry())
        last = time.monotonic()
        while not self.stop.wait(.03):
            while True:
                try:
                    command = self.outgoing.get_nowait()
                except queue.Empty:
                    break
                self.callback({"type": "command_sent", "id": command["id"]})
                self.callback(self.controller.apply(command))
                self.callback(self.controller.telemetry())
            now = time.monotonic()
            if now - last >= 1.0:
                self.controller.advance(now - last)
                self.callback(self.controller.telemetry())
                last = now
            self.callback({"type": "tick"})
