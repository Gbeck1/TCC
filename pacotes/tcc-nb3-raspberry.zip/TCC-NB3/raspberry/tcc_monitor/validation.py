"""Validação compartilhada dos comandos; não impõe intertravamentos manuais."""
from __future__ import annotations

import math
import re
import struct


def number(value, name="Valor"):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} deve ser um número finito.")
    try:
        struct.pack("<f", value)
    except (OverflowError, struct.error) as exc:
        raise ValueError(f"{name} não cabe no formato float de 32 bits do Mega.") from exc
    return float(value)


def pwm(value):
    if type(value) is not int or not 0 <= value <= 255:
        raise ValueError("PWM deve ser inteiro entre 0 e 255.")
    return value


def outputs(fans, power, peltier):
    if not isinstance(fans, list) or len(fans) != 3:
        raise ValueError("Informe os três PWMs de ventoinhas.")
    for value in fans:
        pwm(value)
    if type(power) is not bool:
        raise ValueError("Alimentação NB3 é um único liga/desliga comum aos três ventiladores.")
    pwm(peltier)


def tach(channel, pulses_per_rev):
    if type(channel) is not int or channel not in range(3):
        raise ValueError("Canal TACH deve estar entre 0 e 2.")
    if type(pulses_per_rev) is not int or not 1 <= pulses_per_rev <= 255:
        raise ValueError("Pulsos por volta devem ser inteiros entre 1 e 255.")


def gains(loop, kp, ki, kd):
    if loop not in ("pressure", "temperature"):
        raise ValueError("Malha PID desconhecida.")
    if any(number(value, "Ganho") < 0 for value in (kp, ki, kd)):
        raise ValueError("Ganhos PID devem ser não negativos.")


def calibration(channel, offset, scale):
    if type(channel) is not int or channel not in range(7):
        raise ValueError("Canal de pressão deve estar entre 0 e 6.")
    number(offset, "Offset")
    scale = number(scale, "Escala")
    if struct.unpack("<f", struct.pack("<f", scale))[0] == 0:
        raise ValueError("Escala não pode ser zero nem arredondar para zero no Mega.")


def crc8(data):
    crc = 0
    for byte in data:
        for _ in range(8):
            mix = (crc ^ byte) & 1
            crc >>= 1
            if mix:
                crc ^= 0x8C
            byte >>= 1
    return crc


def temperature_address(channel, address):
    if type(channel) is not int or channel not in range(6):
        raise ValueError("Canal de temperatura deve estar entre 0 e 5.")
    if not isinstance(address, str) or not re.fullmatch(r"[0-9a-fA-F]{16}", address):
        raise ValueError("ROM deve ter 16 dígitos hexadecimais.")
    rom = bytes.fromhex(address)
    if rom[0] != 0x28 or crc8(rom[:7]) != rom[7]:
        raise ValueError("ROM DS18B20 inválida (família 28 / CRC).")
