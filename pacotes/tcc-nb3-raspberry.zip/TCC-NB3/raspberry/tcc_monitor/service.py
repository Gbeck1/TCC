"""Regras de acesso e integração entre UI, banco e controlador serial."""
from __future__ import annotations

import copy
import json
import queue
import threading
import time
from pathlib import Path

from . import validation as check
from .storage import Store
from .protocol import VERSION
from .transport import DemoTransport, SerialTransport, decode_message


class AppError(Exception):
    """Erro que pode ser apresentado ao operador."""


class MonitorService:
    ACK_TIMEOUT = 2.0

    def __init__(self, data_dir=None, port=None, demo=False, transport_factory=None):
        suffix = "tcc-monitor-demo" if demo else "tcc-monitor"
        self.data_dir = Path(data_dir).expanduser() if data_dir else Path.home() / ".local/share" / suffix
        self.store = Store(self.data_dir)
        self.demo = demo
        self.lock = threading.RLock()
        self._snapshot = None
        self._status = "Inicializando SIMULAÇÃO" if demo else "Serial não iniciada"
        self._username = "Operador"
        self._role = "operator"
        self._generation = 0
        self._last_telemetry = 0.0
        self._id = 0
        self._pending = {}
        self._events = queue.Queue()
        self._closed = False
        self._started = False
        factory = transport_factory or (DemoTransport if demo else SerialTransport)
        self.transport = factory(callback=self._on_event, port=port)

    @property
    def snapshot(self):
        with self.lock:
            return copy.deepcopy(self._snapshot)

    @property
    def status(self):
        with self.lock:
            return self._status

    @property
    def admin(self):
        with self.lock:
            return self._role == "admin"

    @property
    def username(self):
        with self.lock:
            return self._username

    def start(self):
        if self._closed:
            raise AppError("Serviço já encerrado.")
        if not self._started:
            self._started = True
            self.transport.start()

    def close(self):
        if self._closed:
            return
        # No automatic/manual/output command on close. Outputs stay under Mega control.
        self._closed = True
        self.transport.close()
        self.store.close()

    def drain_events(self):
        events = []
        while True:
            try:
                events.append(self._events.get_nowait())
            except queue.Empty:
                return events

    def _on_event(self, event):
        try:
            self._receive(event)
        except Exception as exc:
            # A local DB/storage failure must be visible, never silently kill serial I/O.
            self._events.put({"type": "error", "message": "Falha ao processar dados: " + str(exc)})

    def _receive(self, event):
        kind = event.get("type")
        with self.lock:
            if kind == "telemetry":
                # Also validate simulator/custom transport messages at the trust boundary.
                state = decode_message(json.dumps(event, allow_nan=False).encode("utf-8"))
                self._snapshot = copy.deepcopy(state)
                self._last_telemetry = time.monotonic()
                self.store.record(state)
            elif kind == "status":
                self._status = event["status"]
                if self._status.startswith("Desconectado:") and self._pending:
                    for command_id, pending in self._pending.items():
                        self._events.put({"type": "error", "id": command_id, "op": pending["op"], "message":
                            f"Conexão perdida no comando {command_id} ({pending['op']}); resultado desconhecido, sem reenvio."})
                    self._pending.clear()
            elif kind == "ack":
                pending = self._pending.pop(event.get("id"), None)
                if pending is not None:
                    self._events.put(event)
                    detail = json.dumps({"id": event["id"], "ok": event["ok"], "error": event.get("error")}, ensure_ascii=False)
                    self.store.audit(pending["username"], "ack:" + pending["op"], detail)
                    callback = pending.get("on_success")
                    if event["ok"] and callback:
                        callback()
            elif kind == "command_sent":
                pending = self._pending.get(event.get("id"))
                if pending is not None:
                    pending["sent"] = time.monotonic()
            elif kind == "command_lost":
                pending = self._pending.pop(event.get("id"), None)
                if pending is not None:
                    self._events.put({"type": "error", "id": event["id"], "op": pending["op"], "message": event["message"]})
            elif kind == "error":
                self._events.put(event)
            if kind == "tick":
                now = time.monotonic()
                expired = [command_id for command_id, value in self._pending.items()
                           if value["sent"] is not None and now - value["sent"] > self.ACK_TIMEOUT]
                for command_id in expired:
                    pending = self._pending.pop(command_id)
                    self.store.audit(pending["username"], "timeout:" + pending["op"], str(command_id))
                    self._events.put({"type": "error", "id": command_id, "op": pending["op"], "message": f"Sem ACK do comando {command_id} ({pending['op']}). Resultado desconhecido; sem reenvio automático."})

    def _admin_required(self):
        if not self.admin:
            raise AppError("Entre com um usuário ADMIN para esta operação.")

    def _manual_required(self):
        self._admin_required()
        if not self._snapshot or self._snapshot["mode"] != "manual" or not self._snapshot["manual_authorized"]:
            raise AppError("Ative o modo manual autorizado antes de alterar este parâmetro.")

    def _command(self, op, on_success=None, **fields):
        with self.lock:
            if self._closed:
                raise AppError("Aplicação encerrada.")
            if not self._snapshot:
                raise AppError("Aguarde a primeira telemetria para reconhecer o controlador.")
            self._id = self._id % 2147483646 + 1
            command_id = self._id
            command = {"v": VERSION, "type": "command", "id": command_id, "op": op, **fields}
            self._pending[command_id] = {"sent": None, "op": op, "username": self.username, "on_success": on_success}
            try:
                self.transport.send(command)
            except (ValueError, OSError) as exc:
                self._pending.pop(command_id, None)
                raise AppError(str(exc)) from exc
            self.store.audit(self.username, "command:" + op, json.dumps(command, ensure_ascii=False, allow_nan=False))
            return command_id

    def login(self, username, password):
        if not isinstance(username, str) or not isinstance(password, str):
            raise AppError("Informe usuário e senha.")
        role = self.store.authenticate(username, password)
        if role is None:
            raise AppError("Usuário ou senha incorretos.")
        with self.lock:
            self._username = username
            self._role = role
            self._generation += 1
            self.store.audit(username, "login", role)

    def logout(self):
        with self.lock:
            self.store.audit(self.username, "logout", "Saídas preservadas")
            self._username = "Operador"
            self._role = "operator"
            self._generation += 1

    def set_mode(self, mode):
        with self.lock:
            if mode not in ("auto", "manual"):
                raise AppError("Modo deve ser auto ou manual.")
            if mode == "auto":
                self._command("mode", value="auto")
                return
            self._admin_required()
            generation = self._generation

            def enter_manual():
                # An ACK arriving after logout must not grant an anonymous operator a new mode.
                if self.admin and self._generation == generation:
                    self._command("mode", value="manual")

            self._command("manual_unlock", on_success=enter_manual)

    @staticmethod
    def _validated(function, *args):
        try:
            return function(*args)
        except (ValueError, TypeError) as exc:
            raise AppError(str(exc)) from exc

    def setpoints(self, temperature, pressure):
        self._validated(check.number, temperature, "Setpoint térmico")
        self._validated(check.number, pressure, "Setpoint de pressão")
        with self.lock:
            if self._snapshot and self._snapshot["mode"] == "manual":
                self._admin_required()
            self._command("setpoints", temperature=temperature, pressure=pressure)

    def outputs(self, fans, power, peltier):
        self._validated(check.outputs, fans, power, peltier)
        with self.lock:
            self._manual_required()
            self._command("outputs", fans=fans, fan_power=power, peltier=peltier)

    def set_pid(self, loop, kp, ki, kd):
        self._validated(check.gains, loop, kp, ki, kd)
        with self.lock:
            self._manual_required()
            self._command("pid", loop=loop, kp=kp, ki=ki, kd=kd)

    def calibrate(self, channel, offset, scale):
        self._validated(check.calibration, channel, offset, scale)
        with self.lock:
            self._manual_required()
            return self._command("calibrate", channel=channel, offset=offset, scale=scale)

    def set_temperature_address(self, channel, address):
        self._validated(check.temperature_address, channel, address)
        with self.lock:
            self._manual_required()
            self._command("temperature_address", channel=channel, address=address.upper())

    def set_tach(self, channel, pulses_per_rev):
        self._validated(check.tach, channel, pulses_per_rev)
        with self.lock:
            self._manual_required()
            self._command("tach", channel=channel, pulses_per_rev=pulses_per_rev)

    def save_controller(self):
        with self.lock:
            self._manual_required()
            return self._command("save")

    def rooms(self):
        return self.store.rooms()

    def history(self, room_id, limit=300):
        return self.store.history(room_id, limit)

    def alarm_log(self, limit=200):
        return self.store.alarm_log(limit)

    def users(self):
        self._admin_required()
        return self.store.users()

    def update_room(self, room_id, name, temp_min, temp_max, pressure_min, pressure_max):
        self._validated(self.store.update_room, room_id, name, temp_min, temp_max, pressure_min, pressure_max)
        self.store.audit(self.username, "room:update", str(room_id))

    def assign_rooms(self, mapping, confirmed=True):
        self._validated(self.store.assign_rooms, mapping, confirmed)
        self.store.audit(self.username, "room:assign", json.dumps(mapping, ensure_ascii=False))

    def add_user(self, username, password, role):
        self._admin_required()
        self._validated(self.store.add_user, username, password, role)
        self.store.audit(self.username, "user:add", username)

    def delete_user(self, username):
        self._admin_required()
        if username == self.username:
            raise AppError("Entre com outro administrador para excluir este usuário.")
        self._validated(self.store.delete_user, username)
        self.store.audit(self.username, "user:delete", username)

    def change_password(self, username, password):
        self._admin_required()
        self._validated(self.store.change_password, username, password)
        self.store.audit(self.username, "password:change", username)

    def export_csv(self, path):
        try:
            return self.store.export_csv(path)
        except (ValueError, OSError) as exc:
            raise AppError(str(exc)) from exc
