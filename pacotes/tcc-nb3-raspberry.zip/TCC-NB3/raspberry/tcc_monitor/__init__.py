"""Monitor local do TCC: Arduino Mega 2560 e Raspberry Pi."""

__version__ = "0.2.0"
