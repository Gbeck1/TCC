"""Pressure calibration workflow without blocking Tk or changing process outputs."""
from __future__ import annotations

import math
import statistics
import tkinter as tk
from tkinter import ttk

from .calibration import calibration_from_points, zero_calibration
from .service import AppError


BG = "#edf3fa"
INK = "#19334f"
BLUE = "#1967b4"
GREEN = "#187957"
RED = "#ba3447"
MUTED = "#5c7289"
AMBER = "#ad5e0d"


def _number(value, digits=5):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return "--"
    return f"{value:.{digits}g}"


def _decimal(value):
    try:
        result = float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError) as exc:
        raise ValueError("Informe a pressão de referência em Pa.") from exc
    if not math.isfinite(result):
        raise ValueError("A pressão de referência deve ser um número finito.")
    return result


def _item(values, index):
    return values[index] if isinstance(values, (tuple, list)) and len(values) > index else None


class PressureCalibration(ttk.Frame):
    """Capture two known pressures, preview coefficients and explicitly apply/save.

    ``channel`` uses the displayed one-based channel number; service commands use
    the zero-based channel index. A captured point retains its reference pressure
    and channel, independently of subsequent form edits.
    """

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.service = app.service
        self.channel = tk.StringVar(self, "1")
        self.sample_count = tk.StringVar(self, "5")
        self.pressure_a = tk.StringVar(self, "0")
        self.pressure_b = tk.StringVar(self, "")
        self.raw_a = tk.StringVar(self, "Ainda não capturado")
        self.raw_b = tk.StringVar(self, "Ainda não capturado")
        self.points = {}
        self.room_name = tk.StringVar(self)
        self.live_reading = tk.StringVar(self, "Leitura bruta: --     Pressão: -- Pa")
        self.current_coefficients = tk.StringVar(self, "Atual: offset -- · escala -- Pa/contagem")
        self.preview_text = tk.StringVar(self, "Prévia: capture A e B e escolha Calcular.")
        self.status = tk.StringVar(self, "")
        self._capture = None
        self._preview = None
        self._pending = None
        self._awaiting_coefficients = None
        self._timer = None
        self._destroyed = False
        self._rooms = {}
        self._make_widgets()
        self.channel.trace_add("write", self._channel_changed)
        self.pressure_a.trace_add("write", lambda *_: self._reference_changed("a"))
        self.pressure_b.trace_add("write", lambda *_: self._reference_changed("b"))
        self.bind("<Destroy>", self._on_destroy, add="+")
        self._channel_changed()
        self._tick()

    def _make_widgets(self):
        style = ttk.Style(self)
        style.configure("Calibration.TButton", padding=(10, 10), font=("DejaVu Sans", 12, "bold"))
        style.configure("CalibrationPrimary.TButton", padding=(10, 10), font=("DejaVu Sans", 12, "bold"),
                        foreground="white", background=BLUE)
        style.map("CalibrationPrimary.TButton", background=[("disabled", "#b4c4d5"), ("active", "#145893")],
                  foreground=[("disabled", "#edf3fa")])
        style.configure("Calibration.TEntry", padding=(7, 8), font=("DejaVu Sans", 14))
        self.columnconfigure(0, weight=1, uniform="references")
        self.columnconfigure(1, weight=1, uniform="references")

        ttk.Label(self, text="Use uma pressão de referência conhecida; deixe estabilizar antes de capturar.",
                  foreground=MUTED, wraplength=680).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        selection = ttk.Frame(self)
        selection.grid(row=1, column=0, sticky="ew", pady=(0, 3))
        ttk.Label(selection, text="Canal P").pack(side="left")
        ttk.Combobox(selection, textvariable=self.channel, values=tuple(str(n) for n in range(1, 8)),
                     width=3, state="readonly").pack(side="left", padx=(3, 8))
        ttk.Label(selection, textvariable=self.room_name, foreground=INK,
                  font=("DejaVu Sans", 13, "bold")).pack(side="left")
        sampling = ttk.Frame(self)
        sampling.grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 8))
        ttk.Label(sampling, text="Amostras").pack(side="left", padx=(0, 4))
        self.sample_selector = ttk.Combobox(sampling, textvariable=self.sample_count,
                                           values=tuple(str(n) for n in range(1, 31)), width=3, state="readonly")
        self.sample_selector.pack(side="left")
        self.cancel_button = ttk.Button(sampling, text="Cancelar coleta", command=self.cancel_capture,
                                         style="Calibration.TButton")
        self.cancel_button.pack(side="left", padx=(8, 0))
        ttk.Label(self, textvariable=self.live_reading, foreground=BLUE,
                  font=("DejaVu Sans", 14, "bold"), wraplength=680).grid(row=3, column=0, columnspan=2, sticky="w")
        ttk.Label(self, textvariable=self.current_coefficients, foreground=MUTED,
                  font=("DejaVu Sans", 12), wraplength=680).grid(row=4, column=0, columnspan=2, sticky="w", pady=(4, 8))

        self.capture_buttons = {}
        self.reference_entries = {}
        for column, point in enumerate(("a", "b")):
            area = ttk.Frame(self)
            area.grid(row=5, column=column, sticky="new", padx=(0, 12) if column == 0 else (0, 0))
            ttk.Label(area, text=f"Referência {point.upper()} (Pa)", font=("DejaVu Sans", 13, "bold")).grid(
                row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
            entry = ttk.Entry(area, textvariable=getattr(self, "pressure_" + point), width=9,
                              style="Calibration.TEntry")
            entry.grid(row=1, column=0, sticky="w", padx=(0, 8))
            self.reference_entries[point] = entry
            button = ttk.Button(area, text=f"Capturar {point.upper()}", command=lambda p=point: self.start_capture(p),
                                style="Calibration.TButton")
            button.grid(row=1, column=1, sticky="w")
            self.capture_buttons[point] = button
            ttk.Label(area, textvariable=getattr(self, "raw_" + point), foreground=MUTED,
                      font=("DejaVu Sans", 11), wraplength=320).grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 8))

        actions = ttk.Frame(self)
        actions.grid(row=6, column=0, columnspan=2, sticky="ew", pady=(4, 8))
        self.calculate_button = ttk.Button(actions, text="Calcular", command=self.calculate, style="Calibration.TButton")
        self.calculate_button.pack(side="left")
        self.apply_button = ttk.Button(actions, text="Aplicar calibração", command=self.apply,
                                       style="CalibrationPrimary.TButton")
        self.apply_button.pack(side="left", padx=6)
        ttk.Label(self, textvariable=self.preview_text, foreground=INK, font=("DejaVu Sans", 12),
                  wraplength=680).grid(row=7, column=0, columnspan=2, sticky="w", pady=(0, 4))
        self.status_label = ttk.Label(self, textvariable=self.status, foreground=MUTED,
                                      wraplength=680, font=("DejaVu Sans", 12))
        self.status_label.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(2, 8))

        ttk.Separator(self).grid(row=9, column=0, columnspan=2, sticky="ew", pady=8)
        advanced = ttk.Frame(self)
        advanced.grid(row=10, column=0, columnspan=2, sticky="ew")
        self.zero_button = ttk.Button(advanced, text="Zerar canal", command=self.zero, style="Calibration.TButton")
        self.zero_button.pack(side="left")
        self.save_button = ttk.Button(advanced, text="Salvar no Arduino", command=self.save, style="Calibration.TButton")
        self.save_button.pack(side="left", padx=6)
        ttk.Label(self, text="Aplicar usa a memória atual. Salvar preserva após reiniciar.",
                  foreground=MUTED, wraplength=680, font=("DejaVu Sans", 12)).grid(
                      row=11, column=0, columnspan=2, sticky="w", pady=(6, 0))

    def _index(self):
        try:
            value = int(self.channel.get()) - 1
        except (ValueError, tk.TclError):
            return None
        return value if 0 <= value <= 6 else None

    def _set_status(self, text, color=MUTED, announce=False):
        self.status.set(text)
        self.status_label.configure(foreground=color)
        if announce and hasattr(self.app, "message"):
            self.app.message.set(text)

    def _channel_changed(self, *_):
        self.cancel_capture(announce=False)
        self.points.clear()
        self.raw_a.set("Ainda não capturado")
        self.raw_b.set("Ainda não capturado")
        self._preview = None
        self.preview_text.set("Prévia: capture A e B e escolha Calcular.")
        self._refresh_room_name()
        if self._pending is None and self._awaiting_coefficients is None:
            self._set_status("", announce=False)
        self._refresh()

    def _refresh_room_name(self):
        rooms = self.service.rooms()
        self._rooms = {room["id"]: room["name"] for room in rooms}
        index = self._index()
        self.room_name.set("Ambiente" if index == 6 else self._rooms.get(index + 1 if index is not None else None, ""))

    def _reference_changed(self, point):
        # While collecting, edits cannot replace the pressure fixed at start.
        if self._capture is not None and self._capture["point"] == point:
            return
        if point in self.points:
            self.points.pop(point)
            getattr(self, "raw_" + point).set("Referência alterada; capture novamente")
        self._preview = None
        self.preview_text.set("Prévia: capture A e B e escolha Calcular.")
        self._update_buttons(self.service.snapshot or {})

    def _manual_authorized(self, data):
        return bool(self.service.admin and data.get("mode") == "manual" and data.get("manual_authorized"))

    def _require_manual(self, data):
        if not self.service.admin:
            raise AppError("Entre como ADMIN para aplicar ou salvar a calibração.")
        if not self._manual_authorized(data):
            raise AppError("Selecione Manual na manutenção para aplicar ou salvar a calibração.")

    def _busy(self):
        return self._pending is not None or self._awaiting_coefficients is not None

    def _update_buttons(self, data):
        capturing = self._capture is not None
        self.cancel_button.configure(text="Cancelar espera" if self._busy() else "Cancelar coleta",
                                     state="normal" if capturing or self._busy() else "disabled")
        for button in self.capture_buttons.values():
            button.configure(state="disabled" if capturing or self._busy() else "normal")
        self.sample_selector.configure(state="disabled" if capturing else "readonly")
        for point, entry in self.reference_entries.items():
            entry.configure(state="disabled" if capturing and self._capture["point"] == point else "normal")
        self.calculate_button.configure(state="normal" if not capturing and len(self.points) == 2 and not self._busy() else "disabled")
        editable = self._manual_authorized(data) and not capturing and not self._busy()
        applicable = editable and self._preview is not None and self._preview["channel"] == self._index()
        self.apply_button.configure(state="normal" if applicable else "disabled")
        self.zero_button.configure(state="normal" if editable else "disabled")
        # A calculated preview is not controller state and cannot be persisted.
        index = self._index()
        calibrated = index is not None and _item(data.get("calibrated"), index)
        savable = editable and calibrated and (self._preview is None or self._matches_coefficients(self._preview, data))
        self.save_button.configure(state="normal" if savable else "disabled")

    def _refresh(self, data=None):
        if data is None:
            data = self.service.snapshot or {}
        index = self._index()
        raw = _item(data.get("raw_pressures"), index) if index is not None else None
        pa = _item(data.get("pressures"), index) if index is not None else None
        self.live_reading.set(f"Leitura bruta: {_number(raw, 8)}     Pressão: {_number(pa, 6)} Pa")
        coefficient = _item(data.get("calibration"), index) if index is not None else None
        coefficient = coefficient if isinstance(coefficient, dict) else {}
        calibrated = _item(data.get("calibrated"), index) if index is not None else False
        suffix = "" if calibrated else " · sem calibração"
        self.current_coefficients.set(f"Atual: offset {_number(coefficient.get('offset'), 8)} · "
                                      f"escala {_number(coefficient.get('scale'), 8)} Pa/contagem{suffix}")
        self._update_buttons(data)
        return data

    @staticmethod
    def _frame_key(data):
        seq, ms = data.get("seq"), data.get("ms")
        if isinstance(seq, bool) or isinstance(ms, bool) or not isinstance(seq, int) or not isinstance(ms, int):
            return None
        return seq, ms

    def start_capture(self, point):
        if point not in ("a", "b"):
            raise ValueError("Ponto deve ser a ou b.")
        try:
            if self._busy():
                raise ValueError("Aguarde a resposta do Arduino antes de iniciar outra coleta.")
            pressure = _decimal(getattr(self, "pressure_" + point).get())
            try:
                count = int(self.sample_count.get())
            except ValueError as exc:
                raise ValueError("Escolha entre 1 e 30 amostras.") from exc
            if not 1 <= count <= 30:
                raise ValueError("Escolha entre 1 e 30 amostras.")
            index = self._index()
            if index is None:
                raise ValueError("Selecione um canal entre P1 e P7.")
        except (ValueError, TypeError) as exc:
            self._set_status(str(exc), RED)
            return
        self.cancel_capture(announce=False)
        self.points.pop(point, None)
        self._preview = None
        self.preview_text.set("Prévia: aguardando a coleta dos pontos.")
        data = self.service.snapshot or {}
        key = self._frame_key(data)
        self._capture = {"point": point, "channel": index, "pressure": pressure,
                         "target": count, "samples": [], "last_key": key,
                         "saturated": False}
        getattr(self, "raw_" + point).set(f"Coletando 0/{count} · referência {_number(pressure)} Pa")
        self._set_status(f"P{index + 1}: aguardando novas leituras para a referência {point.upper()}.", BLUE)
        self._update_buttons(data)

    def cancel_capture(self, announce=True):
        capture = self._capture
        self._capture = None
        if capture is not None:
            getattr(self, "raw_" + capture["point"]).set("Coleta cancelada; capture novamente")
            if announce:
                self._set_status("Coleta cancelada. Nenhum coeficiente foi alterado.")
            self._update_buttons(self.service.snapshot or {})
        elif announce and self._busy():
            self._pending = None
            self._awaiting_coefficients = None
            self._set_status("Acompanhamento encerrado; o comando enviado pode ter sido executado. "
                             "Confira o estado recebido do Arduino; não houve reenvio.", AMBER)
            self._update_buttons(self.service.snapshot or {})

    def _collect(self, data):
        capture = self._capture
        if capture is None:
            return
        if capture["channel"] != self._index():
            self.cancel_capture(announce=False)
            return
        key = self._frame_key(data)
        if key is None or key == capture["last_key"]:
            return
        capture["last_key"] = key
        raw = _item(data.get("raw_pressures"), capture["channel"])
        if isinstance(raw, bool) or not isinstance(raw, (int, float)) or not math.isfinite(raw):
            self._set_status(f"P{capture['channel'] + 1}: sem leitura bruta; aguardando o sensor "
                             f"({len(capture['samples'])}/{capture['target']}).", AMBER, announce=False)
            return
        capture["samples"].append(raw)
        if raw in (-8388608, 8388607):
            capture["saturated"] = True
        count = len(capture["samples"])
        getattr(self, "raw_" + capture["point"]).set(f"Coletando {count}/{capture['target']} · referência {_number(capture['pressure'])} Pa")
        self._set_status(f"P{capture['channel'] + 1}: coletando {capture['point'].upper()}, "
                         f"{count}/{capture['target']} amostras.", BLUE, announce=False)
        if count < capture["target"]:
            return
        mean = statistics.fmean(capture["samples"])
        self.points[capture["point"]] = {"channel": capture["channel"], "raw": mean,
                                          "pressure": capture["pressure"], "samples": count}
        self._capture = None
        getattr(self, "raw_" + capture["point"]).set(f"Bruto médio: {_number(mean, 8)} · {_number(capture['pressure'])} Pa ({count} amostras)")
        if capture["saturated"]:
            self._set_status(f"Referência {capture['point'].upper()} capturada; houve leitura no limite do conversor. "
                             "Confira se o sinal está saturado.", AMBER)
        else:
            self._set_status(f"Referência {capture['point'].upper()} capturada. "
                             + ("Escolha Calcular para conferir a prévia." if len(self.points) == 2 else "Capture a outra referência."), GREEN)

    def _set_preview(self, coefficient, index, source):
        self._preview = {"channel": index, "offset": coefficient["offset"], "scale": coefficient["scale"], "source": source}
        self.preview_text.set(f"Prévia P{index + 1}: offset {_number(coefficient['offset'], 8)} · "
                              f"escala {_number(coefficient['scale'], 8)} Pa/contagem")
        self._update_buttons(self.service.snapshot or {})

    def calculate(self):
        try:
            if self._capture is not None or self._busy():
                raise ValueError("Conclua a coleta e aguarde a resposta do Arduino antes de calcular.")
            index = self._index()
            if any(point not in self.points or self.points[point]["channel"] != index for point in ("a", "b")):
                raise ValueError("Capture as referências A e B para o mesmo canal.")
            a, b = self.points["a"], self.points["b"]
            coefficient = calibration_from_points(a["raw"], a["pressure"], b["raw"], b["pressure"])
            self._set_preview(coefficient, index, "points")
            self._set_status("Prévia calculada. Confira os valores e escolha Aplicar calibração.", BLUE)
        except (ValueError, TypeError, OverflowError) as exc:
            self._preview = None
            self.preview_text.set("Prévia indisponível; confira as referências.")
            self._set_status(str(exc), RED)
            self._update_buttons(self.service.snapshot or {})

    def apply(self):
        try:
            data = self.service.snapshot or {}
            self._require_manual(data)
            if self._capture is not None or self._busy():
                raise AppError("Aguarde a coleta ou a resposta do Arduino antes de aplicar.")
            preview = self._preview
            if preview is None or preview["channel"] != self._index():
                raise AppError("Calcule a prévia para o canal selecionado antes de aplicar.")
            command_id = self.service.calibrate(preview["channel"], preview["offset"], preview["scale"])
            self._pending = {"id": command_id, "op": "calibrate", **preview}
            self._set_status(f"P{preview['channel'] + 1}: aguardando confirmação do Arduino para a calibração.", BLUE)
        except (AppError, ValueError, TypeError, OSError) as exc:
            self._set_status(str(exc), RED)
        self._update_buttons(self.service.snapshot or {})

    def zero(self):
        try:
            data = self.service.snapshot or {}
            self._require_manual(data)
            if self._capture is not None or self._busy():
                raise AppError("Aguarde a coleta ou a resposta do Arduino antes de zerar.")
            index = self._index()
            raw = _item(data.get("raw_pressures"), index) if index is not None else None
            coefficient = _item(data.get("calibration"), index) if index is not None else None
            if not _item(data.get("calibrated"), index) or not isinstance(coefficient, dict) or not coefficient.get("scale"):
                raise AppError("Faça a calibração por duas referências antes de zerar este canal.")
            if isinstance(raw, bool) or not isinstance(raw, (int, float)) or not math.isfinite(raw):
                raise AppError("Aguarde uma leitura bruta válida para zerar este canal.")
            result = zero_calibration(raw, coefficient["scale"])
            self._set_preview(result, index, "zero")
            self._set_status(f"Prévia de zero de P{index + 1} calculada para 0 Pa. Escolha Aplicar calibração.", BLUE)
        except (AppError, ValueError, TypeError, OverflowError) as exc:
            self._set_status(str(exc), RED)

    def save(self):
        try:
            data = self.service.snapshot or {}
            self._require_manual(data)
            if self._capture is not None or self._busy():
                raise AppError("Aguarde a confirmação da calibração antes de salvar no Arduino.")
            index = self._index()
            if index is None or not _item(data.get("calibrated"), index):
                raise AppError("Aplique uma calibração ao canal selecionado antes de salvar no Arduino.")
            if self._preview is not None and not self._matches_coefficients(self._preview, data):
                raise AppError("A prévia ainda não foi aplicada. Escolha Aplicar calibração antes de salvar.")
            command_id = self.service.save_controller()
            self._pending = {"id": command_id, "op": "save"}
            self._set_status("Aguardando confirmação do Arduino para salvar a configuração.", BLUE)
        except (AppError, ValueError, TypeError, OSError) as exc:
            self._set_status(str(exc), RED)
        self._update_buttons(self.service.snapshot or {})

    def notify_event(self, event):
        """Receive events routed by the app; only this frame's command ids matter."""
        pending = self._pending
        if event.get("type") == "error" and self._awaiting_coefficients is not None:
            if event.get("id") == self._awaiting_coefficients["id"]:
                self._awaiting_coefficients = None
                self._set_status(str(event.get("message", "Coeficientes ainda não confirmados por telemetria.")), RED)
                self._update_buttons(self.service.snapshot or {})
                return
        if pending is None or pending["id"] is None or event.get("id") != pending["id"]:
            return
        if event.get("type") == "ack":
            self._pending = None
            if not event.get("ok"):
                self._set_status("Arduino recusou a operação: " + str(event.get("error", "erro sem descrição")), RED)
            elif pending["op"] == "save":
                self._set_status("Configuração salva no Arduino.", GREEN)
            else:
                self._awaiting_coefficients = pending
                self._set_status(f"Arduino confirmou P{pending['channel'] + 1}; aguardando a telemetria dos coeficientes.", BLUE)
                self._check_coefficients(self.service.snapshot or {})
        elif event.get("type") == "error":
            self._pending = None
            self._set_status(str(event.get("message", "Sem confirmação do Arduino; resultado desconhecido.")), RED)
        self._update_buttons(self.service.snapshot or {})

    @staticmethod
    def _matches_coefficients(expected, data):
        received = _item(data.get("calibration"), expected["channel"])
        if not isinstance(received, dict) or not _item(data.get("calibrated"), expected["channel"]):
            return False
        try:
            return all(math.isclose(received[field], expected[field], rel_tol=2e-6, abs_tol=0)
                       for field in ("offset", "scale"))
        except (KeyError, ValueError, TypeError):
            return False

    def _check_coefficients(self, data):
        expected = self._awaiting_coefficients
        if expected is not None and self._matches_coefficients(expected, data):
            self._awaiting_coefficients = None
            self._set_status(f"Calibração de P{expected['channel'] + 1} confirmada. "
                             "Use Salvar no Arduino para preservar após reiniciar.", GREEN)

    def _tick(self):
        if self._destroyed:
            return
        self._timer = None
        try:
            data = self._refresh()
            self._collect(data)
            self._check_coefficients(data)
            self._update_buttons(data)
        except (AppError, KeyError, ValueError, TypeError) as exc:
            self._set_status("Não foi possível atualizar a calibração: " + str(exc), RED, announce=False)
        self._timer = self.after(200, self._tick)

    def _on_destroy(self, event):
        if event.widget is not self:
            return
        self._destroyed = True
        if self._timer is not None:
            self.after_cancel(self._timer)
            self._timer = None
        self._capture = None
