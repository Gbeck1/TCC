# Comissionamento NB3

Faça esta sequência com os valores físicos de sua montagem. A simulação e os testes unitários não substituem medições no circuito.

## 1. Confirmar montagem e comunicação

Confira o mapa NB3 de [wiring.md](wiring.md): PWM D6/D7/D8, alimentação única D4 pelo driver Q4/IRF4905, Peltier D5, OneWire D36, sete pares HX710B D22..D35 e tacômetros D2/D3/D18. Primeiro verifique sinais lógicos e tensões; depois conecte as cargas. Confirme pinos, clock, frequência/polaridade de PWM, níveis dos tacômetros e correntes nas unidades reais.

A associação confirmada é P1 Paramentação, P2 Desparamentação, P3 Corredor Central, P4 Sala de Autoclave, P5 Laboratório 1 e P6 Laboratório 2. Confira as mangueiras, a fiação e as ROMs contra essa tabela. A planta é uma aproximação esquemática sem cotas físicas. O PID sempre usa P6/Laboratório 2; renomear uma sala na interface não muda o canal de referência.

Atualize firmware e aplicação juntos para o protocolo v2. Grave o firmware, conecte a USB à Pi e execute sem `--demo`. A telemetria precisa identificar `v:2` e `hardware:"NB3"`; uma versão antiga não deve ser aceita como equivalente. Faça um comando de setpoint e confirme seu ACK e o valor retornado. Uma mensagem enviada não comprova execução antes do ACK. Perda de comunicação gera estado desconectado; não deve mostrar medidas novas inventadas ou reenviar saídas anteriores.

O layout EEPROM NB3 é versão 2. Uma configuração salva pelo layout anterior é invalidada; confira/reinsira calibrações, ROMs, ganhos, setpoints e pulsos por volta antes de salvar explicitamente. A atualização do firmware não transporta automaticamente esses dados antigos para a nova pinagem.

## 2. Associar os DS18B20

Entre como ADMIN (senha inicial `15234`), mude a senha e habilite Manual. Identifique as seis ROMs e associe-as às salas corretas na aba de sensores/manutenção. A descoberta das ROMs ocorre na partida para evitar interrupções prolongadas da comunicação: depois de acrescentar, retirar ou substituir sensores, reinicie o Mega para atualizar a lista de endereços descobertos. Aqueça um sensor por vez e confira a sala que responde. Verifique os seis sensores antes de usar a média: o firmware só publica a média quando todos os seis são válidos. Salve a configuração no controlador e aguarde o ACK de conclusão da gravação.

## 3. Calibrar os sete canais de pressão

O firmware inicia os canais sem escala física. Por isso uma leitura em contagens pode estar disponível enquanto a leitura em Pa aparece ausente. Não considere isso como pressão zero.

A interface possui **Manutenção → Calibração**, com captura por duas referências, cálculo automático, zeragem e gravação no Arduino. Siga [o procedimento pela interface](calibration.md); não é necessário editar o sketch para atualizar os coeficientes.

Defina primeiro a topologia pneumática. O MPS20N0040D-D mede a diferença entre duas portas; nenhum dos sete módulos é tratado aqui como barômetro absoluto. Para usar a fórmula implementada `canal_sala - canal_ambiente`, os canais precisam compartilhar uma referência coerente. Uma possibilidade é ligar uma porta de todos os módulos à mesma referência e a outra à sala ou ao ambiente correspondente. Confira se a referência escolhida e o intervalo dos módulos permitem medir o que o projeto exige. Se as duas portas dos seis sensores já estiverem ligadas diretamente entre sala e ambiente, revise a fórmula para não descontar o ambiente uma segunda vez. O sétimo sensor só tem interpretação útil quando suas duas portas e sua referência forem explicitadas.

Para cada canal, registre a contagem `r0` em uma diferença de pressão conhecida `p0` entre suas portas e a contagem `r1` em outra diferença conhecida `p1`, nas unidades Pa. Calcule:

```text
scale = (p1 - p0) / (r1 - r0)       # Pa/contagem; r1 precisa diferir de r0
offset = r0 - p0 / scale           # contagens
p = (raw - offset) * scale
```

Não arredonde uma escala pequena para zero. A escala pode ter sinal negativo dependendo da orientação pneumática. Use mais pontos para verificar linearidade, histerese e ruído; o ajuste de dois pontos não prova adequação para todo o intervalo. Confirme o canal e aplique offset/escala no modo manual ADMIN, repetindo nos sete módulos.

Coloque todas as salas na mesma pressão ambiente. As seis pressões diferenciais devem ficar próximas de zero dentro da incerteza esperada. Aplique diferenças conhecidas e confira sinal e amplitude, especialmente em P6/Laboratório 2. Confirme a topologia de referências dos módulos: a equação `sala - ambiente` só vale quando os sete canais têm referência coerente. Salve na EEPROM após validar.

## 4. Conferir atuação manual

No modo manual ADMIN, teste separadamente os dois PWM Delta, o PWM NMB, o comando único de alimentação e o Peltier, dentro das condições do ensaio. Confirme que PWM lógico crescente aumenta a velocidade real de cada ventoinha, apesar da inversão pelo BC548. Desligar `fan_power` deve cortar a alimentação das três juntas; PWM zero sozinho pode não parar uma ventoinha. O NB3 não tem três comandos independentes de alimentação.

Confira cada tacômetro, a tensão/pull-up de 10 kΩ e os pulsos por volta. O valor inicial de 2 pulsos/volta é provisório: consulte o modelo real ou compare com uma medição de referência antes de confiar no RPM. Configure o canal no manual ADMIN e salve. RPM zero depois de uma janela sem pulsos não prova desligamento da carga; também pode indicar fio/sinal incorreto. Não existe intertravamento por RPM.

O manual não aplica intertravamento entre ventoinhas e não desliga saídas por timeout. Pode haver qualquer combinação de PWMs e alimentação, respeitando apenas os domínios de representação do hardware. Logout, saída do programa e desconexão USB não enviam novos comandos de atuação. Confira esses comportamentos antes de usar a montagem sem acompanhamento.

## 5. Ajustar os controles automáticos

O PID de pressão compara o diferencial de **P6/Laboratório 2** com o setpoint em Pa. Quando a medição está acima do setpoint, aumenta o esforço de exaustão. O automático mantém o PWM de ambas as Delta estritamente maior que o da NMB e liga a alimentação comum das três ventoinhas. Verifique vazão e pressão em todos os ambientes: a relação de PWM é uma regra de comando, não uma medição de vazão.

O controle térmico Liga/Desliga usa a média dos seis DS18B20. Liga o Peltier acima do setpoint + 0,5°C e desliga quando a média chega ao setpoint ou fica abaixo dele; no intervalo conserva o estado. Confira a posição do lado frio/quente e o sentido da resposta. O software não implementa aquecimento por reversão de corrente.

Os ganhos iniciais são valores de partida de software, não sintonia comprovada da maquete. No manual autorizado, ajuste os ganhos do PID de pressão, observando resposta, atraso, saturação e oscilações. Depois mude para Automático e confira os setpoints e saídas recebidos. A anti-saturação matemática do PID não adiciona um intertravamento entre cargas. Salve os ganhos/setpoints após o ensaio.

Na ausência de uma medição válida, o controlador conserva o último esforço calculado para aquele controle e informa ausência de valor. Não existe desligamento automático adicional por falha de sensor. Os limites de alarme da interface registram eventos e não interrompem a atuação.

## 6. Alarmes, históricos e recuperação

Defina os mínimos/máximos de temperatura e pressão diferencial de cada sala. Provoque uma passagem controlada pelos limites e confira a entrada e o retorno de alarme, com sala/parâmetro/horário. Abra os gráficos de cada sala e exporte CSV; confira datas, unidades e valores contra a telemetria real.

Feche/reabra o programa para confirmar persistência de usuários, associação dos ambientes, nomes, limites e histórico, além da necessidade de novo login ADMIN. Reinicie o Mega e confira a configuração EEPROM v2 salva, incluindo pulsos por volta, e a ausência de restauração de modo/saídas manuais. O circuito de auto-reset de algumas interfaces USB pode reiniciar o Mega ao abrir a porta; esse comportamento é físico e precisa ser testado.

Verifique o launcher por clique na tela da Pi. Confirme legibilidade e toque em 800×480, acesso ao teclado de tela e ao botão Sair. A aplicação não coleta amostras nem alarmes enquanto estiver fechada ou sem telemetria; o Mega continua controlando sem depender da interface.
