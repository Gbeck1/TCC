# Interface para tela touch de 7″

A versão 0.3.0 reorganiza a interface para leitura em 800×480. O corpo dos formulários usa fonte de 13 pontos, as entradas usam 14 pontos e as leituras principais da planta usam 20 pontos. Em janelas maiores, as leituras podem aumentar para 22 ou 24 pontos. A divisão esquemática das salas foi equilibrada para que a Autoclave tenha o mesmo espaço de leitura das demais, mantendo a posição de cada ambiente.

Pressão e temperatura aparecem em linhas separadas. A linha SP mantém os setpoints globais. A linha seguinte apresenta os limites mínimo e máximo de P e T, separados por reticências. Cores e texto indicam leituras ausentes, alarmes e dados anteriores. Tocar numa sala abre seus dois gráficos.

Na Manutenção, as setas ▲ e ▼ à direita rolam os formulários. Os controles foram distribuídos em mais linhas para preservar o tamanho de letra. As ações que ficam abaixo da área visível continuam acessíveis pela rolagem; a roda do mouse também funciona. A calibração mantém a sequência Capturar A/B, Calcular, Aplicar e Salvar no Arduino.

Os gráficos mostram os valores atuais em destaque, o histórico com horários no eixo horizontal e o setpoint como linha verde tracejada. A escala vertical acompanha as medições e o alvo para evidenciar pequenas variações. Os limites atuais aparecem no cabeçalho de cada gráfico; suas linhas vermelhas são desenhadas quando estão dentro da escala exibida. Os limites e setpoints apresentados são os atuais, não uma reconstrução dos ajustes utilizados em cada amostra histórica. Leituras ausentes interrompem a curva; não são substituídas por zero. Voltar fecha o histórico e retorna à planta.

Em monitores de até 1024×600, a aplicação abre em tela cheia. Sair permanece acessível pelo toque. Esc retorna ao modo janela; F11 alterna tela cheia em qualquer monitor. A aplicação continua sendo iniciada apenas por clique ou comando, sem autostart.

Na versão 0.4.0, tocar nos campos numéricos editáveis abre um teclado com dígitos, vírgula decimal, sinal, Apagar, Limpar, Cancelar e Concluir. A edição aparece num campo próprio do teclado. Concluir preenche o campo de origem; não envia comandos ao Arduino. Cancelar preserva o conteúdo anterior. Os percentuais dos ventiladores aceitam 0 a 100%, inclusive frações. Campos desabilitados não abrem o teclado.

O Peltier possui a opção Ligar, com estado recebido separado; Aplicar saídas confirma o envio. O controle automático usa Liga/Desliga com a média dos seis sensores e histerese de 0,5°C. A aba PID controla apenas a pressão. A página Setpoints informa quando o Arduino ainda precisa da atualização. O roteiro para a instalação existente em /home/beck/Desktop/TCC-NB3 está em [update-0.4.md](update-0.4.md).
